
(function(){
const S = {
  db:null, dbState:'loading', // loading | ok | missing
  q:new Map(), r:new Map(), rodadas:[], qLoaded:false,
  view:'painel', cap:null, modo:'novos', shuffle:false,
  round:null, pendingRender:false,
  ed:new Map(), mat:new Map(), pt:new Map(), di:[], edLoaded:false,
  fEvo:'', evoModo:'n', evoOff:new Set(), evoPer:'d', evoDe:'', evoAte:'',
  fMat:'', fSt:'', abertos:new Set(), ptsAbertos:new Set(), evocar:false, revelados:new Set(),
  rv:new Map(), cfg:new Map(), cartAbertos:new Set(),
  pg:new Map(), fPgMat:'', fPgTipo:'',
  an:new Map(), mecQ:new Map(), pgModo:'mec', fMecMat:''
};
const VIEWS=['cartoes','mapa','simulado','painel','edital','revisao','pegadinhas','conteudo','treinar','caderno','historico','metodo'];
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtPct=x=>isFinite(x)?(Math.round(x*100)+'%'):'–';
const LETRA={C:'Certo',E:'Errado',B:'Em branco'};
const CONF={1:'Chute',2:'Dúvida',3:'Certeza'};

/* ---------- método: revisão espaçada ---------- */
const PROVA='2027-01-17';      // data da prova
const LIMITE='2027-01-10';     // última semana: revisões diárias, nada agendado depois disso
const INT=[1,3,7,15,30];       // intervalos em dias por nível (proposta do Metodo_de_Estudo.md)
const ORIGENS={
  recuperacao:{t:'Não lembrei',d:'Recuperação: o conteúdo não veio à memória. Revise com flashcards e questões espaçadas, nunca relendo.'},
  interferencia:{t:'Confundi com outra regra',d:'Interferência: estude as duas regras lado a lado e treine em rodadas intercaladas.'},
  leitura:{t:'Li rápido demais',d:'Sistema 1: uma palavra de alcance passou batida. Releia o comando inteiro e marque as travas antes de julgar.'},
  compreensao:{t:'Não entendi o conceito',d:'Compreensão: explique com suas palavras e crie um exemplo próprio antes de voltar às questões.'}
};
const pad=n=>String(n).padStart(2,'0');
const dia=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
function hoje(){return dia(new Date())}
function addDias(ds,n){const [y,m,d]=ds.split('-').map(Number);return dia(new Date(y,m-1,d+n))}
function difDias(a,b){const pa=a.split('-').map(Number),pb=b.split('-').map(Number);return Math.round((Date.UTC(pb[0],pb[1]-1,pb[2])-Date.UTC(pa[0],pa[1]-1,pa[2]))/864e5)}
function diaDe(iso){const d=new Date(iso);return isNaN(d)?hoje():dia(d)}
function ddmm(ds){const p=ds.split('-');return p[2]+'/'+p[1]}
function nivelDe(r){return Number.isInteger(r.nivel)?r.nivel:(r.noCaderno?0:1)}
function proxDe(r){
  if(!r||!r.tentativas) return null;
  const base=diaDe(r.atualizadoEm||new Date().toISOString());
  const salvo=r.proxRevisao||addDias(base,r.noCaderno?1:3);
  if(r.noCaderno) return salvo;
  /* acertos fora do caderno: no mínimo 7 dias (certeza) ou 3 (dúvida) depois da última resposta.
     Vale também para respostas antigas, sem alterá-las no banco. */
  const min=agendarDias(base,r.conf===3?7:3);
  return min>salvo?min:salvo;
}
function agendarDias(d,n){
  if(d>=LIMITE) return addDias(d,1);
  const p=addDias(d,Math.min(n,teto(d)));
  return p>LIMITE?LIMITE:p;
}
const LIMITE_DIA=50;   // revisões de questões por dia (06/11/2026: 50, o mesmo teto dos cartões); erros primeiro
/* teto: nenhum intervalo passa de 20% dos dias que faltam para a prova (curva de Cepeda et al., 2008) */
function teto(d){return Math.max(1,Math.floor(difDias(d,PROVA)*0.2))}
function agendar(d,nivel){
  if(d>=LIMITE) return addDias(d,1);
  const n=Math.min(INT[Math.max(0,Math.min(nivel,INT.length-1))],teto(d));
  const p=addDias(d,n);
  return p>LIMITE?LIMITE:p;
}

/* palavras de alcance (treino do Sistema 2): destacadas só depois da resposta */
const TRAVAS=new RegExp('(?<![\\p{L}])(apenas|somente|só|sempre|nunca|jamais|exclusivamente|unicamente|necessariamente|obrigatoriamente|todos|todas|todo|toda|nenhum|nenhuma|qualquer|exceto|salvo|vedad[oa]s?|privativ[oa]s?|privativamente|independentemente|em regra|integralmente|totalmente|em nenhuma hipótese)(?![\\p{L}])','giu');
function marcarTravas(txt){return esc(txt).replace(TRAVAS,'<mark class="trava">$1</mark>')}
function temTravas(q){TRAVAS.lastIndex=0;const t=TRAVAS.test(String(q.enunciado||''));TRAVAS.lastIndex=0;return t}

/* ---------- escrita serial ---------- */
let chain=Promise.resolve();
function enqueue(fn){
  chain=chain.then(fn).catch(err=>{
    const code=err&&err.code;
    toast(code==='quota_exceeded'?'O espaço do caderno encheu. Peça ao Claude para arquivar rodadas antigas.':
      code==='invalid_argument'?'Esta conta não pode gravar neste caderno.':
      'Não foi possível salvar agora. Sua próxima resposta tentará de novo.');
  });
  return chain;
}
let toastT;
function toast(msg){const t=$('#toast');t.textContent=msg;t.hidden=false;clearTimeout(toastT);toastT=setTimeout(()=>t.hidden=true,3800)}

/* ---------- dados derivados ---------- */
/* uma questão errada (ou deixada em branco) uma vez fica contada como erro: acertos posteriores não apagam o erro (regra do Lucas, 02/11/2026) */
function jaErrou(r){return (r.erros||0)>0||(r.brancos||0)>0||(r.hist||[]).some(h=>!h.ok)}
/* capítulos que repetem erros de simulado (SIM-…) ficam fora dos percentuais: os itens continuam no caderno de erros (pedido do Lucas, 05/11/2026) */
const foraCalc=cap=>/^SIM/i.test(String(cap||''));
/* itens marcados com foraNivel (acima do nível do edital do cargo 11) ficam fora de percentuais, revisão espaçada e simulado (06/11/2026) */
const foraQ=q=>!!q&&(foraCalc(q.cap)||!!q.foraNivel);
const foraQid=qid=>foraQ(S.q.get(qid));
function caps(){
  const m=new Map(), h=hoje();
  for(const q of S.q.values()){ if(!m.has(q.cap)) m.set(q.cap,{cap:q.cap,nome:q.capNome||'',total:0,resp:0,okUlt:0,cad:0,devidos:0}); }
  for(const q of S.q.values()){
    const c=m.get(q.cap); c.total++;
    const r=S.r.get(q.id);
    if(r&&r.tentativas){ c.resp++; if(r.ultimaMarcada===q.gabarito&&!jaErrou(r)) c.okUlt++; if(r.noCaderno) c.cad++; const p=proxDe(r); if(p&&p<=h) c.devidos++; }
  }
  return [...m.values()].sort((a,b)=>{const ta=topicoDoCap(a.cap),tb=topicoDoCap(b.cap);
    return (ta?ta.materiaOrdem||99:999)-(tb?tb.materiaOrdem||99:999)||(ta?ta.ordem||0:0)-(tb?tb.ordem||0:0)||a.cap.localeCompare(b.cap,'pt',{numeric:true});});
}
/* tópico do edital ligado a um capítulo do Caderno (o de menor ordem, se houver mais de um) */
function topicoDoCap(cap){let best=null;for(const t of S.ed.values()) if((t.caps||[]).includes(cap)&&(!best||(t.ordem||0)<(best.ordem||0))) best=t; return best}
function capNome(cap){for(const q of S.q.values()) if(q.cap===cap) return q.capNome||''; return ''}
function questoesDoCap(cap){return [...S.q.values()].filter(q=>q.cap===cap).sort((a,b)=>(a.ordem||0)-(b.ordem||0))}
function filaPara(cap,modo){
  let qs=questoesDoCap(cap);
  if(modo==='novos') qs=qs.filter(q=>!(S.r.get(q.id)?.tentativas));
  if(modo==='caderno') qs=qs.filter(q=>S.r.get(q.id)?.noCaderno);
  return qs.map(q=>q.id);
}
/* revisões vencidas, intercaladas: um item de cada capítulo por vez */
function devidas(){
  const h=hoje(), porCap=new Map();
  for(const r of S.r.values()){
    const q=S.q.get(r.qid); if(!q||q.foraNivel) continue;
    const p=proxDe(r); if(!p||p>h) continue;
    if(!porCap.has(q.cap)) porCap.set(q.cap,[]);
    porCap.get(q.cap).push({id:q.id,p,cad:!!r.noCaderno});
  }
  /* limite diário: erros do caderno primeiro, depois os acertos mais antigos; o que sobra fica para amanhã */
  const todas=[...porCap.values()].flat().sort((a,b)=>(b.cad-a.cad)||a.p.localeCompare(b.p));
  /* o limite é do dia: desconta o que já foi revisado hoje nas rodadas de revisão espaçada */
  const feitas=new Set(); for(const r of S.rodadas) if(r.modo==='revisao'&&diaDe(r.inicio)===h) for(const it of (r.itens||[])) feitas.add(it.qid);
  const lim=Math.max(0,LIMITE_DIA+(S.revExtra||0)-feitas.size);
  const escolhidas=new Set(todas.slice(0,lim).map(x=>x.id));
  const listas=[...porCap.values()].map(l=>l.filter(x=>escolhidas.has(x.id)).sort((a,b)=>(b.cad-a.cad)||a.p.localeCompare(b.p))).filter(l=>l.length);
  for(let i=listas.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[listas[i],listas[j]]=[listas[j],listas[i]]}
  const out=[]; let k=0, resto=true;
  while(resto){ resto=false; for(const l of listas){ if(k<l.length){ out.push(l[k].id); resto=true; } } k++; }
  const nCad=todas.filter(x=>x.cad&&escolhidas.has(x.id)).length;
  return {fila:out,caps:listas.length,atrasadas:todas.filter(x=>x.p<h&&escolhidas.has(x.id)).length,adiadas:Math.max(0,todas.length-lim),erros:nCad,feitasHoje:feitas.size};
}
function proximaData(){
  const h=hoje(); let min=null,n=0;
  for(const r of S.r.values()){ if(!S.q.has(r.qid)) continue; const p=proxDe(r); if(!p||p<=h) continue; if(!min||p<min){min=p;n=1} else if(p===min) n++; }
  return min?{d:min,n}:null;
}
function cadernoItens(){
  return [...S.r.values()].filter(r=>r.noCaderno&&S.q.has(r.qid))
    .map(r=>({r,q:S.q.get(r.qid)}))
    .sort((a,b)=>a.q.cap.localeCompare(b.q.cap,'pt',{numeric:true})||(a.q.ordem||0)-(b.q.ordem||0));
}
function textoHTML(q){
  const t=q&&q.textoId&&S.tx&&S.tx.get(q.textoId); if(!t) return '';
  return `<details class="why" open style="border-top:0;padding-top:0"><summary>Texto de apoio · ${esc(t.titulo||'')} <span class="ref">(${esc(t.itens||'')})</span></summary><div class="statement" style="font-size:16.5px;margin-top:8px">${String(t.texto||'').split(/\n\n+/).map(p=>`<p style="text-indent:1.5em">${esc(p)}</p>`).join('')}</div><p class="ref" style="text-align:right">${esc(t.fonte||'')}</p></details>`;
}
function statementHTML(q,travas){
  // "Situação hipotética: ... Assertiva: ..." vira dois blocos
  const f=travas?marcarTravas:esc;
  const t=String(q.enunciado||'');
  /* contexto antes da assertiva: situação hipotética, texto de apoio, dados de tabela ou proposição dada */
  const m=t.match(/^(Situação hipotética|Texto de apoio|Dados da tabela|Considere a proposição \S+):\s*([\s\S]*?)\s*Assertiva:\s*([\s\S]*)$/);
  if(m){ const lb=m[1].startsWith('Considere')?m[1].replace('Considere a ','').replace(/^p/,'P'):m[1];
    return `<span class="lbl">${esc(lb)}</span><p>${f(m[2])}</p><span class="lbl">Assertiva</span><p>${f(m[3])}</p>`; }
  return `<p>${f(t)}</p>`;
}
function rotuloCap(cap){return cap==='MIX'?'Revisão intercalada':cap==='PEG'?'Pegadinhas':'Cap. '+cap}
const multiCap=cap=>cap==='MIX'||cap==='PEG';

/* ---------- navegação ---------- */
/* 5 abas; Estudo agrupa Revisão, Pegadinhas e Conteúdo; Treinar inclui o caderno de erros; Desempenho inclui o Método */
const PAI={cartoes:'estudo',mapa:'estudo',revisao:'estudo',pegadinhas:'estudo',conteudo:'estudo',caderno:'treinar',metodo:'historico'};
const SUBS={estudo:[['revisao','Revisão ativa'],['pegadinhas','Pegadinhas'],['conteudo','Conteúdo']],treinar:[['treinar','Treinar'],['caderno','Caderno de erros']],historico:[['historico','Desempenho'],['metodo','Método']]};
function subnav(){
  const pai=PAI[S.view]||S.view, l=SUBS[pai]; if(!l) return '';
  const cnt={caderno:cadernoItens().length,pegadinhas:S.pg.size};
  return `<div class="seg subnav" role="group" aria-label="Seções">${l.map(([v,t])=>`<button data-sub="${v}" aria-pressed="${S.view===v}">${t}${cnt[v]?` <span class="count${v==='caderno'?' hot':''}">${cnt[v]}</span>`:''}</button>`).join('')}</div>`;
}
function setView(v,push=true){
  if(v==='estudo') v=S.ultEstudo||'revisao';
  if(!VIEWS.includes(v)) v='treinar';
  S.view=v; if(PAI[v]==='estudo') S.ultEstudo=v;
  const pai=PAI[v]||v;
  for(const id of ['painel','edital','treinar','estudo','simulado','historico']){ const b=$('#tab-'+id); if(id===pai) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current'); }
  if(push){ try{ history.replaceState(null,'','#'+v);}catch(e){} }
  render(true);
}
document.querySelectorAll('nav.tabs button').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
/* tema: automático → escuro → claro (preferência guardada neste navegador) */
(function(){const ORD=['auto','dark','light'],LBL={auto:'Tema: automático',dark:'Tema: escuro',light:'Tema: claro'};let t='auto';try{t=localStorage.getItem('qb-tema')||'auto'}catch(e){}
  const ap=()=>{if(t==='auto')document.documentElement.removeAttribute('data-theme');else document.documentElement.setAttribute('data-theme',t);const b=$('#theme-b');if(b)b.textContent=LBL[t]};
  ap();$('#theme-b').addEventListener('click',()=>{t=ORD[(ORD.indexOf(t)+1)%3];try{localStorage.setItem('qb-tema',t)}catch(e){}ap()});})();

/* ---------- render ---------- */
function render(force){
  const ae=document.activeElement;
  if(!force && ae && ae.dataset && (ae.dataset.nota||ae.dataset.cresp)){ S.pendingRender=true; updateCounts(); return; }
  S.pendingRender=false;
  updateCounts();
  const main=$('#main');
  if(S.view==='metodo'){ main.innerHTML=`<div class="wrap" style="gap:14px">${subnav()}${viewMetodo()}</div>`; wire(); return; }
  if(S.dbState==='loading'){ main.innerHTML=`<div class="notice">Abrindo o caderno…</div>`; return; }
  if(S.dbState==='missing'){ main.innerHTML=`<div class="notice"><strong>Não foi possível abrir o banco de respostas nesta visualização.</strong> Abra este caderno pelo claude.ai com a sua conta para treinar e guardar as respostas.</div>`; return; }
  if(!S.qLoaded){ main.innerHTML=`<div class="notice">Carregando as questões…</div>`; return; }
  if(S.q.size===0){ main.innerHTML=`<div class="notice"><strong>Nenhuma questão carregada ainda.</strong> Peça ao Claude, na conversa, para adicionar os itens de um capítulo. Eles aparecem aqui automaticamente.</div>`; return; }
  if(S.view==='painel') main.innerHTML=viewPainel();
  else if(S.view==='edital') main.innerHTML=viewEdital();
  else if(S.view==='revisao') main.innerHTML=viewRevisao();
  else if(S.view==='mapa') main.innerHTML=viewMapa();
  else if(S.view==='cartoes') main.innerHTML=viewCartoes();
  else if(S.view==='pegadinhas') main.innerHTML=viewPegadinhas();
  else if(S.view==='conteudo') main.innerHTML=viewConteudo();
  else if(S.view==='treinar') main.innerHTML=S.round?(S.round.fim?viewFim():viewItem()):viewSetup();
  else if(S.view==='caderno') main.innerHTML=viewCaderno();
  else if(S.view==='simulado'){ main.innerHTML=viewSimulado(); wireSim(); return; }
  else main.innerHTML=viewHistorico();
  const sn=subnav(); if(sn&&!(S.view==='treinar'&&S.round)) main.insertAdjacentHTML('afterbegin',`<div class="wrap" style="margin-bottom:14px">${sn}</div>`);
  wire();
}
function updateCounts(){
  const d=S.qLoaded?devidas().fila.length:0, eh=$('#cnt-hoje');
  eh.textContent=d; eh.classList.toggle('hot',d>0);
  const f=difDias(hoje(),PROVA), cd=$('#countdown');
  cd.innerHTML=f>0?`Prova em 17/01/2027 · <b>${f}</b> ${f===1?'dia':'dias'}`:(f===0?'<b>Prova hoje</b>':'Prova realizada');
}

function viewSetup(){
  const cs=caps();
  if(!S.cap||!S.capEscolhido||!cs.find(c=>c.cap===S.cap)) S.cap=cs[0].cap;
  const nNovos=filaPara(S.cap,'novos').length, nTodos=filaPara(S.cap,'todos').length, nCad=filaPara(S.cap,'caderno').length;
  if(S.modo==='novos'&&!nNovos) S.modo='todos';
  if(S.modo==='caderno'&&!nCad) S.modo='todos';
  const n=filaPara(S.cap,S.modo).length;
  const dv=devidas(), px=proximaData();
  const due=dv.fila.length?`<section class="due" aria-label="Revisão espaçada de hoje">
      <div class="due-body"><h2 class="section-title">Revisão espaçada de hoje</h2>
        <div class="due-n"><span class="mono">${dv.fila.length}</span> ${dv.fila.length===1?'item':'itens'} para hoje</div>
        <div class="due-meta">${dv.erros} do caderno de erros e ${dv.fila.length-dv.erros} ${dv.fila.length-dv.erros===1?'acerto':'acertos'} para confirmar · ${dv.caps} ${dv.caps===1?'capítulo':'capítulos'}, intercalados.${dv.feitasHoje?` Você já revisou ${dv.feitasHoje} hoje.`:''}${dv.adiadas?` Limite de ${LIMITE_DIA} por dia: ${dv.adiadas} ${dv.adiadas===1?'item fica':'itens ficam'} para os próximos dias.`:''}</div></div>
      <button class="btn" id="start-rev">Começar revisão</button></section>`
    :`<section class="due calm" aria-label="Revisão espaçada"><div class="due-body"><h2 class="section-title">Revisão espaçada</h2>
        <div class="due-meta">${dv.feitasHoje?`Meta de hoje cumprida: <b class="mono">${dv.feitasHoje}</b> revisadas.${dv.adiadas?` ${dv.adiadas} ${dv.adiadas===1?'item vencido fica':'itens vencidos ficam'} para os próximos dias.`:''}</div>${dv.adiadas?'<button class="btn ghost small" id="rev-mais" style="margin-top:6px;align-self:flex-start">Revisar mais 20 (opcional)</button>':''}<div class="due-meta" hidden>`:'Nada vence hoje.'}${px?` Próxima revisão em <b class="mono">${ddmm(px.d)}</b>: ${px.n} ${px.n===1?'item':'itens'}.`:' Responda itens para montar a agenda.'}</div></div></section>`;
  const card=c=>{
    const ok=c.total?c.okUlt/c.total*100:0, bad=c.total?(c.resp-c.okUlt)/c.total*100:0;
    const t=topicoDoCap(c.cap);
    const nome=t?String(c.nome||'').replace(/^[^·]*·\s*/,''):c.nome;
    return `<button class="cap" data-cap="${esc(c.cap)}" aria-pressed="${c.cap===S.cap}">
      <span class="cn">${t?`Edital ${esc(t.num)} · `:''}Capítulo ${esc(c.cap)}</span>
      <span class="ct">${esc(nome)}</span>
      <span class="bar" aria-hidden="true"><i style="width:${ok}%;background:var(--certo)"></i><i style="width:${bad}%;background:var(--errado)"></i></span>
      <span class="meta">${c.resp}/${c.total} feitas · ${c.cad} no caderno${c.devidos?` · ${c.devidos} hoje`:''}</span>
    </button>`};
  /* agrupa por matéria, como na aba Edital: P1 e P2, matérias e capítulos na ordem do edital */
  const grupos=new Map();
  for(const c of cs){
    const t=topicoDoCap(c.cap);
    const k=t?t.sigla:'_outros';
    if(!grupos.has(k)) grupos.set(k,{k,nome:t?t.materia:'Outros capítulos',prova:t?t.prova:'',cs:[]});
    grupos.get(k).cs.push(c);
  }
  const gSel=[...grupos.values()].find(g=>g.cs.some(c=>c.cap===S.cap));
  if(gSel&&S.edLoaded&&!S.trIni){ S.trIni=true; S.abertos.add('tr:'+gSel.k); }
  const grupoHTML=g=>{
    const tot=g.cs.reduce((a,c)=>a+c.total,0), resp=g.cs.reduce((a,c)=>a+c.resp,0), ok=g.cs.reduce((a,c)=>a+c.okUlt,0), dev=g.cs.reduce((a,c)=>a+c.devidos,0);
    const sel=g.cs.some(c=>c.cap===S.cap);
    return `<details class="mat-g" data-grupo="tr:${esc(g.k)}" ${S.abertos.has('tr:'+g.k)?'open':''}><summary><span class="gn">${esc(g.nome)}${sel?' <span class="mono" style="font-size:12px;color:var(--pen)">· selecionado</span>':''}</span><span class="sbar" aria-hidden="true">${tot?`<i style="width:${ok/tot*100}%;background:var(--certo)"></i><i style="width:${(resp-ok)/tot*100}%;background:var(--errado)"></i>`:''}</span><span class="mono" style="font-size:12.5px;color:var(--muted)">${g.cs.length} ${g.cs.length===1?'capítulo':'capítulos'} · ${resp}/${tot}${dev?` · ${dev} hoje`:''}</span></summary>
      <div class="caps" style="padding:0 16px 16px">${g.cs.map(card).join('')}</div></details>`};
  let capCards='';
  for(const p of ['P1','P2','']){
    const gp=[...grupos.values()].filter(g=>g.prova===p);
    if(!gp.length) continue;
    capCards+=`<h3 class="prova-h" style="margin:4px 0 0;background:none;border:0;padding:0">${esc(PROVAS[p]||'Sem tópico do edital')}</h3>${gp.map(grupoHTML).join('')}`;
  }
  const mode=(id,title,desc,count)=>`<label class="mode${count?'':' disabled'}">
      <input type="radio" name="modo" id="modo-${id}" value="${id}" ${S.modo===id?'checked':''} ${count?'':'disabled'}>
      <div><b>${title}</b> <span class="mono">(${count})</span><br><span>${desc}</span></div></label>`;
  return `<div class="wrap" style="gap:18px">
    ${due}
    <h2 class="section-title">Capítulo · por matéria, na ordem do edital</h2>
    <div class="row"><button class="btn ghost small" id="tr-abrir">Abrir tudo</button><button class="btn ghost small" id="tr-fechar">Fechar tudo</button></div>
    <div style="display:flex;flex-direction:column;gap:10px">${capCards}</div>
    <h2 class="section-title">O que treinar</h2>
    <div class="modes">
      ${mode('novos','Só as que ainda não fiz','Itens do capítulo que você nunca respondeu.',nNovos)}
      ${mode('todos','Todas do capítulo','Refaz o capítulo inteiro. Cada resposta atualiza o caderno e a agenda.',nTodos)}
      ${mode('caderno','Revisar o caderno de erros','Só os itens que você errou, deixou em branco ou acertou no chute. Dois acertos seguidos com segurança tiram o item do caderno.',nCad)}
    </div>
    <div class="row">
      <button class="btn" id="start" ${n?'':'disabled'}>Começar rodada · ${n} ${n===1?'item':'itens'}</button>
      <label class="check"><input type="checkbox" id="shuffle" ${S.shuffle?'checked':''}> Embaralhar a ordem</label>
    </div>
  </div>`;
}

function emRep(rd){return rd.rep.ini!==null&&rd.idx>=rd.rep.ini}
function placar(rd){
  const liq=rd.certos-rd.errados;
  const prog=emRep(rd)?`Repescagem ${rd.idx-rd.rep.ini+1} de ${rd.fila.length-rd.rep.ini} · não conta no placar`:`Item ${Math.min(rd.idx+1,rd.fila.length)} de ${rd.fila.length} · ${esc(rotuloCap(rd.cap))}`;
  return `<div class="scorebar">
    <span class="progress">${prog}</span>
    <span class="score"><span class="c">C ${rd.certos}</span><span class="e">E ${rd.errados}</span><span class="b">B ${rd.brancos}</span><span class="n">Nota líquida ${liq}</span></span>
  </div>`;
}
function chipsOrigem(qid,atual){
  const o=atual&&ORIGENS[atual];
  return `<div class="origem"><span class="origem-q">De onde veio o erro?</span>
    <div class="chips">${Object.entries(ORIGENS).map(([k,v])=>`<button class="chip" data-origem="${esc(qid)}" data-val="${k}" aria-pressed="${atual===k}">${v.t}</button>`).join('')}</div>
    ${o?`<p class="origem-hint">${esc(o.d)}</p>`:''}</div>`;
}
function viewItem(){
  const rd=S.round, q=S.q.get(rd.fila[rd.idx]);
  if(!q){ rd.idx++; if(rd.idx>=rd.fila.length){ finalizar(); return viewFim(); } return viewItem(); }
  const a=rd.atual, pend=rd.pend;
  const bub=(L)=>{
    let cls='bubble'; if((a&&a.marcada===L)||(pend&&pend.marcada===L)) cls+=' picked'; if(a&&q.gabarito===L) cls+=' key';
    return `<button class="${cls}" data-ans="${L}" ${a?'disabled':''} aria-label="${LETRA[L]}">${L}</button>`};
  let mid='';
  if(pend){
    mid=`<div class="conf" role="group" aria-label="Confiança"><span class="conf-q">Você marcou ${LETRA[pend.marcada]}. Antes de ver o gabarito: qual a sua confiança?</span>
      ${pend.marcada==='E'?`<div class="note"><label for="corr-txt">Como ficaria certo? (opcional) Reescreva a assertiva corrigida antes de ver o gabarito.</label><textarea id="corr-txt" style="min-height:48px" placeholder="Ex.: a competência é privativa, e não exclusiva…">${esc(rd.corr||'')}</textarea></div>`:''}
      <div class="conf-opts">${[1,2,3].map(c=>`<button data-conf="${c}"><span class="mono">${c}</span>${CONF[c]}</button>`).join('')}</div>
      <span class="kbd">teclas 1 · 2 · 3 · Esc troca a resposta</span></div>`;
  }
  if(a&&a.rep){
    const kind=a.marcada==='B'?'dub':(a.acertou?'ok':'bad');
    const vt=a.marcada==='B'?`Em branco. O gabarito é ${LETRA[q.gabarito]}.`:(a.acertou?`Acertou na repescagem. Gabarito: ${LETRA[q.gabarito]}.`:`Errou de novo. O gabarito é ${LETRA[q.gabarito]}.`);
    mid=`<div class="verdict ${kind}"><span class="vt">${vt}</span><p>${esc(q.comentario)}</p>
      <span class="ref">A repescagem fecha a sessão com uma recuperação correta e não muda a agenda: o item volta na revisão espaçada.</span></div>`;
  } else if(a){
    const r=S.r.get(q.id)||{};
    const kind=a.marcada==='B'?'dub':(a.acertou?(a.conf===1?'dub':'ok'):'bad');
    const vt=a.marcada==='B'?`Em branco. O gabarito é ${LETRA[q.gabarito]}.`:(a.acertou?`Acertou. Gabarito: ${LETRA[q.gabarito]}.`:`Errou. O gabarito é ${LETRA[q.gabarito]}.`);
    let calib='';
    if(a.marcada!=='B'&&!a.acertou&&a.conf===3) calib=`<span class="calib alert">Erro com certeza: na prova, você marcaria e perderia um ponto. Para aprender, é o melhor momento: erros cometidos com certeza são os que mais se corrigem depois do feedback. Leia o comentário com atenção.</span>`;
    else if(a.acertou&&a.conf===1) calib=`<span class="calib">Acerto no chute: o item foi para o caderno e só sai com dois acertos seguros.</span>`;
    else if(a.acertou&&a.conf===3) calib=`<span class="calib">Calibrado: certeza e acerto.</span>`;
    const foiCaderno=(kind!=='ok')?' Este item está no caderno de erros.':'';
    const prox=r.proxRevisao?` Próxima revisão em ${ddmm(r.proxRevisao)}.`:'';
    const precisaOrigem=exigeJust(a);
    const nj=(rd.just||'').trim().length;
    mid=`<div class="verdict ${kind}"><span class="vt">${vt}</span>${calib}${a.corr?`<span class="calib">Sua correção: <span style="font-weight:400;font-family:var(--read)">${esc(a.corr)}</span>${q.gabarito==='E'?' · Confira com o comentário se ela bate com a versão certa.':' · O item era Certo: a sua versão alterava o que já estava correto.'}</span>`:''}<p>${esc(q.comentario)}</p>
      ${temTravas(q)?`<span class="ref">Palavras de alcance destacadas no enunciado: confira se a assertiva generaliza ou restringe demais.</span>`:''}
      ${(()=>{const x=mecDe(q);return x&&MEC[x.m]?`<span class="calib">Mecanismo da banca: ${esc(x.m)} · ${esc(MEC[x.m].n)}.${x.v&&String(q.comentario||'').includes(x.v)?'':x.v?` Vacina: ${esc(x.v)}`:` ${esc(MEC[x.m].v)}`}</span>`:''})()}
      <span class="ref">${q.ref?('Ver '+esc(q.ref)+'.'):''}${esc(foiCaderno+prox)}</span>
      ${precisaOrigem?chipsOrigem(q.id,r.origem):''}
      ${precisaOrigem?`<div class="just"><label for="just-txt">${a.marcada!=='B'&&!a.acertou&&a.conf===3?'Erro com certeza: o que te deu certeza? Escreva o que te levou a marcar e qual é a regra certa, com as suas palavras.':`Justifique para seguir: por que você ${a.marcada==='B'?'deixou em branco':(a.acertou?'chutou':'errou')} e qual é a regra certa, com as suas palavras. Se puder, dê um exemplo seu.`}</label>
        <textarea id="just-txt" data-just="${esc(q.id)}" placeholder="Ex.: confundi competência exclusiva com privativa; a exclusiva não pode ser delegada porque…">${esc(rd.just||'')}</textarea>
        <span class="saved" id="just-cnt">${justMsg(nj,r.origem)}</span></div>`:''}</div>`;
  }
  const last=rd.idx===rd.fila.length-1;
  const vaiRep=last&&rd.rep.ini===null&&rd.rep.fila.length>0;
  const tag=(multiCap(rd.cap)||emRep(rd))?`Cap. ${q.cap} · ${q.tema||''}`:(q.tema||'');
  return `${placar(rd)}
  <article class="item" style="margin-top:16px">
    <div class="item-head"><span class="item-num">${emRep(rd)?'REPESCAGEM · ':''}ITEM ${String(q.ordem||'').padStart(2,'0')}</span><span class="tag">${esc(tag)}</span></div>
    ${textoHTML(q)}<div class="statement">${statementHTML(q,!!a)}</div>
    <div class="answers">${bub('C')}${bub('E')}
      <button class="blank${a&&a.marcada==='B'?' picked':''}" data-ans="B" ${a?'disabled':''}>Deixar em branco</button>
      ${a||pend?'':'<span class="kbd">teclas C · E · B</span>'}</div>
    ${mid}
  </article>
  <div class="next-row" style="margin-top:14px">
    <button class="btn ghost small" id="quit">Encerrar rodada</button>
    ${a?`<button class="btn" id="next" ${a.rep||!exigeJust(a)||justOk(rd,q.id)?'':'disabled'}>${vaiRep?`Ir para a repescagem (${rd.rep.fila.length})`:(last?'Ver resultado':'Próximo item')} <span class="kbd" style="color:inherit;opacity:.75">Enter</span></button>`:''}
  </div>`;
}
function viewFim(){
  const rd=S.round, liq=rd.certos-rd.errados, resp=rd.certos+rd.errados+rd.brancos;
  const foram=rd.itens.filter(i=>i.marcada!==i.gabarito||i.conf===1);
  const excesso=rd.itens.filter(i=>i.marcada!=='B'&&i.marcada!==i.gabarito&&i.conf===3).length;
  const mix=multiCap(rd.cap);
  const lista=foram.length?`<div class="tbl-wrap"><table><thead><tr><th>Item</th>${mix?'<th>Cap.</th>':''}<th>Tema</th><th>Você marcou</th><th>Gabarito</th><th>Confiança</th></tr></thead><tbody>
    ${foram.map(i=>{const q=S.q.get(i.qid)||{};return `<tr><td class="mono">${String(q.ordem||'').padStart(2,'0')}</td>${mix?`<td class="mono">${esc(q.cap||'')}</td>`:''}<td>${esc(q.tema||'')}</td><td class="${i.marcada==='B'?'':(i.marcada===i.gabarito?'pos':'neg')}">${LETRA[i.marcada]}</td><td>${LETRA[i.gabarito]}</td><td>${i.conf?CONF[i.conf]:'–'}</td></tr>`}).join('')}
    </tbody></table></div>`:`<div class="notice"><strong>Nenhum erro nem chute nesta rodada.</strong></div>`;
  return `<div class="wrap" style="gap:16px;margin-top:8px">
    <h2 class="section-title">Resultado da rodada · ${esc(rd.cap==='PEG'?rd.capNome:mix?'Revisão intercalada':'Capítulo '+rd.cap)}</h2>
    <div class="summary">
      <div class="stat c"><span class="v">${rd.certos}</span><span class="k">certos</span></div>
      <div class="stat e"><span class="v">${rd.errados}</span><span class="k">errados</span></div>
      <div class="stat b"><span class="v">${rd.brancos}</span><span class="k">em branco</span></div>
      <div class="stat"><span class="v ${liq<0?'neg':''}">${liq}</span><span class="k">nota líquida (C − E)</span></div>
    </div>
    <p class="rule">${resp} de ${rd.rep.ini===null?rd.fila.length:rd.rep.ini} itens respondidos. Aproveitamento líquido: ${resp?fmtPct(liq/resp):'–'}.${excesso?` ${excesso} ${excesso===1?'erro':'erros'} com certeza: leia esses comentários de novo e escreva a regra no caderno.`:''} Cada item já tem a próxima revisão marcada na agenda.</p>
    ${rd.rep.res.length?`<p class="rule">Repescagem: ${rd.rep.res.filter(x=>x.ok).length} de ${rd.rep.res.length} certos no fim da rodada. Ela não entra na nota nem muda a agenda.</p>`:''}
    <h2 class="section-title">Foram para o caderno</h2>
    ${lista}
    <div class="row">
      <button class="btn" id="go-caderno">Abrir o caderno de erros</button>
      <button class="btn ghost" id="again">Nova rodada</button>
    </div>
  </div>`;
}

function viewCaderno(){
  const its=cadernoItens();
  if(!its.length) return `<div class="notice" style="margin-top:4px"><strong>Seu caderno está vazio.</strong> Todo item que você errar, deixar em branco ou acertar no chute entra aqui, com o comentário e espaço para anotar por que errou. Ele sai depois de dois acertos seguros seguidos.</div>`;
  /* agrupado como o Edital: prova → matéria → assunto (tópico do edital) → itens (pedido do Lucas, 05/11/2026) */
  const mats=new Map();
  for(const it of its){
    const t=topicoDoCap(it.q.cap);
    const mk=t?t.sigla:'_outros';
    if(!mats.has(mk)) mats.set(mk,{k:mk,nome:t?t.materia:'Outros capítulos',prova:t?t.prova:'',ord:t?(t.materiaOrdem||99):999,tops:new Map()});
    const tk=t?t.id:'cap:'+it.q.cap;
    const m=mats.get(mk);
    if(!m.tops.has(tk)) m.tops.set(tk,{k:tk,num:t?t.num:'',tit:t?t.titulo:(it.q.capNome||it.q.cap),ord:t?(t.ordem||0):9999,caps:new Set(),its:[]});
    const g=m.tops.get(tk); g.caps.add(it.q.cap); g.its.push(it);
  }
  const hj=hoje();
  const cntHoje=l=>l.filter(({r})=>{const p=proxDe(r);return p&&p<=hj}).length;
  let html=`<p class="rule">${its.length} ${its.length===1?'item':'itens'} no caderno, agrupados por matéria e assunto do edital. Abra a matéria e depois o assunto; "Revisar" faz uma rodada só com os erros daquele capítulo.</p>`;
  for(const pv of ['P1','P2','']){
    const ms=[...mats.values()].filter(m=>m.prova===pv).sort((x,y)=>x.ord-y.ord||x.nome.localeCompare(y.nome));
    if(!ms.length) continue;
    html+=`<h3 class="prova-h" style="margin:4px 0 0;background:none;border:0;padding:0">${esc(PROVAS[pv]||'Sem tópico do edital')}</h3>`;
    for(const m of ms){
      const tops=[...m.tops.values()].sort((x,y)=>x.ord-y.ord||String(x.num).localeCompare(String(y.num),'pt',{numeric:true}));
      const n=tops.reduce((a,t)=>a+t.its.length,0), nh=tops.reduce((a,t)=>a+cntHoje(t.its),0);
      html+=`<details class="mat-g" data-grupo="cd:${esc(m.k)}" ${S.abertos.has('cd:'+m.k)?'open':''}><summary><span class="gn">${esc(m.nome)}</span><span></span><span class="mono" style="font-size:12.5px;color:var(--muted)">${n} ${n===1?'item':'itens'} · ${tops.length} ${tops.length===1?'assunto':'assuntos'}${nh?` · ${nh} hoje`:''}</span></summary>`;
      for(const tp of tops){
        const gk='cd:t:'+tp.k;
        html+=`<details class="rv-top" data-grupo="${esc(gk)}" ${S.abertos.has(gk)?'open':''}><summary><div class="t-h"><span class="t-num">${esc(tp.num||'')}</span><span class="t-tit">${esc(tp.tit||'')} <span class="mono" style="font-size:12px;color:var(--muted)">· ${tp.its.length} ${tp.its.length===1?'item':'itens'}</span></span></div></summary>
          <div class="acts">${[...tp.caps].map(c=>{const k=tp.its.filter(x=>x.q.cap===c).length;return `<button class="btn small" data-revisar="${esc(c)}">Revisar ${k} · cap. ${esc(c)}</button>`}).join('')}</div>`;
        html+=entradasCaderno(tp.its);
        html+=`</details>`;
      }
      html+=`</details>`;
    }
  }
  return `<div class="wrap" style="gap:14px">${html}</div>`;
}
function entradasCaderno(lista){
  let html='';
  {
    for(const {q,r} of lista){
      const dub=r.motivo==='branco'||r.motivo==='chute';
      const seq=r.acertosSeguidos||0;
      const prox=proxDe(r);
      const ult=r.motivo==='chute'?'<span class="pill b">Acertou no chute</span>':`<span class="pill ${r.ultimaMarcada==='B'?'b':(r.ultimaMarcada===q.gabarito?'c':'e')}">Última: ${LETRA[r.ultimaMarcada]||'–'}</span>`;
      html+=`<article class="entry${dub?' dub':''}">
        <div class="item-head"><span class="item-num">ITEM ${String(q.ordem||'').padStart(2,'0')}</span><span class="tag">${esc(q.tema||'')}</span></div>
        <div class="statement">${statementHTML(q,true)}</div>
        <div class="pills">
          ${ult}
          <span class="pill c">Gabarito: ${LETRA[q.gabarito]}</span>
          ${r.conf?`<span class="pill">Confiança: ${CONF[r.conf]}</span>`:''}
          <span class="pill">${r.erros||0} ${r.erros===1?'erro':'erros'} · ${r.brancos||0} em branco</span>
          <span class="pill">${seq}/2 acertos para sair</span>
          ${prox?`<span class="pill p">Revisão ${prox<=hoje()?'hoje':'em '+ddmm(prox)}</span>`:''}
        </div>
        ${chipsOrigem(q.id,r.origem)}
        <details class="why"><summary>Ver o gabarito comentado</summary><p>${esc(q.comentario)}</p>${q.ref?`<p class="ref">Ver ${esc(q.ref)}</p>`:''}</details>
        <div class="note"><label for="nota-${esc(q.id)}">Por que errei / o que lembrar</label>
          <textarea id="nota-${esc(q.id)}" data-nota="${esc(q.id)}" placeholder="Escreva a regra com as suas palavras e um exemplo próprio.">${esc(r.nota||'')}</textarea>
          <span class="saved" id="saved-${esc(q.id)}"></span></div>
        <div class="row"><button class="btn ghost small" data-tirar="${esc(q.id)}">Tirar do caderno</button></div>
      </article>`;
    }
  }
  return html;
}

function estatisticas(){
  let eSendoC=0,cSendoE=0,brancos=0;
  const conf={1:[0,0],2:[0,0],3:[0,0]};
  for(const r of S.r.values()){
    const q=S.q.get(r.qid); if(!q||foraQ(q)) continue;
    for(const h of (r.hist||[])){
      if(h.m==='B'){brancos++;continue}
      if(!h.ok){ if(h.m==='E') eSendoC++; else cSendoE++; }
      if(h.c&&conf[h.c]){ conf[h.c][0]++; if(h.ok) conf[h.c][1]++; }
    }
  }
  const origem={}; let semOrigem=0;
  for(const {r} of cadernoItens()){ if(r.motivo==='chute') continue; if(r.origem&&ORIGENS[r.origem]) origem[r.origem]=(origem[r.origem]||0)+1; else semOrigem++; }
  return {eSendoC,cSendoE,brancos,conf,origem,semOrigem};
}
/* evolução dos acertos por assunto (capítulo do Caderno), por dia, a partir dos itens de cada rodada */
function dadosEvolucao(){
  const m=new Map();
  for(const r of S.rodadas){
    const d0=diaDe(r.inicio);
    if((S.evoDe&&d0<S.evoDe)||(S.evoAte&&d0>S.evoAte)) continue;
    const d=bucketEvo(d0);
    for(const it of (r.itens||[])){
      const q=S.q.get(it.qid); const c0=q?q.cap:(!multiCap(r.cap)?r.cap:null); if(!c0||foraCalc(c0)||(q&&q.foraNivel)) continue;
      /* sem filtro: uma linha por matéria; com matéria escolhida: uma linha por assunto dela */
      const sig=materiaDoCap(c0)||'_';
      if(S.fEvo&&sig!==S.fEvo) continue;
      const cap=S.fEvo?c0:sig;
      const nome=S.fEvo?(q?q.capNome:(r.capNome||'')):(nomeMateria(sig));
      if(!m.has(cap)) m.set(cap,{cap,nome,dias:new Map()});
      const o=m.get(cap).dias.get(d)||{c:0,n:0}; o.n++; if(it.marcada===it.gabarito) o.c++; m.get(cap).dias.set(d,o);
    }
  }
  const ser=[...m.values()].map(s=>({...s,pts:[...s.dias.entries()].sort((a,b)=>a[0].localeCompare(b[0])).map(([d,o])=>({d,c:o.c,n:o.n}))}));
  ser.sort((a,b)=>a.pts[0].d.localeCompare(b.pts[0].d)||a.cap.localeCompare(b.cap,'pt',{numeric:true}));
  ser.forEach((s,i)=>{s.slot=i<8?i+1:0;});
  return ser;
}
/* período do gráfico: dia, semana (começa na segunda) ou mês */
function bucketEvo(d){
  if(S.evoPer==='s'){const [y,m,dd]=d.split('-').map(Number);const w=(new Date(y,m-1,dd).getDay()+6)%7;return addDias(d,-w)}
  if(S.evoPer==='m') return d.slice(0,8)+'01';
  return d;
}
const MESES=['jan','fev','mar','abr','mai','jun','jul','ago','set','out','nov','dez'];
function lblEvo(d){if(S.evoPer==='m') return MESES[+d.slice(5,7)-1]+'/'+d.slice(2,4); if(S.evoPer==='s') return 'sem. '+ddmm(d); return ddmm(d)}
function nomeMateria(sig){if(sig==='_') return 'Sem tópico do edital';const t=[...S.ed.values()].find(t=>t.sigla===sig);return t?t.materia:sig}
function materiasComRodadas(){const set=new Set();for(const r of S.rodadas)for(const it of (r.itens||[])){const q=S.q.get(it.qid);const c=q?q.cap:null;if(c){const s=materiaDoCap(c);if(s)set.add(s)}}return [...set]}
function materiaDoCap(cap){for(const t of S.ed.values()) if((t.caps||[]).includes(cap)) return t.sigla; return ''}
function viewEvolucao(){
  const todas=dadosEvolucao();
  if(!todas.length&&!(S.evoDe||S.evoAte)) return `<div class="notice">O gráfico aparece depois da primeira rodada.</div>`;
  const mats=materiasComRodadas();
  const ser=todas;
  const vis=ser.filter(s=>!S.evoOff.has(s.cap));
  const pct=S.evoModo==='p';
  const val=p=>pct?Math.round(p.c/p.n*100):p.c;
  const dias=[...new Set(vis.flatMap(s=>s.pts.map(p=>p.d)))].sort();
  const W=window.innerWidth<600?400:720,H=window.innerWidth<600?260:280,L=44,R=vis.length&&vis.length<=4?90:20,T=14,B=38;
  let d0=dias[0]||hoje(), d1=dias[dias.length-1]||hoje(); if(d0===d1){d0=addDias(d0,-1);d1=addDias(d1,1);}
  const span=Math.max(1,difDias(d0,d1));
  const x=d=>L+(W-L-R)*difDias(d0,d)/span;
  const maxV=pct?100:Math.max(5,...vis.flatMap(s=>s.pts.map(val)));
  const passo=pct?25:Math.max(1,Math.ceil(maxV/4/5)*5);
  const topo=pct?100:Math.ceil(maxV/passo)*passo;
  const y=v=>T+(H-T-B)*(1-v/topo);
  let g='';
  for(let v=0;v<=topo;v+=passo) g+=`<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" class="evo-grid"/><text x="${L-8}" y="${y(v)+4}" class="evo-ax" text-anchor="end">${v}${pct?'%':''}</text>`;
  const nT=Math.min(6,span+1);
  const ticks=dias.length<=8?dias:[...Array(nT)].map((_,i)=>dias[Math.round((dias.length-1)*i/Math.max(1,nT-1))]);
  for(const d of ticks) g+=`<text x="${x(d)}" y="${H-B+20}" class="evo-ax" text-anchor="middle">${lblEvo(d)}</text>`;
  const cor=s=>s.slot?`var(--s${s.slot})`:'var(--muted)';
  let linhas='',pontos='',rot='';
  for(const s of vis){
    const ps=s.pts;
    if(ps.length>1) linhas+=`<path d="${ps.map((p,i)=>(i?'L':'M')+x(p.d).toFixed(1)+' '+y(val(p)).toFixed(1)).join(' ')}" fill="none" stroke="${cor(s)}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" ${s.slot?'':'stroke-dasharray="5 4"'}/>`;
    for(const p of ps) pontos+=`<circle cx="${x(p.d)}" cy="${y(val(p))}" r="4.5" fill="${cor(s)}" class="evo-pt"/>`;
    if(vis.length<=4){const p=ps[ps.length-1];rot+=`<text x="${x(p.d)+10}" y="${y(val(p))+4}" class="evo-lb">${esc(S.fEvo?s.cap:s.cap.toUpperCase())}</text>`;}
  }
  let hits='';
  dias.forEach((d,i)=>{
    const xa=i?(x(dias[i-1])+x(d))/2:L, xb=i<dias.length-1?(x(d)+x(dias[i+1]))/2:W-R;
    const linhasDia=vis.map(s=>{const p=s.pts.find(p=>p.d===d);return p?`${S.fEvo?s.cap:s.nome}: ${p.c} de ${p.n} (${Math.round(p.c/p.n*100)}%)`:null}).filter(Boolean);
    const tip=lblEvo(d)+'\n'+linhasDia.join('\n');
    hits+=`<g class="evo-hit" tabindex="0" data-tip="${esc(tip)}" data-x="${x(d)}"><rect x="${xa}" y="${T}" width="${Math.max(1,xb-xa)}" height="${H-T-B}" fill="transparent"/><line x1="${x(d)}" x2="${x(d)}" y1="${T}" y2="${H-B}" class="evo-cross"/><title>${esc(tip)}</title></g>`;
  });
  const leg=ser.map(s=>`<button class="evo-chip" data-evo="${esc(s.cap)}" aria-pressed="${!S.evoOff.has(s.cap)}"><i style="background:${cor(s)}"></i>${S.fEvo?`${esc(s.cap)} <span>${esc((s.nome||'').split('·').slice(-1)[0].trim())}</span>`:esc(s.nome)}</button>`).join('');
  const linhasTab=ser.flatMap(s=>s.pts.map(p=>`<tr><td>${esc(S.fEvo?s.cap:s.nome)}</td><td class="mono">${lblEvo(p.d)}</td><td class="num">${p.c}</td><td class="num">${p.n}</td><td class="num">${fmtPct(p.c/p.n)}</td></tr>`)).join('');
  return `<div class="evo">
    <div class="filters">
      <select id="f-evo" aria-label="Matéria do gráfico"><option value="">Por matéria</option>${mats.map(s=>`<option value="${esc(s)}" ${S.fEvo===s?'selected':''}>Assuntos de ${esc(nomeMateria(s))}</option>`).join('')}</select>
      <div class="seg" role="group" aria-label="Período">${[['d','Dia'],['s','Semana'],['m','Mês']].map(([k,t])=>`<button data-evoper="${k}" aria-pressed="${S.evoPer===k}">${t}</button>`).join('')}</div>
      <label class="check">De <input type="date" id="evo-de" value="${esc(S.evoDe)}"></label><label class="check">Até <input type="date" id="evo-ate" value="${esc(S.evoAte)}"></label>${S.evoDe||S.evoAte?'<button class="lnk" id="evo-limpa">Todo o período</button>':''}
      <div class="seg" role="group" aria-label="Medida"><button data-evomodo="n" aria-pressed="${!pct}">Nº de acertos</button><button data-evomodo="p" aria-pressed="${pct}">% de acerto</button></div>
    </div>
    <div class="evo-legend">${leg}</div>
    <div class="evo-box"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${pct?'Percentual':'Número'} de acertos por dia, por assunto">${g}${linhas}${pontos}${rot}${hits}</svg><div class="evo-tip" id="evo-tip" hidden></div></div>
    ${dias.length<2?`<p class="rule">Só há respostas em ${{d:'um dia',s:'uma semana',m:'um mês'}[S.evoPer]} neste período. As linhas aparecem a partir do segundo.</p>`:''}
    <p class="rule">${S.fEvo?'Uma linha por assunto da matéria.':'Uma linha por matéria. Escolha uma matéria acima para ver os assuntos dela.'} Cada ponto soma os acertos do ${{d:'dia',s:'semana',m:'mês'}[S.evoPer]} em todas as rodadas; toque na legenda para esconder uma linha.</p>
    <details class="why"><summary>Ver em tabela</summary><div class="tbl-wrap" style="margin-top:8px"><table class="narrow"><thead><tr><th>${S.fEvo?'Assunto':'Matéria'}</th><th>${{d:'Dia',s:'Semana',m:'Mês'}[S.evoPer]}</th><th class="num">Acertos</th><th class="num">Itens</th><th class="num">%</th></tr></thead><tbody>${linhasTab}</tbody></table></div></details>
  </div>`;
}
function viewHistorico(){
  const cs=caps(), st=estatisticas(), h=hoje();
  const capRows=cs.map(c=>`<tr><td>Cap. ${esc(c.cap)} · ${esc(c.nome)}</td><td class="num">${c.resp}/${c.total}</td><td class="num">${c.resp?fmtPct(c.okUlt/c.resp):'–'}</td><td class="num">${c.cad}</td><td class="num">${c.devidos}</td></tr>`).join('');
  const rds=S.rodadas.filter(r=>(r.certos+r.errados+r.brancos)>0);
  const rdRows=rds.map(r=>{const liq=r.certos-r.errados; const d=new Date(r.inicio);
    return `<tr><td class="mono">${isNaN(d)?'–':d.toLocaleDateString('pt-BR')+' '+d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</td><td>${r.cap==='MIX'?'Intercalada':r.cap==='PEG'?esc(r.capNome||'Pegadinhas'):'Cap. '+esc(r.cap)}</td><td>${esc({novos:'Inéditas',todos:'Capítulo todo',caderno:'Revisão do caderno',revisao:'Revisão espaçada',pegadinhas:'Pegadinhas'}[r.modo]||r.modo)}</td>
      <td class="num pos">${r.certos}</td><td class="num neg">${r.errados}</td><td class="num">${r.brancos}</td><td class="num ${liq<0?'neg':''}">${liq}</td><td class="num">${fmtPct(r.certos/(r.certos+r.errados+r.brancos))}</td></tr>`}).join('');

  // direção dos erros (Rápido e Devagar: qual impulso do Sistema 1 está pesando)
  const tot=st.eSendoC+st.cSendoE;
  let leitura='';
  if(tot>=4){
    if(st.eSendoC>=st.cSendoE*1.5) leitura=`<b>Você tende a desconfiar de itens corretos.</b> ${st.eSendoC} dos ${tot} erros foram marcar Errado num item Certo. Antes de marcar E, aponte a palavra ou o trecho exato que torna a assertiva falsa. Se não encontrar, a assertiva provavelmente está certa.`;
    else if(st.cSendoE>=st.eSendoC*1.5) leitura=`<b>Você tende a aceitar itens errados.</b> ${st.cSendoE} dos ${tot} erros foram marcar Certo num item Errado. A assertiva parece familiar e o Sistema 1 aprova. Procure a palavra que generaliza, restringe ou troca um conceito.`;
    else leitura=`<b>Seus erros se dividem entre os dois lados</b> (${st.eSendoC} marcando E num item C, ${st.cSendoE} marcando C num item E). O problema é mais de conteúdo do que de tendência na leitura.`;
  } else leitura='A leitura da tendência aparece depois de 4 erros registrados.';

  const confRows=[3,2,1].map(c=>{const [n,ok]=st.conf[c];const acc=n?ok/n:NaN;const ev=n?2*acc-1:NaN;
    const ganho=n?((ev>0?'+':ev<0?'−':'')+Math.abs(ev).toFixed(2).replace('.',',')):'–';
    const dec=!n?'–':(n<10?'Poucos dados (menos de 10)':(acc>0.5?'<span class="pos">Marcar</span>':'<span class="neg">Deixar em branco</span>'));
    return `<tr><td>${c} · ${CONF[c]}</td><td class="num">${n}</td><td class="num">${n?fmtPct(acc):'–'}</td><td class="num ${ev<0?'neg':''}">${ganho}</td><td>${dec}</td></tr>`}).join('');
  const temConf=[1,2,3].some(c=>st.conf[c][0]>0);

  const oRows=Object.entries(ORIGENS).map(([k,v])=>`<tr><td>${v.t}</td><td class="num">${st.origem[k]||0}</td></tr>`).join('')+`<tr><td>Sem marcação</td><td class="num">${st.semOrigem}</td></tr>`;

  // agenda dos próximos 14 dias (vencidas somadas a hoje)
  const dias=[...Array(14)].map((_,i)=>addDias(h,i)), cnt=dias.map(()=>0);
  for(const r of S.r.values()){ if(!S.q.has(r.qid)) continue; const p=proxDe(r); if(!p) continue; const i=p<=h?0:difDias(h,p); if(i>=0&&i<14) cnt[i]++; }
  const mx=Math.max(1,...cnt);
  const sem=['dom','seg','ter','qua','qui','sex','sáb'];
  const agenda=dias.map((d,i)=>{const [y,m,dd]=d.split('-').map(Number);const w=sem[new Date(y,m-1,dd).getDay()];
    return `<div class="day${i===0?' today':''}"><span class="n">${cnt[i]||''}</span><span class="col"><i style="height:${cnt[i]/mx*100}%"></i></span><span class="d">${i===0?'hoje':w}<br>${ddmm(d)}</span></div>`}).join('');

  /* questões respondidas: total, por matéria e por assunto */
  const gm=new Map();
  for(const c of cs){ if(foraCalc(c.cap)) continue; const t=topicoDoCap(c.cap), k=t?t.sigla:'_';
    if(!gm.has(k)) gm.set(k,{k,nome:t?t.materia:'Sem tópico do edital',total:0,resp:0,ok:0,cs:[]});
    const g=gm.get(k); g.total+=c.total; g.resp+=c.resp; g.ok+=c.okUlt; g.cs.push(c); }
  const T={total:0,resp:0,ok:0}; for(const g of gm.values()){T.total+=g.total;T.resp+=g.resp;T.ok+=g.ok}
  const cel=o=>`<td class="num">${o.resp}<span style="color:var(--muted)">/${o.total}</span></td><td class="num">${fmtPct(o.resp/o.total)}</td><td class="num">${o.ok}</td><td class="num ${o.resp&&o.ok/o.resp<0.5?'neg':''}">${o.resp?fmtPct(o.ok/o.resp):'–'}</td>`;
  const qrRows=[...gm.values()].map(g=>{const ab=S.abertos.has('qr:'+g.k);
    return `<tr class="qr-m" data-qr="${esc(g.k)}" tabindex="0"><td><b>${ab?'▾':'▸'} ${esc(g.nome)}</b></td>${cel(g)}</tr>`+
      (ab?g.cs.map(c=>`<tr class="qr-a"><td>${esc(c.cap)} · ${esc(String(c.nome||'').replace(/^[^·]*·\s*/,''))}</td>${cel({total:c.total,resp:c.resp,ok:c.okUlt})}</tr>`).join(''):'')}).join('');
  const respondidas=`<h2 class="section-title">Questões respondidas</h2>
    <div class="summary">
      <div class="stat"><span class="v">${T.resp}</span><span class="k">respondidas de ${T.total} no banco</span></div>
      <div class="stat"><span class="v">${fmtPct(T.resp/T.total)}</span><span class="k">do banco respondido</span></div>
      <div class="stat c"><span class="v">${T.ok}</span><span class="k">acertos</span></div>
      <div class="stat c"><span class="v">${T.resp?fmtPct(T.ok/T.resp):'–'}</span><span class="k">de acerto</span></div>
    </div>
    <div class="tbl-wrap"><table><thead><tr><th>Matéria · assunto</th><th class="num">Respondidas</th><th class="num">% do banco</th><th class="num">Acertos</th><th class="num">% acerto</th></tr></thead><tbody>${qrRows}
      <tr class="qr-m"><td><b>Total</b></td>${cel(T)}</tr></tbody></table></div>
    <p class="rule">Toque numa matéria para ver os assuntos. Cada questão conta uma vez. Questão que você já errou ou deixou em branco alguma vez fica contada como erro, mesmo que depois tenha acertado.</p>`;
  return `<div class="wrap" style="gap:16px">
    ${respondidas}
    <h2 class="section-title">Agenda de revisões · próximos 14 dias</h2>
    <div class="agenda-wrap"><div class="agenda" role="img" aria-label="Itens a revisar por dia">${agenda}</div></div>
    <p class="rule">Intervalos: 1, 3, 7, 15 e 30 dias, nunca acima de 20% dos dias que faltam para a prova (hoje, ${teto(h)} ${teto(h)===1?'dia':'dias'}). Errou, volta para 1 dia. Acertou com certeza, no mínimo 7 dias; com dúvida, no mínimo 3. No máximo 40 revisões por dia, com os erros primeiro. A partir de 10/01/2027 as revisões ficam diárias até a prova.</p>

    <h2 class="section-title">Direção dos erros</h2>
    <div class="summary two">
      <div class="stat e"><span class="v">${st.eSendoC}</span><span class="k">marcou Errado num item Certo</span></div>
      <div class="stat e"><span class="v">${st.cSendoE}</span><span class="k">marcou Certo num item Errado</span></div>
    </div>
    <p class="insight">${leitura}</p>

    <h2 class="section-title">Calibração e regra de decisão na prova</h2>
    <p class="rule">No Cebraspe, certo vale +1, errado −1 e em branco 0. O ganho esperado de marcar um item é 2 × acerto − 1, então marcar só compensa quando o seu acerto naquele nível de confiança passa de 50%.</p>
    ${temConf?`<div class="tbl-wrap"><table><thead><tr><th>Confiança</th><th class="num">Respostas</th><th class="num">Acerto</th><th class="num">Ganho por item</th><th>Na prova</th></tr></thead><tbody>${confRows}</tbody></table></div>`
      :`<div class="notice">Ainda sem dados. Cada resposta pede a sua confiança antes do gabarito; com 10 respostas num nível, esta tabela diz se compensa marcar ou deixar em branco quando você se sente assim.</div>`}

    <h2 class="section-title">Origem dos erros no caderno</h2>
    <div class="tbl-wrap"><table class="narrow"><thead><tr><th>Origem</th><th class="num">Itens</th></tr></thead><tbody>${oRows}</tbody></table></div>

    <h2 class="section-title">Evolução por assunto</h2>
    ${viewEvolucao()}
    <h2 class="section-title">Rodadas</h2>
    ${rds.length?`<div class="tbl-wrap"><table><thead><tr><th>Quando</th><th>Capítulo</th><th>Modo</th><th class="num">C</th><th class="num">E</th><th class="num">B</th><th class="num">Líquida</th><th class="num">% acerto</th></tr></thead><tbody>${rdRows}</tbody></table></div><p class="rule">% acerto = certos ÷ itens respondidos na rodada, contando os em branco. A repescagem não entra.</p>`
      :`<div class="notice">Nenhuma rodada ainda. Elas aparecem aqui a partir da primeira resposta.</div>`}
  </div>`;
}

/* ---------- central do projeto: edital, materiais, pontos-chave, diário ---------- */
const ST={nao:'Não iniciado',estudo:'Em estudo',revisao:'Revisando',dominado:'Dominado'};
const ST_ORD=['dominado','revisao','estudo','nao'];
const MTIPO={mapa:'Mapa mental',material:'Material de estudo',cobertura:'Cobertura das fontes',fonte:'Fonte do projeto',metodo:'Método'};
const PROVAS={P1:'P1 · Conhecimentos básicos · 90 itens',P2:'P2 · Conhecimentos específicos · 90 itens'};
function topicos(){return [...S.ed.values()].sort((a,b)=>(a.ordem||0)-(b.ordem||0))}
function lblT(t){return t?`${t.sigla} ${t.num}`:''}
function matsDe(id){return [...S.mat.values()].filter(m=>(m.topicos||[]).includes(id))}
/* retenção: acerto (sem chute) em revisão feita RETENCAO+ dias após o primeiro contato */
const RETENCAO=7;
function retido(r){
  if(!r||!r.tentativas) return false; if(r.retidoEm) return true;
  const h=r.hist||[]; const p=r.primeiraEm||(h[0]&&h[0].em); if(!p) return false;
  return h.some(x=>x.ok&&x.c!==1&&x.em&&difDias(diaDe(p),diaDe(x.em))>=RETENCAO);
}
function statsTopico(t){
  const caps=new Set(t.caps||[]), h=hoje();
  const o={total:0,resp:0,ok:0,okN:0,cad:0,hoje:0,ret:0};
  if(!caps.size) return o;
  for(const q of S.q.values()){
    if(!caps.has(q.cap)||q.foraNivel) continue;
    o.total++;
    const r=S.r.get(q.id);
    if(r&&r.tentativas){ o.resp++; if(r.ultimaMarcada===q.gabarito) o.ok++; if(r.ultimaMarcada===q.gabarito&&!jaErrou(r)) o.okN++; if(r.noCaderno) o.cad++; if(retido(r)) o.ret++; const p=proxDe(r); if(p&&p<=h) o.hoje++; }
  }
  return o;
}
const RANK={nao:0,estudo:1,revisao:2,dominado:3};
function statusControle(t,s){
  const estudo=matsDe(t.id).some(m=>m.tipo==='mapa'||m.tipo==='material'||m.tipo==='cobertura')||((S.pt.get(t.id)||{}).itens||[]).length>0||((S.rv.get(t.id)||{}).itens||[]).length>0;
  if(!s.total) return estudo?'estudo':'nao';
  if(s.resp/s.total<0.8) return 'estudo';
  if(s.ok/s.resp>=0.85&&s.cad===0&&s.ret>=s.resp) return 'dominado';
  return 'revisao';
}
/* Tutory (Meu Desempenho): estudo ou resumo = em estudo; revisão e exercício já iniciados = revisando. Nunca "dominado". */
function statusTutory(t){
  const u=t.tutory; if(!u||t.tutoryIgnorar) return 'nao';
  const v=k=>u[k]||0;
  if(!(v('estudo')||v('resumo')||v('revisao')||v('exercicio'))) return 'nao';
  if(v('revisao')>0&&v('exercicio')>0) return 'revisao';
  return 'estudo';
}
function statusAuto(t,s){const a=statusControle(t,s),b=statusTutory(t);return RANK[b]>RANK[a]?b:a}
const pctT=v=>v==null?'–':v+'%';
function tutoryChip(t){
  const u=t.tutory; if(!u) return '';
  return `<span class="tchip" title="${esc((u.itens||[]).join('\n'))}">Tutory${t.tutoryIgnorar?' (desconsiderado)':''}: estudo ${pctT(u.estudo)} · resumo ${pctT(u.resumo)} · revisão ${pctT(u.revisao)} · exercício ${pctT(u.exercicio)}</span>`;
}
function nRev(id){return ((S.rv.get(id)||{}).itens||[]).length+((S.rv.get(id)||{}).cartoes||[]).length+(S.rv.has(id)?0:((S.pt.get(id)||{}).itens||[]).length)}
function statusDe(t){const s=statsTopico(t);return {s,auto:statusAuto(t,s),ef:(t.status&&ST[t.status])?t.status:statusAuto(t,s)}}
function porMateria(){
  const m=new Map();
  for(const t of topicos()){
    if(!m.has(t.sigla)) m.set(t.sigla,{sigla:t.sigla,nome:t.materia,prova:t.prova,ts:[],cont:{nao:0,estudo:0,revisao:0,dominado:0}});
    const g=m.get(t.sigla); const st=statusDe(t); g.ts.push({t,...st}); if(!t.foraEdital) g.cont[st.ef]++;
  }
  return [...m.values()];
}
function barra(cont){
  const tot=ST_ORD.reduce((a,k)=>a+cont[k],0)||1;
  return `<span class="sbar" aria-hidden="true">${['dominado','revisao','estudo'].map(k=>cont[k]?`<i class="b-${k}" style="width:${cont[k]/tot*100}%"></i>`:'').join('')}</span>`;
}
function legenda(){return `<div class="legend"><span><i style="background:var(--certo)"></i>Dominado</span><span><i style="background:var(--pen)"></i>Revisando</span><span><i style="background:var(--duvida)"></i>Em estudo</span><span><i style="background:var(--line)"></i>Não iniciado</span></div>`}
/* cartões de revisão ativa vencidos hoje, por tópico (06/11/2026) */
function cartDueBox(){
  let h=0,nv=0,fi=0,top=null,topN=0;
  for(const [id,v] of S.rv){ if(!v||!(v.cartoes||[]).length) continue; const o=cartStats(id); h+=o.hoje; nv+=o.novos; fi+=o.firmes; if(o.hoje>topN){topN=o.hoje;top=id;} }
  if(!h&&!nv) return '';
  const restR=Math.max(0,CART_REV_DIA-cartRevHoje()); h=Math.min(h,restR);
  const vagas=Math.max(0,NOVOS_DIA-novosHoje()), nn=Math.min(vagas,nv);
  if(!top){ const ids=[...S.rv.entries()].filter(([k,v])=>v&&(v.cartoes||[]).length&&cartStats(k).novos).map(([k])=>k).sort((a,b)=>((S.ed.get(a)||{}).ordem||0)-((S.ed.get(b)||{}).ordem||0)); top=ids[0]||null; }
  const tem=h+nn>0;
  return `<section class="due${tem?'':' calm'}" aria-label="Cartões de hoje"><div class="due-body"><h2 class="section-title">Cartões de revisão ativa</h2>
    <div class="due-n"><span class="mono">${h+nn}</span> ${h+nn===1?'cartão':'cartões'} para hoje</div>
    <div class="due-meta">${h} ${h===1?'vencido':'vencidos'} e ${nn} ${nn===1?'novo':'novos'} (até ${NOVOS_DIA} novos por dia; ${nv} ainda não vistos) · ${fi} firmes. Novamente, Difícil, Bom e Fácil definem quando cada cartão volta.</div></div>
    ${tem?`<button class="btn" data-cart-hoje="1">Revisar cartões · intercalados</button>`:''}</section>`;
}
function dueBox(){
  const dv=devidas(), px=proximaData();
  return dv.fila.length?`<section class="due" aria-label="Revisão espaçada de hoje">
      <div class="due-body"><h2 class="section-title">Revisão espaçada de hoje</h2>
        <div class="due-n"><span class="mono">${dv.fila.length}</span> ${dv.fila.length===1?'item':'itens'} para hoje</div>
        <div class="due-meta">${dv.erros} do caderno de erros e ${dv.fila.length-dv.erros} ${dv.fila.length-dv.erros===1?'acerto':'acertos'} para confirmar · ${dv.caps} ${dv.caps===1?'capítulo':'capítulos'}, intercalados.${dv.feitasHoje?` Você já revisou ${dv.feitasHoje} hoje.`:''}${dv.adiadas?` Limite de ${LIMITE_DIA} por dia: ${dv.adiadas} ${dv.adiadas===1?'item fica':'itens ficam'} para os próximos dias.`:''}</div></div>
      <button class="btn" id="start-rev">Começar revisão</button></section>`
    :`<section class="due calm" aria-label="Revisão espaçada"><div class="due-body"><h2 class="section-title">Revisão espaçada</h2>
        <div class="due-meta">${dv.feitasHoje?`Meta de hoje cumprida: <b class="mono">${dv.feitasHoje}</b> revisadas.${dv.adiadas?` ${dv.adiadas} ${dv.adiadas===1?'item vencido fica':'itens vencidos ficam'} para os próximos dias.`:''}</div>${dv.adiadas?'<button class="btn ghost small" id="rev-mais" style="margin-top:6px;align-self:flex-start">Revisar mais 20 (opcional)</button>':''}<div class="due-meta" hidden>`:'Nada vence hoje.'}${px?` Próxima revisão em <b class="mono">${ddmm(px.d)}</b>: ${px.n} ${px.n===1?'item':'itens'}.`:' Responda itens para montar a agenda.'}</div></div></section>`;
}
/* calibração dos últimos 14 dias: acerto quando você marcou certeza (meta 90% ou mais) */
function calibBox(){
  const ini=addDias(hoje(),-14); let n=0,ok=0;
  for(const r of S.rodadas){ if(diaDe(r.inicio)<ini) continue; for(const it of (r.itens||[])) if(it.conf===3&&(it.marcada==='C'||it.marcada==='E')&&!foraQid(it.qid)){n++; if(it.marcada===it.gabarito) ok++;} }
  if(n<10) return '';
  const p=ok/n, bom=p>=0.9;
  return `<p class="insight" style="font-size:15px"><b style="color:var(--${bom?'certo':'errado'})">Calibração · 14 dias:</b> quando você marcou certeza, acertou <b class="mono">${fmtPct(p)}</b> (${ok} de ${n}; ${n-ok} erros com certeza). Meta: 90% ou mais. ${bom?'Certeza confiável.':'Use certeza só quando souber dizer por quê; na dúvida, marque 2.'}</p>`;
}
/* anéis da aba Hoje: meta diária de revisões, calibração de 14 dias e tempo até a prova */
function anel(frac,cor,num,sub,titulo,meta){
  const r=40,c=2*Math.PI*r,f=Math.max(0,Math.min(1,frac||0));
  return `<div class="ring" role="img" aria-label="${esc(titulo)}: ${esc(num)} ${esc(sub)}. ${esc(meta)}"><svg viewBox="0 0 100 100"><circle class="rt" cx="50" cy="50" r="${r}"/><circle class="rv" cx="50" cy="50" r="${r}" stroke="${cor}" stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${(c*(1-f)).toFixed(1)}"/><text class="rn" x="50" y="52" text-anchor="middle">${esc(num)}</text><text class="rs" x="50" y="67" text-anchor="middle">${esc(sub)}</text></svg><span class="rk">${esc(titulo)}</span><span class="rm">${meta}</span></div>`;
}
function anelBox(){
  const dv=devidas(), feitas=dv.feitasHoje, alvo=Math.max(1,Math.min(LIMITE_DIA,feitas+dv.fila.length));
  const fr=feitas/alvo, okRev=feitas>=alvo;
  const a1=anel(fr,okRev?'var(--certo)':'var(--pen)',String(feitas),'de '+alvo,'Revisões de hoje',okRev?'Meta cumprida':`Faltam ${alvo-feitas}`);
  const ini=addDias(hoje(),-14); let n=0,ok=0;
  for(const r of S.rodadas){ if(diaDe(r.inicio)<ini) continue; for(const it of (r.itens||[])) if(it.conf===3&&(it.marcada==='C'||it.marcada==='E')&&!foraQid(it.qid)){n++; if(it.marcada===it.gabarito) ok++;} }
  const p=n?ok/n:0, corC=n<10?'var(--line)':p>=0.9?'var(--certo)':p>=0.8?'var(--duvida)':'var(--errado)';
  const a2=anel(p,corC,n<10?'–':Math.round(p*100)+'%',n<10?'poucos dados':`${n-ok} erros`,'Acerto com certeza',n<10?'Mínimo de 10 respostas':(p>=0.9?'Meta de 90% atingida':`Meta 90% · faltam ${Math.ceil(90-p*100)} pontos`));
  const tot=difDias('2026-10-25',PROVA), falta=Math.max(0,difDias(hoje(),PROVA));
  const fase=falta>60?'Cobertura do edital':falta>20?'Intercalação e provas':'Só revisão e simulados';
  const a3=anel(1-falta/tot,'var(--s7)',String(falta),'dias','Até a prova',fase);
  return `<section class="rings" aria-label="Metas">${a1}${a2}${a3}</section>`;
}
/* constância: dias com itens respondidos (rodadas), sequência e nível (dias de estudo reais, não quantidade de questões) */
const NIVEIS=[[0,'Começando'],[5,'Constante'],[10,'Focado'],[20,'Persistente'],[35,'Disciplinado'],[55,'Implacável']];
function constancia(){
  const por=new Map(); for(const r of S.rodadas){const d=diaDe(r.inicio);por.set(d,(por.get(d)||0)+(r.itens||[]).length)}
  const h=hoje(); let seq=0, d=por.get(h)?h:addDias(h,-1); while(por.get(d)){seq++;d=addDias(d,-1)}
  const dias=[...por.keys()].filter(k=>por.get(k)>0).length;
  let nv=0; NIVEIS.forEach(([m],i)=>{if(dias>=m)nv=i});
  const prox=NIVEIS[nv+1];
  const [y,m,dd]=h.split('-').map(Number), dow=new Date(y,m-1,dd).getDay();
  const ini=addDias(h,-(dow+28)), cells=[];
  for(let i=0;i<35;i++){const k=addDias(ini,i),n=por.get(k)||0;cells.push(`<span class="${k>h?'fut':n>=40?'l2':n>0?'l1':''}${k===h?' hj':''}" title="${ddmm(k)}: ${n} ${n===1?'item':'itens'}">${Number(k.slice(8))}</span>`)}
  return `<section class="card-v" aria-label="Constância"><h2 class="section-title">Constância · últimas 5 semanas</h2>
    <div class="badge"><span class="bn">${nv+1}</span><span><span class="bt">${NIVEIS[nv][1]}</span><br><span class="bs">${dias} ${dias===1?'dia':'dias'} de estudo · sequência de <b>${seq}</b> ${seq===1?'dia':'dias'}${prox?` · nível ${nv+2} com ${prox[0]} dias`:''}</span></span></div>
    <div class="cal">${['D','S','T','Q','Q','S','S'].map(x=>`<span class="w">${x}</span>`).join('')}${cells.join('')}</div>
    <p class="rule">Verde-claro: estudou. Verde forte: 40 itens ou mais. O nível sobe com dias de estudo, não com quantidade de questões.</p></section>`;
}
/* sua memória por intervalo: acerto ao reencontrar um item, conforme os dias desde a resposta anterior (dados reais do histórico) */
function memoria(){
  const B=[[1,1,'1 d'],[2,3,'2–3 d'],[4,7,'4–7 d'],[8,15,'8–15 d'],[16,999,'16+ d']], acc=B.map(()=>[0,0]);
  for(const r of S.r.values()){ if(foraQid(r.qid)) continue; const hs=(r.hist||[]).filter(x=>x.em&&x.m!=='B'||x.em).slice().sort((a,b)=>String(a.em).localeCompare(String(b.em)));
    for(let i=1;i<hs.length;i++){const g=difDias(diaDe(hs[i-1].em),diaDe(hs[i].em)); if(g<1) continue; const k=B.findIndex(b=>g>=b[0]&&g<=b[1]); if(k<0) continue; acc[k][0]++; if(hs[i].ok) acc[k][1]++;}}
  const W=360,H=180,L=34,Rr=16,T=24,Bt=28, x=i=>L+i*(W-L-Rr)/(B.length-1), y=v=>T+(1-v)*(H-T-Bt);
  const pts=acc.map((a,i)=>a[0]>=5?[x(i),y(a[1]/a[0]),a]:null);
  const path=pts.filter(Boolean).map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ');
  const grid=[0.5,0.75,0.9,1].map(v=>`<line x1="${L}" x2="${W-Rr}" y1="${y(v)}" y2="${y(v)}" stroke="var(--line)" ${v===0.9?'stroke-dasharray="4 3" stroke="var(--certo)"':''}/><text class="vx" x="${L-4}" y="${y(v)+3}" text-anchor="end">${v*100}%</text>`).join('');
  const n=acc.reduce((s,a)=>s+a[0],0);
  if(n<10) return `<section class="card-v"><h2 class="section-title">Sua memória por intervalo</h2><p class="rule">Ainda há poucas revisões registradas para desenhar a curva.</p></section>`;
  return `<section class="card-v" aria-label="Sua memória por intervalo"><h2 class="section-title">Sua memória por intervalo</h2>
    <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Acerto ao rever um item, por dias desde a resposta anterior">${grid}
    <path d="${path}" fill="none" stroke="var(--pen)" stroke-width="2.5"/>
    ${pts.map((p,i)=>p?`<circle cx="${p[0]}" cy="${p[1]}" r="5" fill="var(--pen)" stroke="var(--surface)" stroke-width="2"><title>${B[i][2]}: ${Math.round(p[2][1]/p[2][0]*100)}% (${p[2][1]} de ${p[2][0]})</title></circle><text class="vl" x="${p[0]}" y="${p[1]-9}" text-anchor="middle">${Math.round(p[2][1]/p[2][0]*100)}%</text>`:'').join('')}
    ${B.map((b,i)=>`<text class="vx" x="${x(i)}" y="${H-10}" text-anchor="middle">${b[2]}</text>`).join('')}</svg>
    <p class="rule">Quanto você acerta ao reencontrar um item, pelos dias desde a resposta anterior (${n} reencontros; pontos com menos de 5 ficam de fora). A linha tracejada é a meta de 90%. Se a curva cai muito nos intervalos longos, o espaçamento está largo demais para você.</p></section>`;
}
/* revisões até a prova: uma faixa por matéria, bolinhas nas datas agendadas, bandeira na prova (HTML, para o texto não escalar) */
function linhaProva(){
  const h=hoje(), fim=PROVA, tot=Math.max(1,difDias(h,fim)), m=new Map();
  for(const r of S.r.values()){ const q=S.q.get(r.qid); if(!q||foraQ(q)) continue; const p=proxDe(r); if(!p) continue; const d=p<h?h:p; const sig=materiaDoCap(q.cap); if(!sig) continue;
    if(!m.has(sig)) m.set(sig,new Map()); const g=m.get(sig); g.set(d,(g.get(d)||0)+1); }
  if(!m.size) return '';
  const rows=[...m.entries()].sort((a,b)=>nomeMateria(a[0]).localeCompare(nomeMateria(b[0])));
  const pc=d=>(difDias(h,d)/tot*100).toFixed(2)+'%', cores=['--s1','--s2','--s3','--s4','--s5','--s6','--s7','--s8'];
  const curto=n=>n.replace(/ e (Administração Pública|Regimento Interno|Regimentos|Dados)$/,'').replace(', Transcrição e IA','');
  const linhas=rows.map(([sig,ds],i)=>`<div class="tl-r"><span class="tl-n">${esc(curto(nomeMateria(sig)))}</span><div class="tl-t">${[...ds].map(([d,n])=>{const z=Math.min(18,7+Math.sqrt(n)*2.2);return `<i style="left:${pc(d)};width:${z}px;height:${z}px;background:var(${cores[i%cores.length]})" title="${esc(nomeMateria(sig))} · ${ddmm(d)}: ${n} ${n===1?'item':'itens'}"></i>`}).join('')}</div></div>`).join('');
  return `<section class="card-v" aria-label="Revisões até a prova"><h2 class="section-title">Revisões agendadas até a prova</h2>
    <div class="tl" style="--lim:${pc(LIMITE)}">${linhas}
      <div class="tl-r tl-ax"><span class="tl-n"></span><div class="tl-t"><b style="left:0">hoje</b><b style="left:${pc(addDias(h,Math.round(tot/2)))}">${ddmm(addDias(h,Math.round(tot/2)))}</b><b class="pv" style="left:100%">⚑ 17/01</b></div></div></div>
    <p class="rule">Cada bolinha é um dia com revisões daquela matéria (maior = mais itens; vencidas aparecem em hoje). A faixa vermelha é a reta final: a partir de 10/01 tudo vira revisão diária.</p></section>`;
}
function viewPainel(){
  if(!S.edLoaded) return `<div class="wrap" style="gap:18px">${dueBox()}<div class="notice">Carregando o edital…</div></div>`;
  const gs=porMateria();
  const tot={nao:0,estudo:0,revisao:0,dominado:0}; let nTop=0;
  for(const g of gs) for(const k of ST_ORD){tot[k]+=g.cont[k]; nTop+=g.cont[k];}
  const iniciados=nTop-tot.nao;
  let rows='';
  for(const p of ['P1','P2']){
    rows+=`<div class="prova-h">${esc(PROVAS[p])}</div>`;
    for(const g of gs.filter(g=>g.prova===p)){
      const n=ST_ORD.reduce((a,k)=>a+g.cont[k],0), ini=n-g.cont.nao;
      rows+=`<button class="prog-row" data-ir-materia="${esc(g.sigla)}"><span class="pn">${esc(g.nome)}</span>${barra(g.cont)}<span class="pm">${ini}/${n} tópicos</span></button>`;
    }
  }
  const di=[...S.di].sort((a,b)=>(b.data||'').localeCompare(a.data||'')||(b.registradoEm||'').localeCompare(a.registradoEm||'')||(b.id||'').localeCompare(a.id||''));
  /* próximo passo: o registro mais recente de cada matéria */
  const ult=new Map(); for(const e of di){ const k=e.materia||'Geral'; if(!ult.has(k)&&e.proximo) ult.set(k,e); }
  const proximos=ult.size?`<div class="nxt">${[...ult.values()].map(e=>`<div class="nxt-r"><b>${esc(e.materia||'Geral')}<span class="mono">${e.data?ddmm(e.data):''}</span></b><span>${esc(e.proximo)}</span></div>`).join('')}</div>`:'<div class="notice">Nenhum próximo passo registrado ainda.</div>';
  const diario=di.length?di.map(e=>`<article class="log">
      <div class="log-h"><b>${esc(e.materia||'')}</b><span class="mono" style="font-size:12.5px;color:var(--muted)">${e.data?ddmm(e.data):''}${e.chat?` · ${e.chatUrl?`<a href="${esc(e.chatUrl)}" target="_blank" rel="noopener">chat ${esc(e.chat)}</a>`:'chat '+esc(e.chat)}`:''}</span></div>
      ${(e.topicos||[]).length?`<div class="chips-t">${e.topicos.map(id=>`<span class="tchip">${esc(lblT(S.ed.get(id))||id)}</span>`).join('')}${e.questoes?`<span class="tchip">+${e.questoes} questões</span>`:''}</div>`:''}
      <p>${esc(e.feito||'')}</p>
      ${e.proximo?`<span class="nx"><b>Próximo passo:</b> ${esc(e.proximo)}</span>`:''}
    </article>`).join(''):'';
  const mats=[...S.mat.values()].filter(m=>m.url).sort((a,b)=>(b.criadoEm||'').localeCompare(a.criadoEm||''));
  const matHtml=mats.length?`<div class="mat-l">${mats.map(m=>`<div class="mat"><span class="mt"><a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(m.titulo)}</a></span><span class="mtype">${esc(MTIPO[m.tipo]||m.tipo||'')} · ${(m.topicos||[]).map(id=>esc(lblT(S.ed.get(id))||id)).join(', ')}</span></div>`).join('')}</div>`:'';
  return `<div class="wrap" style="gap:18px">
    ${anelBox()}
    ${dueBox()}
    ${cartDueBox()}
    <div class="duo">${memoria()}${constancia()}</div>
    ${linhaProva()}
    <div class="summary">
      <div class="stat"><span class="v">${iniciados}<span style="font-size:15px;color:var(--muted)">/${nTop}</span></span><span class="k">tópicos do edital iniciados</span></div>
      <div class="stat c"><span class="v">${tot.dominado}</span><span class="k">dominados</span></div>
      <div class="stat"><span class="v" style="color:var(--pen)">${tot.revisao}</span><span class="k">revisando</span></div>
      <div class="stat b"><span class="v">${tot.estudo}</span><span class="k">em estudo</span></div>
    </div>
    <h2 class="section-title">Progresso por matéria</h2>
    ${legenda()}
    <div class="prog">${rows}</div>
    ${(()=>{const c=S.cfg.get('tutory');return c?`<p class="rule">Tutory sincronizado em ${ddmm(c.sincEm)}: plano em ${esc(c.progressoPlano||'–')}, estudo em ${esc(c.progressoEstudo||'–')}, ${esc(c.taxaAcertos||'–')} de acertos.${c.metasAtrasadasDesde?` Metas atrasadas desde ${ddmm(c.metasAtrasadasDesde)}.`:''}</p>`:''})()}
    <h2 class="section-title">Próximo passo por matéria</h2>
    ${proximos}
    ${di.length?`<details class="diario" data-grupo="diario" ${S.abertos.has('diario')?'open':''}><summary>Ver o diário completo (${di.length} registros)</summary><div class="feed">${diario}</div></details>`:''}
  </div>`;
}
/* mapa de calor: um quadrado por tópico, cor pelo aproveitamento (questão errada uma vez conta como erro) */
function heatClasse(s){ if(!s.resp) return ['h0','–']; const p=s.okN/s.resp; return [p<0.6?'h1':p<0.75?'h2':p<0.85?'h3':p<0.9?'h4':'h5',Math.round(p*100)]; }
function heatMap(gs){
  let rows='';
  for(const pv of ['P1','P2']) for(const g of gs.filter(g=>g.prova===pv&&(!S.fMat||g.sigla===S.fMat))){
    const ts=g.ts.filter(x=>!x.t.foraEdital);
    if(!ts.length) continue;
    rows+=`<div class="heat-r"><span class="heat-n">${esc(g.nome)}</span><div class="heat-c">${ts.map(({t,s})=>{const [c,v]=heatClasse(s);return `<button class="hc ${c}" data-heat="${esc(t.id)}" data-sig="${esc(g.sigla)}" title="${esc(t.num)} · ${esc(t.titulo)}\n${s.resp?`${v}% de aproveitamento · ${s.resp}/${s.total} feitas${s.cad?` · ${s.cad} no caderno`:''}`:'Sem questões respondidas'}" aria-label="Tópico ${esc(t.num)}: ${s.resp?v+'%':'sem respostas'}">${esc(t.num)}</button>`}).join('')}</div></div>`;
  }
  return `<section class="heat" aria-label="Mapa de calor do edital"><h2 class="section-title">Mapa de calor · aproveitamento por tópico</h2>${rows}
    <div class="heat-l"><span><span class="hc h1"></span> abaixo de 60%</span><span><span class="hc h2"></span> 60–74%</span><span><span class="hc h3"></span> 75–84%</span><span><span class="hc h4"></span> 85–89%</span><span><span class="hc h5"></span> 90% ou mais</span><span><span class="hc h0"></span> sem respostas</span></div>
    <p class="rule">Toque num quadrado para abrir o tópico logo abaixo. O número é o do tópico no edital.</p></section>`;
}
function viewEdital(){
  if(!S.edLoaded) return `<div class="notice">Carregando o edital…</div>`;
  const gs=porMateria();
  const opts=`<option value="">Todas as matérias</option>`+gs.map(g=>`<option value="${esc(g.sigla)}" ${S.fMat===g.sigla?'selected':''}>${esc(g.nome)}</option>`).join('');
  const stOpts=`<option value="">Todos os status</option>`+ST_ORD.slice().reverse().map(k=>`<option value="${k}" ${S.fSt===k?'selected':''}>${ST[k]}</option>`).join('');
  let html='';
  for(const p of ['P1','P2']){
    const gp=gs.filter(g=>g.prova===p&&(!S.fMat||g.sigla===S.fMat));
    if(!gp.length) continue;
    html+=`<h2 class="section-title">${esc(PROVAS[p])}</h2>`;
    for(const g of gp){
      const ts=g.ts.filter(x=>!S.fSt||x.ef===S.fSt);
      if(!ts.length) continue;
      const n=ST_ORD.reduce((a,k)=>a+g.cont[k],0), ini=n-g.cont.nao;
      const aberto=S.abertos.has(g.sigla)||!!S.fMat||!!S.fSt;
      html+=`<details class="mat-g" data-grupo="${esc(g.sigla)}" ${aberto?'open':''}><summary><span class="gn">${esc(g.nome)}</span>${barra(g.cont)}<span class="mono" style="font-size:12.5px;color:var(--muted)">${ini}/${n}</span></summary>`;
      for(const {t,s,auto,ef} of ts){
        const mats=matsDe(t.id), pts=(S.pt.get(t.id)||{}).itens||[];
        const sel=`<select class="st-sel" data-status="${esc(t.id)}" aria-label="Status de ${esc(lblT(t))}"><option value="" ${!t.status?'selected':''}>Status automático</option>${ST_ORD.slice().reverse().map(k=>`<option value="${k}" ${t.status===k?'selected':''}>Fixar: ${ST[k]}</option>`).join('')}</select>`;
        const est=s.total?`<span class="mono">${s.resp}/${s.total} feitas${s.resp?` · ${fmtPct(s.okN/s.resp)} de acerto`:''}${s.cad?` · ${s.cad} no caderno`:''}${s.resp&&s.ok/s.resp>=0.85&&!s.cad&&s.ret<s.resp?` · ${s.resp-s.ret} sem prova de retenção`:''}${s.hoje?` · ${s.hoje} hoje`:''}</span>`:'';
        const links=mats.map(m=>m.url?`<a class="lnk" href="${esc(m.url)}" target="_blank" rel="noopener" title="${esc(MTIPO[m.tipo]||'')}">${esc(m.tipo==='mapa'?'Mapa':m.tipo==='cobertura'?'Cobertura':m.tipo==='material'?'Material':'Link')}</a>`:`<span class="tchip" title="${esc(m.descricao||'')}">${esc(MTIPO[m.tipo]||'Fonte')}: ${esc(m.titulo)}</span>`).join('');
        const nr=nRev(t.id);
        const mapa=mats.find(m=>m.tipo==='mapa'&&m.url), nCart=((S.rv.get(t.id)||{}).cartoes||[]).length, nPg=pgsDe(t.id).length;
        const outros=mats.filter(m=>m!==mapa);
        const acts=`<div class="acts">
            ${mapa?`<a class="lnk" href="${esc(mapa.url)}" target="_blank" rel="noopener">Mapa mental</a>`:((S.rv.get(t.id)||{}).mapa?`<button class="lnk" data-ir-mapa="${esc(t.id)}">Mapa mental</button>`:S.rv.has(t.id)?`<button class="lnk" data-ir-rev="${esc(t.id)}">Mapa mental</button>`:'<span class="lnk off">Mapa mental</span>')}
            ${nr?`<button class="lnk" data-ir-cart="${esc(t.id)}">Revisão ativa${nCart?(()=>{const o=cartStats(t.id);return ` · ${nCart} cartões${o.firmes?` · ${o.firmes} firmes`:''}${o.hoje?` · ${o.hoje} hoje`:''}`})():''}</button>`:'<span class="lnk off">Revisão ativa</span>'}
            ${(t.caps||[]).length?`<button class="lnk" data-treinar="${esc(t.caps[0])}">Treinar${s.total?` · ${s.resp}/${s.total}`:''}</button>`:'<span class="lnk off">Treinar</span>'}
            ${nPg?`<button class="lnk" data-ir-pg="${esc(t.id)}">Pegadinhas · ${nPg}</button>`:''}</div>`;
        html+=`<div class="topic${t.foraEdital?' fora':''}" id="tp-${esc(t.id)}">
          <div class="t-h"><span class="t-num">${esc(t.num)}</span><span class="t-tit">${esc(t.titulo)} <span class="st st-${ef}">${ST[ef]}${t.status?' · fixo':''}</span></span></div>
          ${acts}
          <details class="t-det" data-grupo="det:${esc(t.id)}" ${S.abertos.has('det:'+t.id)?'open':''}><summary>Detalhes</summary>
            <div class="t-meta">${sel}${est}${outros.map(m=>m.url?`<a class="lnk" href="${esc(m.url)}" target="_blank" rel="noopener">${esc(m.tipo==='cobertura'?'Cobertura':m.tipo==='material'?'Material':'Link')}</a>`:`<span class="tchip" title="${esc(m.descricao||'')}">${esc(MTIPO[m.tipo]||'Fonte')}: ${esc(m.titulo)}</span>`).join('')}</div>
            <div class="t-meta">${tutoryChip(t)}</div>
            ${t.obs?`<p class="rule" style="margin-top:6px">${esc(t.obs)}</p>`:''}
          </details>
        </div>`;
      }
      html+=`</details>`;
    }
  }
  return `<div class="wrap" style="gap:14px">
    <div class="filters"><select id="f-mat" aria-label="Matéria">${opts}</select><select id="f-st" aria-label="Status">${stOpts}</select>
      <label class="check"><input type="checkbox" id="evocar" ${S.evocar?'checked':''}> Evocar antes de ler</label></div>
    ${heatMap(gs)}
    ${legenda()}
    ${html||'<div class="notice">Nenhum tópico com esse filtro.</div>'}
  </div>`;
}
/* aba Revisão: todos os itens de mapa mental e pontos-chave, por matéria e pela numeração do edital */
function itemRev(t,p,i){
  const key=t.id+'#'+i, oc=S.evocar&&!S.revelados.has(key);
  const ex=(p.ex||[]).length?`<ul class="exl">${p.ex.map(e=>`<li>${esc(e[0])}${e[1]?` <span class="exn">${esc(e[1])}</span>`:''}${e[2]?' <span class="inc">incremento</span>':''}</li>`).join('')}</ul>`:'';
  return `<div class="pt">${oc?`<button class="pk ev" data-revelar="${esc(key)}">${esc(p.k)}</button>`:`<span class="pk">${esc(p.k)}</span>`}
    ${oc?'':`<p class="pd">${esc(p.regra||p.d||'')}</p>${ex}${p.trap?`<p class="ptr">Pegadinha: ${esc(p.trap)}</p>`:''}${p.src?`<span class="ps">${esc(p.src)}</span>`:''}`}</div>`;
}
/* revisão ativa (regra do Lucas, 05/11/2026): escrever a resposta, virar o cartão, comparar e só então marcar Lembrei, Parcial ou Não lembrei */
/* repetição espaçada dos cartões no estilo Anki (pedido do Lucas, 06/11/2026): Novamente, Difícil, Bom e Fácil.
   SM-2 com facilidade inicial 2,5 (mínimo 1,3), teto de 20% dos dias até a prova e revisão diária a partir de 10/01/2027.
   Marcações antigas (Lembrei, Parcial, Não lembrei) continuam valendo: Lembrei = Bom, Parcial = Difícil, Não lembrei = Novamente. */
const AVAL={n:'Novamente',d:'Difícil',b:'Bom',f:'Fácil'};
const AVAL_ANT={s:'b',p:'d'};
const avNorm=v=>AVAL_ANT[v]||v;
const avLbl=v=>({s:'Lembrei',p:'Parcial'})[v]||AVAL[v]||v;
const avCls=v=>({n:'e',d:'b',b:'c',f:'p'})[avNorm(v)]||'p';
const FIRME=7;
/* espaçamento dos cartões igual ao das questões (escada INT = 1, 3, 7, 15, 30 dias) (pedido do Lucas, 07/11/2026):
   Novamente volta ao início (1 dia); Difícil repete o degrau; Bom sobe um degrau; Fácil sobe dois. Continua com o teto de 20% dos dias até a prova. */
function cartNivel(a){ if(!a) return 0; if(typeof a.nivel==='number') return a.nivel; const i=a.intervalo||0; let n=0; INT.forEach((x,j)=>{if(x<=i) n=j}); return n }
function srsCalc(prev,v,d){
  d=d||hoje();
  const nv=cartNivel(prev); let nn;
  if(v==='n') nn=0;
  else if(v==='d') nn=nv;
  else if(v==='b') nn=Math.min(INT.length-1,nv+1);
  else nn=Math.min(INT.length-1,nv+2);
  let n=INT[nn]; const fac=prev&&typeof prev.facil==='number'?prev.facil:2.5;
  let prox;
  if(d>=LIMITE){ n=1; prox=addDias(d,1); }
  else { n=Math.min(n,teto(d)); prox=addDias(d,n); if(prox>LIMITE){prox=LIMITE;n=difDias(d,LIMITE);} }
  return {facil:fac,intervalo:n,prox,nivel:nn};
}
function srsFmt(n){return n<=1?'1 dia':n<30?n+' dias':Math.round(n/30)+' mês'}
/* novos por dia: 50 cartões nunca vistos (07/11/2026); revisões de cartões por dia: 50, por prioridade */
const NOVOS_DIA=50, CART_REV_DIA=50;
function cartRevHoje(){let n=0;const h=hoje();for(const a of (S.cav||new Map()).values()){for(const x of (a.hist||[])) if(x.rev&&diaDe(x.em)===h) n++}return n}
const cartNovo=a=>!a||!(a.hist||[]).length;
function novosHoje(){let n=0;const h=hoje();for(const a of (S.cav||new Map()).values()){const x=(a.hist||[])[0];if(x&&diaDe(x.em)===h)n++}return n}
/* vencido: data passou, avaliado antes do sistema novo (sem data), ou marcado "Novamente" nesta sessão */
function cartVence(k){const a=(S.cav||new Map()).get(k); if(S.cartDeNovo&&S.cartDeNovo.has(k)) return true; if(cartNovo(a)) return false; if(!a.prox) return true; return a.prox<=hoje()}
function cartFirme(a){return !!a&&a.prox&&(a.intervalo||0)>=FIRME&&(avNorm(a.ult)==='b'||avNorm(a.ult)==='f')}
function cartStats(id){const rv=S.rv.get(id), cav=S.cav||new Map(), o={tot:0,hoje:0,novos:0,firmes:0};
  ((rv&&rv.cartoes)||[]).forEach((c,i)=>{const k=id+'@'+i,a=cav.get(k);o.tot++; if(cartNovo(a)) o.novos++; else if(cartVence(k)) o.hoje++; if(cartFirme(a)) o.firmes++;});
  return o;}
S.cartDeNovo=new Set();
/* sessão intercalada (pedido do Lucas, 06/11/2026, a partir de Fixe o Conhecimento: o rebatedor treinado com arremessos
   aleatórios rende mais). Todos os tópicos misturados, um cartão por vez, sem dois seguidos do mesmo tópico quando possível.
   Intercalar ajuda a distinguir conceitos parecidos (Rohrer e Taylor, 2007). */
function filaMix(){
  const porTop=new Map(), cav=S.cav||new Map();
  let vagas=Math.max(0,NOVOS_DIA-novosHoje());
  let revVagas=Math.max(0,CART_REV_DIA-cartRevHoje());
  const due=[];
  const ids=[...S.rv.entries()].filter(([k,v])=>v&&(v.cartoes||[]).length).map(([k])=>k).sort((a,b)=>((S.ed.get(a)||{}).ordem||0)-((S.ed.get(b)||{}).ordem||0));
  const novos=new Map();
  for(const id of ids){ (S.rv.get(id).cartoes||[]).forEach((c,i)=>{const k=id+'@'+i,a=cav.get(k);
    if(cartVence(k)){ due.push({k,id,pr:(S.cartDeNovo&&S.cartDeNovo.has(k)?-1:cartNivel(a)),p:(a&&a.prox)||'0000'}); }
    else if(cartNovo(a)){ if(!novos.has(id)) novos.set(id,[]); novos.get(id).push(k); } }); }
  /* revisões: prioridade (Novamente, depois o degrau mais baixo, depois o mais atrasado); o teto diário corta o resto para amanhã */
  due.sort((x,y)=>(x.pr-y.pr)||(x.p<y.p?-1:x.p>y.p?1:0));
  for(const x of due.slice(0,revVagas)){ if(!porTop.has(x.id)) porTop.set(x.id,[]); porTop.get(x.id).push(x.k); }
  /* novos: um de cada tópico por vez, até o limite do dia */
  const nl=[...novos.values()]; let r=0;
  while(vagas>0&&nl.some(l=>l.length)){ const l=nl[r%nl.length]; if(l.length){ const k=l.shift(), id=k.split('@')[0]; if(!porTop.has(id)) porTop.set(id,[]); porTop.get(id).push(k); vagas--; } r++; }
  const emb=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
  const listas=[...porTop.values()];
  /* sorteia o tópico do próximo cartão, com peso pelo que resta, sem repetir o anterior se houver outro */
  const out=[]; let ult=null;
  while(listas.some(l=>l.length)){
    let cand=listas.filter(l=>l.length&&l[0].split('@')[0]!==ult); if(!cand.length) cand=listas.filter(l=>l.length);
    const tot=cand.reduce((a,l)=>a+l.length,0); let x=Math.random()*tot, esc=cand[0];
    for(const l of cand){ x-=l.length; if(x<=0){esc=l;break} }
    const k=esc.shift(); out.push(k); ult=k.split('@')[0];
  }
  return out;
}
function iniciarMix(){const f=filaMix(); if(!f.length){toast('Nenhum cartão para hoje.');return} S.cmix={fila:f,idx:0,tot:f.length,feitos:0}; for(const k of f){S.cartAbertos.delete(k);S.cartRated.delete(k)} setView('cartoes'); window.scrollTo({top:0});}
function viewCmix(){
  const m=S.cmix;
  if(m.idx>=m.fila.length) return `<div class="wrap" style="gap:14px"><div class="due calm"><div class="due-body"><h2 class="section-title">Sessão intercalada concluída</h2><div class="due-n"><span class="mono">${m.feitos}</span> avaliações</div><div class="due-meta">Cada cartão já tem a próxima data. Os marcados como Novamente voltaram no fim da sessão e voltam amanhã.</div></div><button class="btn" data-cmix-sair="1">Fechar</button></div></div>`;
  const k=m.fila[m.idx], [id,i]=k.split('@'), rv=S.rv.get(id)||{}, c=(rv.cartoes||[])[+i]||{}, t=S.ed.get(id)||{}, ab=S.cartAbertos.has(k);
  const rated=S.cartRated.has(k);
  return `<div class="wrap" style="gap:14px">
    <div class="scorebar"><span class="progress">Cartão ${m.idx+1} de ${m.fila.length} · tópicos misturados</span><button class="btn ghost small" data-cmix-sair="1">Encerrar</button></div>
    <div class="card-r ck" style="--mc:var(--pen);padding:16px">
      <span class="tag">${ab?`${esc(lblT(t)||id)} · ${esc(c.tema||'')}`:'Assunto oculto até virar'}</span>
      <p class="cq" style="font-size:17px">${esc(c.q||'')}</p>
      ${ab?`<ul class="exl">${(c.a||[]).map(a=>`<li>${esc(a)}</li>`).join('')}</ul>${c.src?`<span class="ps">${esc(c.src)}</span>`:''}`:''}
      ${cartAval(k,ab)}
      ${rated?`<button class="btn" data-cmix-next="1">Próximo cartão</button>`:''}
    </div>
    <p class="rule">Os cartões vêm misturados de todos os tópicos, como arremessos aleatórios: antes de responder, identifique de que assunto é a pergunta.</p>
  </div>`;
}
S.cartResp=new Map(); S.cartRated=new Set();
/* correção por IA da resposta escrita (06/11/2026). Usa o Claude da própria conta do Lucas (capability "sample"), sem chave de API na página.
   Proteções: limite de tempo de 40 s; uma nova tentativa automática só para falha de rede/tempo, no modelo rápido; "limite de uso" não repete;
   sem IA disponível, o botão some e a autoavaliação manual continua igual. A IA só sugere: quem marca Novamente/Difícil/Bom/Fácil é o Lucas. */
S.ia=new Map(); let IA=null, iaPronta=false;
(async()=>{try{IA=await claude.use('sample')}catch(e){IA=null} iaPronta=true; if(IA&&S.view==='cartoes') render();})();
function cartaoDe(k){const [id,i]=k.split('@');const rv=S.rv.get(id);return rv&&(rv.cartoes||[])[+i]}
function iaBox(k,resp){
  if(!IA||!resp.trim()) return '';
  const st=S.ia.get(k);
  if(!st) return `<button class="btn ghost small" data-ia="${esc(k)}">Corrigir com IA</button>`;
  if(st.s==='run') return `<span class="ps">Corrigindo… ${st.tent>1?'(nova tentativa)':''}</span>`;
  if(st.s==='err') return `<span class="ps" style="color:var(--errado)">${esc(st.msg)}</span>`;
  const r=st.r, V={lembrei:['c','Bom'],parcial:['b','Difícil'],nao:['e','Novamente']}[r.veredito]||['p','?'];
  return `<div class="m-det" style="--mc:var(--pen);margin:0"><p><span class="pill ${V[0]}">Sugestão da IA: ${V[1]}</span></p>
    ${(r.acertou||[]).length?`<p><b>Acertou:</b> ${esc(r.acertou.join('; '))}</p>`:''}
    ${(r.faltou||[]).length?`<p><b>Faltou:</b> ${esc(r.faltou.join('; '))}</p>`:''}
    ${(r.errado||[]).length?`<p class="m-trap"><b>Errado:</b> ${esc(r.errado.join('; '))}</p>`:''}
    ${r.comentario?`<p>${esc(r.comentario)}</p>`:''}<span class="ps">A decisão é sua: marque abaixo.</span></div>`;
}
async function corrigirIA(k){
  const c=cartaoDe(k), resp=(S.cartResp.get(k)||'').trim(); if(!IA||!c||!resp) return;
  const prompt=`Você corrige um cartão de revisão ativa de um candidato a concurso (Cebraspe, Câmara dos Deputados). Compare a resposta do candidato com a resposta esperada, item a item, aceitando sinônimos e paráfrases fiéis. Não acrescente conteúdo que não esteja na resposta esperada.
PERGUNTA: ${c.q}
RESPOSTA ESPERADA (itens): ${(c.a||[]).map((x,i)=>`(${i+1}) ${x}`).join(' ')}
RESPOSTA DO CANDIDATO: ${resp}
Devolva só JSON: {"veredito":"lembrei"|"parcial"|"nao","acertou":[itens esperados que ele trouxe],"faltou":[itens esperados ausentes],"errado":[afirmações dele que contradizem a resposta esperada],"comentario":"uma frase curta, em português, dizendo o ponto principal a fixar"}. "lembrei" só se todos os itens essenciais estiverem presentes e nada estiver errado; "nao" se quase nada bate.`;
  for(let tent=1;tent<=2;tent++){
    S.ia.set(k,{s:'run',tent}); render(true);
    const ac=new AbortController(), to=setTimeout(()=>ac.abort(),40000);
    try{
      const r=await IA.json(prompt,{modelTier:tent===1?'default':'quick',signal:ac.signal});
      clearTimeout(to);
      if(!r||typeof r!=='object'||!r.veredito) throw {code:'formato'};
      S.ia.set(k,{s:'ok',r}); render(true); return;
    }catch(e){
      clearTimeout(to);
      const code=(e&&e.code)||(ac.signal.aborted?'tempo':'erro');
      if(code==='not_granted'){IA=null;S.ia.delete(k);toast('Correção por IA desativada nesta visualização. A autoavaliação continua normal.');render(true);return;}
      if(code==='rate_limited'){S.ia.set(k,{s:'err',msg:'Limite de uso da IA atingido agora. Compare você mesmo e tente a IA mais tarde.'});render(true);return;}
      if(tent===2||code==='formato'&&tent===2){S.ia.set(k,{s:'err',msg:'A IA não respondeu a tempo. Compare você mesmo; a marcação funciona igual.'});render(true);return;}
    }
  }
}
/* explicação na revisão ativa (06/11/2026): 1) explicação gravada no cartão (campo "ex"); 2) nó mais parecido do mapa mental do tópico; 3) explicação gerada por IA */
const _nrm=t=>String(t||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
const _STOP=new Set('para pela pelo com sem que dos das nos nas uma uns umas por como mais sobre entre quando qual quais isso esse essa este esta ele ela seu sua nao sim art lei inciso'.split(' '));
const _tok=t=>new Set(_nrm(t).split(/[^a-z0-9]+/).filter(w=>w.length>3&&!_STOP.has(w)));
function noDoMapa(id,c){
  const rv=S.rv.get(id), m=rv&&rv.mapa; if(!m) return null;
  const alvo=_tok([c.tema,c.q,(c.a||[]).join(' ')].join(' ')); let best=null;
  const walk=(n,path)=>{const txt=[n.t,n.n,n.x&&n.x.e,n.x&&n.x.ex,n.x&&n.x.trap].join(' ');const ws=_tok(txt);let sc=0;ws.forEach(w=>{if(alvo.has(w))sc++});if(n.x)sc+=0.5;if(sc>=2&&(!best||sc>best.sc))best={sc,path};(n.f||[]).forEach((f,i)=>walk(f,path+'.'+i))};
  (m.ramos||[]).forEach((r,i)=>walk(r,String(i))); return best&&best.path;
}
function irMapa(k){
  const [id]=k.split('@'), c=cartaoDe(k), path=c&&noDoMapa(id,c); if(!path) return;
  S.mapaId=id; S.mapaAb=new Set(['*']); S.mapaX=S.mapaX||new Set(); const xk='mx:'+id+':'+path; S.mapaX.add(xk);
  setView('mapa'); setTimeout(()=>{const el=document.querySelector(`[data-mx="${CSS.escape(xk)}"]`);if(el){el.scrollIntoView({block:'center'});el.closest('li').classList.add('m-foco');setTimeout(()=>el.closest('li')&&el.closest('li').classList.remove('m-foco'),2500)}},40);
}
S.iaEx=new Map(); S.exAb=new Set();
async function explicarIA(k){
  const c=cartaoDe(k); if(!IA||!c) return;
  const prompt=`Você é tutor de um candidato ao concurso de Analista Legislativo da Câmara dos Deputados (banca Cebraspe). Explique, em português e em no máximo 120 palavras, POR QUE a resposta abaixo é a correta. Baseie-se só na pergunta, na resposta e na fonte indicada; se algo depender de informação que não está aqui, diga que deve ser conferido na fonte, sem inventar números, artigos ou jurisprudência.
PERGUNTA: ${c.q}
RESPOSTA: ${(c.a||[]).join(' | ')}
FONTE: ${c.src||'não informada'}
Devolva só JSON: {"explicacao":"o raciocínio, em linguagem simples","exemplo":"um exemplo concreto curto ou vazio","pegadinha":"como o Cebraspe costuma distorcer isso, ou vazio","pergunta":"uma pergunta de recuperação curta sobre o ponto"}`;
  for(let tent=1;tent<=2;tent++){
    S.iaEx.set(k,{s:'run',tent}); render(true);
    const ac=new AbortController(), to=setTimeout(()=>ac.abort(),40000);
    try{ const r=await IA.json(prompt,{modelTier:tent===1?'default':'quick',signal:ac.signal}); clearTimeout(to);
      if(!r||!r.explicacao) throw {code:'formato'}; S.iaEx.set(k,{s:'ok',r}); render(true); return;
    }catch(e){ clearTimeout(to); const code=(e&&e.code)||(ac.signal.aborted?'tempo':'erro');
      if(code==='not_granted'){IA=null;S.iaEx.delete(k);toast('IA indisponível nesta visualização.');render(true);return;}
      if(code==='rate_limited'){S.iaEx.set(k,{s:'err',msg:'Limite de uso da IA atingido agora. Tente mais tarde.'});render(true);return;}
      if(tent===2){S.iaEx.set(k,{s:'err',msg:'A IA não respondeu a tempo. Tente de novo.'});render(true);return;}
    }
  }
}
function explicaBox(k){
  const [id]=k.split('@'), c=cartaoDe(k); if(!c) return '';
  const bts=[];
  if(c.ex) bts.push(`<button class="lnk" data-exab="${esc(k)}">${S.exAb.has(k)?'Esconder explicação':'Ver explicação'}</button>`);
  if(noDoMapa(id,c)) bts.push(`<button class="lnk" data-irmapa="${esc(k)}">Ver no mapa mental ↗</button>`);
  const st=S.iaEx.get(k);
  if(IA&&!st) bts.push(`<button class="lnk" data-exia="${esc(k)}">Explicar com IA</button>`);
  let out=bts.length?`<div class="chips" style="gap:12px">${bts.join('')}</div>`:'';
  if(c.ex&&S.exAb.has(k)) out+=`<div class="m-det" style="margin:0"><p>${esc(c.ex)}</p></div>`;
  if(st&&st.s==='run') out+=`<span class="ps">Gerando explicação… ${st.tent>1?'(nova tentativa)':''}</span>`;
  if(st&&st.s==='err') out+=`<span class="ps" style="color:var(--errado)">${esc(st.msg)}</span> <button class="lnk" data-exia="${esc(k)}">Tentar de novo</button>`;
  if(st&&st.s==='ok'){const r=st.r; out+=`<div class="m-det" style="--mc:var(--pen);margin:0"><p><span class="pill p">Explicação gerada por IA · confira na fonte</span></p><p>${esc(r.explicacao)}</p>${r.exemplo?`<p><b>Exemplo:</b> ${esc(r.exemplo)}</p>`:''}${r.pegadinha?`<p class="m-trap"><b>Pegadinha:</b> ${esc(r.pegadinha)}</p>`:''}${r.pergunta?`<p><b>Recupere:</b> ${esc(r.pergunta)}</p>`:''}</div>`;}
  return out;
}
function cartAval(k,ab){
  const a=(S.cav||new Map()).get(k), ult=a&&a.hist&&a.hist.length?a.hist[a.hist.length-1]:null;
  const last=ult?`<span class="ps">Última: ${avLbl(ult.v)} em ${ddmm(diaDe(ult.em))}${a.hist.length>1?` · ${a.hist.length} tentativas`:''}${a.prox?` · próxima em ${ddmm(a.prox)}`:''}</span>`:'';
  const resp=S.cartResp.get(k)||'';
  if(!ab) return `<div class="cav" style="width:100%"><div class="note" style="width:100%"><label for="cr-${esc(k)}">Sua resposta, de memória (nas lacunas, escreva o que vai em cada uma, na ordem):</label><textarea id="cr-${esc(k)}" data-cresp="${esc(k)}" style="min-height:52px" placeholder="Escreva antes de ver a resposta…">${esc(resp)}</textarea></div><button class="btn small" data-cver="${esc(k)}">Ver resposta</button>${last}</div>`;
  const sua=resp.trim()?`<p class="cq" style="font-size:14.5px"><b>Sua resposta:</b> ${esc(resp)}</p>`:'<span class="ps">Você não escreveu resposta.</span>';
  if(!S.cartRated.has(k)) return `<div class="cav">${sua}${explicaBox(k)}${iaBox(k,resp)}<span class="ps">Compare com a resposta acima e marque:</span><div class="srs-g">${Object.entries(AVAL).map(([v,t])=>`<button class="srs srs-${v}" data-cav="${esc(k)}" data-v="${v}"><b>${t}</b><span>${v==='n'?'hoje e amanhã':srsFmt(srsCalc(a,v).intervalo)}</span></button>`).join('')}</div>${last}</div>`;
  return `<div class="cav">${sua}${ult?`<span class="pill ${avCls(ult.v)}">Você marcou: ${avLbl(ult.v)}${a.prox?` · volta em ${ddmm(a.prox)}`:''}</span>`:''}${explicaBox(k)}<button class="lnk" data-cart="${esc(k)}">Esconder resposta</button></div>`;
}
function salvarAval(k,v){
  S.cav=S.cav||new Map(); const prev=S.cav.get(k)||{k,hist:[]};
  const r=(S.cartResp.get(k)||'').trim();
  const sc=srsCalc(prev,v);
  const eraRev=!cartNovo(prev);
  const hist=(prev.hist||[]).concat([Object.assign({v,em:new Date().toISOString(),int:sc.intervalo,rev:eraRev},r?{resp:r.slice(0,1000)}:{})]).slice(-20);
  const doc={k,ult:v,hist,facil:sc.facil,intervalo:sc.intervalo,nivel:sc.nivel,prox:sc.prox,atualizadoEm:new Date().toISOString()}; S.cav.set(k,doc);
  /* Novamente: o cartão volta no fim desta sessão (fica visível em "Para hoje") e de novo amanhã */
  if(v==='n') S.cartDeNovo.add(k); else S.cartDeNovo.delete(k);
  if(S.cmix){ S.cmix.feitos++; if(v==='n'&&S.cmix.fila.lastIndexOf(k)<=S.cmix.idx) S.cmix.fila.push(k); }
  S.cartAbertos.add(k); S.cartRated.add(k); render(true);
  if(S.db) enqueue(()=>S.db.doc('cartoes_aval/'+k.replace(/[^A-Za-z0-9_\-.~:@+]/g,'_')).set(doc));
}
/* revisão ativa em layout de mapa: centro, temas como ramos coloridos, cartões prontos para responder */
function viewCartoes(){
  if(S.cmix) return viewCmix();
  const ids=[...S.rv.entries()].filter(([k,v])=>v&&(v.cartoes||[]).length).map(([k])=>k).sort((a,b)=>((S.ed.get(a)||{}).ordem||0)-((S.ed.get(b)||{}).ordem||0));
  if(!ids.length) return `<div class="wrap"><div class="notice">Nenhum cartão de revisão ativa ainda.</div></div>`;
  if(!S.cartId||!ids.includes(S.cartId)) S.cartId=ids[0];
  const rv=S.rv.get(S.cartId), t=S.ed.get(S.cartId)||{}, cav=S.cav||new Map();
  const grupos=new Map(); (rv.cartoes||[]).forEach((c,i)=>{const g=c.tema||'Geral';if(!grupos.has(g))grupos.set(g,[]);grupos.get(g).push([c,i])});
  const cnt={n:0,d:0,b:0,f:0,x:0}, cs0=cartStats(S.cartId);
  const vagas=Math.max(0,NOVOS_DIA-novosHoje()), novosOk=new Set();
  (rv.cartoes||[]).forEach((c,i)=>{const k=S.cartId+'@'+i;if(cartNovo(cav.get(k))&&novosOk.size<vagas)novosOk.add(k)});
  (rv.cartoes||[]).forEach((c,i)=>{const a=cav.get(S.cartId+'@'+i);cnt[a&&a.ult?avNorm(a.ult):'x']++});
  let gi=0;
  const ramos=[...grupos].map(([g,cs])=>{gi++;
    const vis=cs.filter(([c,i])=>{if(!S.cartPend)return true;const k=S.cartId+'@'+i;return cartVence(k)||novosOk.has(k)||S.cartRated.has(k)});
    if(!vis.length) return '';
    const fk=S.cartId+'#'+g, fe=(S.cartFech||new Set()).has(fk);
    return `<section class="m-ramo" style="--mc:var(--s${(gi-1)%8+1})"><button class="m-l m-tx" data-cfech="${esc(fk)}" aria-expanded="${!fe}" style="margin-bottom:6px;width:100%"><span class="m-t" style="font-size:16px;font-weight:800">${fe?'▸':'▾'} ${esc(g)}</span><span class="ps">${vis.length}</span></button>${fe?'':vis.map(([c,i])=>{const k=S.cartId+'@'+i,ab=S.cartAbertos.has(k);
      return `<div class="card-r ck"><p class="cq">${esc(c.q)}</p>${ab?`<ul class="exl">${(c.a||[]).map(a=>`<li>${esc(a)}</li>`).join('')}</ul>${c.src?`<span class="ps">${esc(c.src)}</span>`:''}`:''}${cartAval(k,ab)}</div>`}).join('')}</section>`}).join('');
  /* fim dos ramos de cartões */
  const tot=(rv.cartoes||[]).length;
  return `<div class="wrap" style="gap:14px;max-width:1100px">
    <div class="filters"><select id="cart-top" aria-label="Tópico">${ids.map(id=>{const o=cartStats(id),h=o.hoje+o.novos;return `<option value="${esc(id)}" ${id===S.cartId?'selected':''}>${esc(lblT(S.ed.get(id))||id)} · ${esc((S.ed.get(id)||{}).titulo||'')}${o.hoje?` · ${o.hoje} vencidos`:''}</option>`}).join('')}</select>
      <label class="check"><input type="checkbox" id="cart-pend" ${S.cartPend?'checked':''}> Só os de hoje (vencidos + até ${vagas} novos)</label>
      <button class="btn small" data-cart-hoje="1">Sessão intercalada · todos os tópicos</button>
      <button class="btn ghost small" id="cart-reset">Esconder respostas</button>
      <button class="btn ghost small" data-cf="1">Abrir tudo</button><button class="btn ghost small" data-cf="0">Fechar tudo</button>
      ${rv.mapa?`<button class="lnk" data-ir-mapa="${esc(S.cartId)}">Mapa mental</button>`:''}</div>
    <div class="m-centro">${esc((rv.mapa&&rv.mapa.centro)||t.titulo||'')} · revisão ativa</div>
    <p class="rule" style="align-self:center">${tot} cartões · <b>${Math.min(cs0.hoje,Math.max(0,CART_REV_DIA-cartRevHoje()))} para hoje</b> (${cs0.hoje} vencidos; teto de ${CART_REV_DIA} revisões por dia) · ${cs0.novos} novos · <span class="pos">${cs0.firmes} firmes</span> (intervalo de ${FIRME}+ dias) · última marcação: <span class="neg">${cnt.n} novamente</span>, <span style="color:var(--duvida)">${cnt.d} difícil</span>, <span class="pos">${cnt.b} bom</span>, <span style="color:var(--pen)">${cnt.f} fácil</span>. Responda de memória, vire e marque: cada botão mostra quando o cartão volta.</p>
    <div class="m-grid">${ramos||`<div class="notice">Nada para hoje neste tópico${vagas?'':` (o limite de ${NOVOS_DIA} cartões novos por dia já foi atingido)`}. Desmarque "Só os de hoje" para ver todos.</div>`}</div>
  </div>`;
}
function viewRevisao(){
  if(!S.edLoaded) return `<div class="notice">Carregando…</div>`;
  const gs=porMateria();
  const comRev=t=>S.rv.has(t.id)||((S.pt.get(t.id)||{}).itens||[]).length>0;
  const opts=`<option value="">Todas as matérias</option>`+gs.filter(g=>g.ts.some(x=>comRev(x.t))).map(g=>`<option value="${esc(g.sigla)}" ${S.fMat===g.sigla?'selected':''}>${esc(g.nome)}</option>`).join('');
  let html='', nI=0, nC=0, nT=0;
  for(const p of ['P1','P2']){
    for(const g of gs.filter(g=>g.prova===p&&(!S.fMat||g.sigla===S.fMat))){
      const ts=g.ts.map(x=>x.t).filter(comRev);
      if(!ts.length) continue;
      const nIt=ts.reduce((a,t)=>a+nRev(t.id),0);
      html+=`<details class="mat-g" data-grupo="rv:${esc(g.sigla)}" ${S.abertos.has('rv:'+g.sigla)||S.fMat?'open':''}><summary><span class="gn">${esc(g.nome)}</span><span></span><span class="mono" style="font-size:12.5px;color:var(--muted)">${ts.length} ${ts.length===1?'tópico':'tópicos'} · ${nIt} itens</span></summary>`;
      for(const t of ts){
        nT++;
        const rv=S.rv.get(t.id), pt=S.pt.get(t.id), doc=rv||pt, itens=doc.itens||[], cart=(rv&&rv.cartoes)||[];
        nI+=itens.length; nC+=cart.length;
        const fontes=(doc.fontes||[]).map(x=>x.url?`<a class="lnk" href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.titulo)}</a>`:`<span class="tchip">${esc(x.titulo)}</span>`).join('');
        let corpo='', gr=null;
        /* árvore do mapa: ramo (grupo) → microtópico (sub) → folhas */
        let sb=null;
        itens.forEach((it,i)=>{ if(it.grupo&&it.grupo!==gr){gr=it.grupo; sb=null; corpo+=`<span class="pts-g">${esc(gr)}</span>`;} if(it.sub&&it.sub!==sb){sb=it.sub; corpo+=`<span class="pts-g" style="margin-left:14px;text-transform:none;letter-spacing:0;font-size:12px">↳ ${esc(sb)}</span>`;} corpo+=it.sub?`<div style="margin-left:14px">${itemRev(t,it,i)}</div>`:itemRev(t,it,i); });
        const fol=itens.length?`<details class="t-det" data-grupo="fol:${esc(t.id)}" ${S.abertos.has('fol:'+t.id)?'open':''} style="padding-left:0"><summary>Folhas detalhadas (${itens.length})</summary><div class="pts" style="padding-left:0">${corpo}</div></details>`:'';
        html+=`<details class="rv-top" id="rv-${esc(t.id)}" data-grupo="rvt:${esc(t.id)}" ${S.abertos.has('rvt:'+t.id)?'open':''}>
          <summary class="t-h"><span class="t-num">${esc(t.num)}</span><span class="t-tit">${esc(t.titulo)} <span class="mono" style="font-size:12px;color:var(--muted)">· ${itens.length} itens${cart.length?` · ${cart.length} cartões`:''}</span></span></summary>
          <div class="acts">${rv&&rv.mapa?`<button class="lnk" data-ir-mapa="${esc(t.id)}">Mapa mental</button>`:''}${cart.length?`<button class="lnk" data-ir-cart="${esc(t.id)}">Revisão ativa · ${cart.length}</button>`:''}${fontes}${rv?'':'<span class="tchip">pontos-chave do material</span>'}</div>
          <div class="pts">${fol}</div></details>`;
      }
      html+=`</details>`;
    }
  }
  return `<div class="wrap" style="gap:14px">
    <div class="filters"><select id="f-mat" aria-label="Matéria">${opts}</select>
      <label class="check"><input type="checkbox" id="evocar" ${S.evocar?'checked':''}> Evocar antes de ler</label></div>
    <div class="row"><button class="btn ghost small" id="rv-abrir">Abrir tudo</button><button class="btn ghost small" id="rv-fechar">Fechar tudo</button></div>
    <p class="rule">${nI} itens e ${nC} cartões em ${nT} ${nT===1?'tópico':'tópicos'}. Com "Evocar antes de ler", explique de memória antes de abrir.</p>
    ${html||'<div class="notice">Nenhum mapa mental registrado ainda. Cada mapa criado num chat de matéria entra aqui.</div>'}
  </div>`;
}
/* mapa mental no estilo do modelo do Lucas (End-to-End): centro, ramos coloridos, rótulos curtos com etiqueta, tabela, caixa e ligações cruzadas */
function viewMapa(){
  const ids=[...S.rv.entries()].filter(([k,v])=>v&&v.mapa).map(([k])=>k).sort((a,b)=>((S.ed.get(a)||{}).ordem||0)-((S.ed.get(b)||{}).ordem||0));
  if(!ids.length) return `<div class="wrap"><div class="notice">Nenhum mapa no formato novo ainda. Os chats de matéria gravam o mapa no documento de revisão do tópico.</div></div>`;
  if(!S.mapaId||!ids.includes(S.mapaId)) S.mapaId=ids[0];
  const t=S.ed.get(S.mapaId)||{}, m=S.rv.get(S.mapaId).mapa, ab=S.mapaAb||new Set(['*']), tudo=ab.has('*');
  const nomes={}; const walk=(n)=>{if(n.id)nomes[n.id]=n.t;(n.f||[]).forEach(walk)}; (m.ramos||[]).forEach(walk);
  const lig=m.ligacoes||[];
  let seq=0;
  const no=(n,cor,path)=>{
    const k=path, kids=n.f||[], aberto=tudo||ab.has(k), key='mp:'+S.mapaId+':'+k, oc=S.evocar&&n.n&&!S.revelados.has(key);
    const out=lig.filter(l=>l[0]===n.id).map(l=>`<button class="m-link" data-mir="${esc(l[1])}" title="${esc(l[2]||'')}">↗ ${esc(nomes[l[1]]||l[1])}</button>`).join('');
    const inn=lig.filter(l=>l[1]===n.id).map(l=>`<button class="m-link" data-mir="${esc(l[0])}" title="${esc(l[2]||'')}">↙ ${esc(nomes[l[0]]||l[0])}</button>`).join('');
    const tab=n.tabela?`<table class="m-tab">${n.tabela.map(([c,vs])=>`<tr><th>${esc(c)}</th><td>${vs.map(v=>`<div>${esc(v)}</div>`).join('')}</td></tr>`).join('')}</table>`:'';
    const nota=n.n?(oc?`<button class="m-nota ev" data-revelar="${esc(key)}">evocar</button>`:`<span class="m-nota">${esc(n.n)}</span>`):'';
    const tog=kids.length?`<button class="m-tog" data-mtog="${esc(k)}" aria-expanded="${aberto}">${aberto?'−':'+'}${aberto?'':' '+kids.length}</button>`:'';
    const xk='mx:'+S.mapaId+':'+k, xa=n.x&&(S.mapaX||new Set()).has(xk);
    const lab=n.x?`<button class="m-t m-tx" data-mx="${esc(xk)}" aria-expanded="${!!xa}">${esc(n.t)} <span class="m-i">${xa?'▾':'ⓘ'}</span></button>`:`<span class="m-t">${esc(n.t)}</span>`;
    const det=xa?`<div class="m-det"><p>${esc(n.x.e)}</p>${n.x.ex?`<p><b>Exemplo:</b> ${esc(n.x.ex)}</p>`:''}${n.x.trap?`<p class="m-trap"><b>Pegadinha:</b> ${esc(n.x.trap)}</p>`:''}${n.x.src?`<span class="ps">${esc(n.x.src)}</span>`:''}</div>`:'';
    return `<li class="m-no${n.caixa?' m-caixa':''}" ${n.id?`id="mn-${esc(n.id)}"`:''}><div class="m-l">${lab}${tog}${out}${inn}</div>${nota}${det}${tab}${kids.length&&aberto?`<ul>${kids.map((c,i)=>no(c,cor,k+'.'+i)).join('')}</ul>`:''}</li>`;
  };
  const ramos=(m.ramos||[]).map((r,i)=>{const cor=`var(--s${((r.cor||i+1)-1)%8+1})`;return `<section class="m-ramo" style="--mc:${cor}"><ul class="m-raiz">${no(r,cor,String(i))}</ul></section>`}).join('');
  return `<div class="wrap" style="gap:14px;max-width:1100px">
    <div class="filters"><select id="mapa-top" aria-label="Tópico">${ids.map(id=>`<option value="${esc(id)}" ${id===S.mapaId?'selected':''}>${esc(lblT(S.ed.get(id))||id)} · ${esc((S.ed.get(id)||{}).titulo||'')}</option>`).join('')}</select>
      <label class="check"><input type="checkbox" id="evocar" ${S.evocar?'checked':''}> Evocar antes de ler</label>
      <button class="btn ghost small" data-mtodos="1">Abrir tudo</button><button class="btn ghost small" data-mtodos="0">Fechar tudo</button>
      ${((S.rv.get(S.mapaId)||{}).cartoes||[]).length?`<button class="lnk" data-ir-cart="${esc(S.mapaId)}">Revisão ativa · ${(S.rv.get(S.mapaId).cartoes||[]).length}</button>`:''}</div>
    <p class="rule">Toque num ramo com ⓘ para abrir a explicação. Com "Evocar antes de ler", tente explicar antes de abrir.</p>
    <div class="m-centro">${esc(m.centro||t.titulo||'')}</div>
    <div class="m-grid">${ramos}</div>
    ${m.autor?`<p class="rule">${esc(m.autor)}</p>`:''}
  </div>`;
}
/* aba Pegadinhas: cada armadilha da banca, por matéria e tópico, ligada a um item C/E que a testa */
const PG_TIPO={alcance:'Palavra de alcance',troca:'Troca de conceitos',excecao:'Regra × exceção',literalidade:'Literalidade',jurisprudencia:'Jurisprudência',relacao:'Relação lógica',extrapolacao:'Extrapolação',composicao:'Composição',reescrita:'Reescrita',verdade:'Verdade que parece erro'};
/* mecanismos de falsificação do Cebraspe (claude/Taxonomia_Falsificacao_Cebraspe.md, v1) */
const MEC={
  F1:{n:'Generalização',o:'Amplia o alcance da regra além do que a fonte permite.',s:'sempre, nunca, todos, qualquer, independentemente',v:'Procure a exceção que a palavra absoluta apaga.'},
  F2:{n:'Restrição indevida',o:'Diz que a regra só vale num caso quando vale em outros.',s:'apenas, somente, exclusivamente, só',v:'Pergunte: existe outro caso que a fonte admite?'},
  F3:{n:'Troca de conceito',o:'Substitui um termo, instituto, órgão ou classificação por um vizinho parecido.',s:'pares próximos: privativo × exclusivo, nulo × anulável, adjetiva × adverbial',v:'Leia o substantivo-chave e confira se é exatamente o da regra.'},
  F4:{n:'Detalhe alterado',o:'Muda prazo, número, quórum, percentual, órgão ou o verbo de dever.',s:'números, prazos, “mais de” × “no mínimo”, pode × deve',v:'Todo número e todo prazo do item precisam bater com a fonte.'},
  F5:{n:'Regra × exceção',o:'Apresenta a exceção como regra, ou a regra como se não tivesse exceção.',s:'“em regra”, “salvo”, ou a falta deles',v:'Lembre se a regra tem ressalva e se o item a respeita.'},
  F6:{n:'Relação lógica alterada',o:'Muda causa, condição, concessão, finalidade, ordem ou negação entre duas partes verdadeiras.',s:'porque, portanto, desde que, embora, a fim de, não',v:'Cada parte pode ser verdadeira; confira a ligação entre elas.'},
  F7:{n:'Extrapolação',o:'Conclui o que o texto ou a regra não autoriza.',s:'infere-se, conclui-se, o autor defende',v:'Só vale o que o texto diz ou implica necessariamente.'},
  F8:{n:'Fonte superada',o:'Cobra a lei contra a jurisprudência (ou o contrário), posição minoritária ou texto revogado.',s:'“segundo o STF”, redação anterior a emenda',v:'Pergunte qual é a fonte e se ela ainda vale.'},
  F9:{n:'Composição',o:'Junta uma parte certa e uma errada na mesma frase.',s:'e, bem como, além de, ponto e vírgula',v:'Julgue cada parte; basta uma errada.'},
  F10:{n:'Reescrita',o:'Propõe reescrita que muda o sentido ou quebra a correção.',s:'“mantém a correção e o sentido”',v:'Teste sentido e gramática separadamente.'},
  V1:{n:'Paráfrase fiel',o:'Redação diferente da lei ou da aula, com o mesmo sentido.',s:'sinônimos, ordem invertida',v:'Compare o sentido, não as palavras.'},
  V2:{n:'Incompleto não é errado',o:'Cita só parte da regra, sem dizer que é a única.',s:'um requisito, um exemplo',v:'Incompleto é certo, salvo se disser “apenas”.'},
  V3:{n:'Alcance verdadeiro',o:'Usa “sempre”, “nunca” ou “apenas” onde a regra é mesmo absoluta.',s:'palavra absoluta em regra absoluta',v:'Conheça as poucas regras realmente absolutas.'},
  V4:{n:'Exceção real',o:'Cobra uma exceção verdadeira que soa estranha.',s:'caso surpreendente, mas previsto',v:'Lembre as exceções que a banca adora.'}
};
const MEC_ORD=['F3','F6','F1','F9','F2','F5','F7','F4','F8','F10','V1','V4','V3','V2'];
const SIG_MAT={LP:'Língua Portuguesa',LI:'Língua Inglesa',DC:'Direito Constitucional e Regimento',PL:'Processo Legislativo',DA:'Direito Administrativo e Adm. Pública',TI:'Tecnologia da Informação',LG:'Linguística e Lógica',RF:'Reconhecimento de Fala',CP:'Ciência Política',OUTRA:'Fora do edital ARR'};
/* mecanismo e vacina de um item: o próprio campo, ou a classificação dos itens antigos (analise/CONTROLE) */
function mecDe(q){if(!q) return null; if(q.mecanismo) return {m:q.mecanismo,v:q.vacina||'',e:q.evidencia||''}; return S.mecQ.get(q.id)||null}
function idsDoMec(code){return [...S.q.values()].filter(q=>{const x=mecDe(q);return x&&x.m===code&&(!S.fMecMat||materiaDaQuestao(q)===S.fMecMat)}).map(q=>q.id)}
function materiaDaQuestao(q){const m=String(q.cap||'').match(/^BANCA-(\w+)/); if(m) return m[1]; const t=topicoDoCap(q.cap); return t?t.sigla:''}
function taxaPessoal(code){let n=0,ok=0;for(const id of idsDoMec(code)){const r=S.r.get(id),q=S.q.get(id);if(r&&r.tentativas&&r.ultimaMarcada!=='B'){n++;if(r.ultimaMarcada===q.gabarito)ok++;}}return {n,ok}}
function viewMecanismos(){
  const rk=S.an.get('ranking');
  if(!rk) return `<div class="notice"><strong>A análise dos mecanismos ainda não foi gravada.</strong> Ela é feita no Code e fica na coleção "analise".</div>`;
  const geral=new Map((rk.geral||[]).map(x=>[x.mecanismo,x]));
  const porMat=new Map(); for(const x of (rk.porMateria||[])){ if(!porMat.has(x.materia)) porMat.set(x.materia,[]); porMat.get(x.materia).push(x); }
  const mats=[...porMat.keys()].filter(k=>k!=='OUTRA');
  const matOpts=`<option value="">Todas as matérias</option>`+mats.map(k=>`<option value="${esc(k)}" ${S.fMecMat===k?'selected':''}>${esc(SIG_MAT[k]||k)}</option>`).join('');
  /* exemplos reais por mecanismo, dos itens das provas */
  const ex=new Map();
  for(const [id,doc] of S.an){ if(id==='ranking') continue; for(const it of (doc.itens||[])){ if(!it.mecanismo||it.anulado||!it.evidencia) continue; if(S.fMecMat&&it.materia!==S.fMecMat) continue; if(!ex.has(it.mecanismo)) ex.set(it.mecanismo,[]); const l=ex.get(it.mecanismo); if(l.length<2&&it.confianca!=='baixa') l.push({...it,doc:doc.titulo}); } }
  const linha=code=>{
    const g=geral.get(code), d=MEC[code]; if(!d) return '';
    const nMat=S.fMecMat?((porMat.get(S.fMecMat)||[]).find(x=>x.mecanismo===code)||{n:0,pct:0}):g;
    const tx=taxaPessoal(code), ids=idsDoMec(code);
    const key='mec:'+code, oc=S.evocar&&!S.revelados.has(key);
    const exs=(ex.get(code)||[]).map(e=>`<li>“${esc(e.evidencia)}” <span class="exn">${esc(SIG_MAT[e.materia]||e.materia)} · ${esc(e.doc||'')}${typeof e.item==='number'?' · item '+e.item:''}</span></li>`).join('');
    return `<div class="pt pg-${code[0]==='V'?'analitica':'prova'}">
      ${oc?`<button class="pk ev" data-revelar="${esc(key)}">${esc(code)} · ${esc(d.n)}</button>`:`<span class="pk">${esc(code)} · ${esc(d.n)}</span>`}
      <div class="pills"><span class="pill p">Na banca: ${nMat?nMat.n:0} ${S.fMecMat?'itens na matéria':'itens'} · ${nMat?String(nMat.pct).replace('.',','):'0'}%</span>
        <span class="pill ${tx.n>=20&&tx.ok/tx.n<0.7?'e':''}">Você: ${tx.n?`${tx.ok}/${tx.n} (${fmtPct(tx.ok/tx.n)})${tx.n<20?' · poucos dados':''}`:'ainda sem respostas'}</span></div>
      ${oc?'':`<p class="pd">${esc(d.o)}</p><p class="ptr">Sinais: ${esc(d.s)}. Vacina: ${esc(d.v)}</p>${exs?`<ul class="exl">${exs}</ul>`:''}`}
      ${ids.length?`<div class="row"><button class="lnk" data-mec-treinar="${esc(code)}">Treinar ${ids.length} ${ids.length===1?'item':'itens'} deste mecanismo, intercalados</button></div>`:''}
    </div>`;
  };
  const matriz=mats.map(k=>{const l=porMat.get(k)||[];const tot=l[0]?l[0].total:0;return `<tr><td>${esc(SIG_MAT[k]||k)}</td><td class="num">${tot}</td>${[0,1,2].map(i=>l[i]?`<td>${esc(l[i].mecanismo)} · ${esc((MEC[l[i].mecanismo]||{}).n||'')} <span class="mono" style="color:var(--muted)">${String(l[i].pct).replace('.',',')}%</span></td>`:'<td>–</td>').join('')}</tr>`}).join('');
  return `<div style="display:flex;flex-direction:column;gap:14px">
    <p class="rule">Como o Cebraspe fabrica itens errados e quais itens certos parecem errados, a partir de ${rk.totalValidos} itens reais classificados (provas da Câmara de 2026 e questões Cebraspe das aulas). ${esc(rk.metodo||'')} Taxonomia ${esc(rk.taxonomia||'v1')}, calculada em ${rk.calculadoEm?ddmm(rk.calculadoEm):'–'}.</p>
    <div class="filters"><select id="f-mecmat" aria-label="Matéria">${matOpts}</select></div>
    <h2 class="section-title">Onde cada matéria arma a pegadinha · 3 mecanismos mais frequentes</h2>
    <div class="tbl-wrap"><table><thead><tr><th>Matéria</th><th class="num">Itens</th><th>1º</th><th>2º</th><th>3º</th></tr></thead><tbody>${matriz}</tbody></table></div>
    <h2 class="section-title">Itens errados: como a banca falsifica</h2>
    <div class="pts" style="padding-left:0">${MEC_ORD.filter(c=>c[0]==='F').map(linha).join('')}</div>
    <h2 class="section-title">Itens certos que parecem errados</h2>
    <div class="pts" style="padding-left:0">${MEC_ORD.filter(c=>c[0]==='V').map(linha).join('')}</div>
    <p class="rule">"Você" é o seu acerto na última resposta dos itens de cada mecanismo. A comparação com a banca só vale com 20 respostas ou mais. Treinar por mecanismo, misturando matérias, ensina a reconhecer o truque em qualquer assunto.</p>
  </div>`;
}
function treinarMec(code){
  const fila=idsDoMec(code); if(!fila.length) return;
  for(let i=fila.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[fila[i],fila[j]]=[fila[j],fila[i]]}
  setView('treinar');
  novaRodada('PEG',`Mecanismo ${code} · ${(MEC[code]||{}).n||''}${S.fMecMat?' · '+(SIG_MAT[S.fMecMat]||S.fMecMat):''}`,'pegadinhas',fila);
}
const PG_ORIG={registrada:'Você errou aqui',prova:'Caiu em prova',analitica:'Análise do Claude'};
function pgsDe(id){return [...S.pg.values()].filter(p=>p.topico===id).sort((a,b)=>a.id.localeCompare(b.id,'pt',{numeric:true}))}
function qidsPg(ps){return [...new Set(ps.flatMap(p=>p.qids||[]))].filter(id=>S.q.has(id))}
function estadoItem(qid){
  const r=S.r.get(qid), q=S.q.get(qid);
  if(!q) return '';
  if(!r||!r.tentativas) return '<span class="pill">Item não respondido</span>';
  if(r.noCaderno) return `<span class="pill e">Item no caderno de erros</span>`;
  return r.ultimaMarcada===q.gabarito?'<span class="pill c">Último: acertou</span>':'<span class="pill e">Último: errou</span>';
}
function viewPegadinhas(){
  if(!S.edLoaded) return `<div class="notice">Carregando…</div>`;
  const seg=`<div class="row"><div class="seg" role="group" aria-label="Visão"><button data-pgmodo="mec" aria-pressed="${S.pgModo==='mec'}">Mecanismos da banca</button><button data-pgmodo="top" aria-pressed="${S.pgModo!=='mec'}">Pegadinhas por tópico</button></div>
    <label class="check"><input type="checkbox" id="evocar" ${S.evocar?'checked':''}> Evocar antes de ler</label></div>`;
  if(S.pgModo==='mec') return `<div class="wrap" style="gap:14px">${seg}${viewMecanismos()}</div>`;
  return `<div class="wrap" style="gap:14px">${seg}${viewPegadinhasTopicos()}</div>`;
}
function viewPegadinhasTopicos(){
  if(!S.pg.size) return `<div class="notice"><strong>Nenhuma pegadinha registrada ainda.</strong> Peça ao Claude, no Code, "/pegadinhas" com o tópico ou a matéria (por exemplo, "/pegadinhas dc-2d"). Cada pegadinha entra aqui ligada a um item C/E.</div>`;
  const gs=porMateria();
  const vis=p=>(!S.fPgTipo||p.tipo===S.fPgTipo);
  const comPg=t=>pgsDe(t.id).some(vis);
  const opts=`<option value="">Todas as matérias</option>`+gs.filter(g=>g.ts.some(x=>pgsDe(x.t.id).length)).map(g=>`<option value="${esc(g.sigla)}" ${S.fPgMat===g.sigla?'selected':''}>${esc(g.nome)}</option>`).join('');
  const tOpts=`<option value="">Todos os tipos</option>`+Object.entries(PG_TIPO).map(([k,v])=>`<option value="${k}" ${S.fPgTipo===k?'selected':''}>${esc(v)}</option>`).join('');
  let html='', nP=0, todos=[];
  for(const p of ['P1','P2']){
    for(const g of gs.filter(g=>g.prova===p&&(!S.fPgMat||g.sigla===S.fPgMat))){
      const ts=g.ts.map(x=>x.t).filter(comPg);
      if(!ts.length) continue;
      const nG=ts.reduce((a,t)=>a+pgsDe(t.id).filter(vis).length,0);
      html+=`<details class="mat-g" data-grupo="pg:${esc(g.sigla)}" ${S.abertos.has('pg:'+g.sigla)||S.fPgMat?'open':''}><summary><span class="gn">${esc(g.nome)}</span><span></span><span class="mono" style="font-size:12.5px;color:var(--muted)">${ts.length} ${ts.length===1?'tópico':'tópicos'} · ${nG} ${nG===1?'pegadinha':'pegadinhas'}</span></summary>`;
      for(const t of ts){
        const ps=pgsDe(t.id).filter(vis); nP+=ps.length;
        const ids=qidsPg(ps); todos=todos.concat(ids);
        let corpo='';
        for(const pg of ps){
          const key='pg:'+pg.id, oc=S.evocar&&!S.revelados.has(key);
          const par=(pg.par||[]).length?`<div class="chips-t">${pg.par.map(x=>`<span class="tchip">${esc(x)}</span>`).join('<span class="ps">×</span>')}</div>`:'';
          const itens=(pg.qids||[]).map(estadoItem).join('');
          corpo+=`<div class="pt pg-${esc(pg.origem||'analitica')}">
            ${oc?`<button class="pk ev" data-revelar="${esc(key)}">${esc(pg.armadilha)}</button>`:`<span class="pk">${esc(pg.armadilha)}</span>`}
            ${oc?'':`${par}<p class="pd">${esc(pg.regra)}</p>${pg.sinal?`<p class="ptr">Sinal: ${esc(pg.sinal)}</p>`:''}
            <div class="pills"><span class="pill">${esc(PG_TIPO[pg.tipo]||pg.tipo||'')}</span><span class="pill ${pg.origem==='registrada'?'e':pg.origem==='prova'?'p':''}">${esc(PG_ORIG[pg.origem]||pg.origem||'')}${pg.origem==='prova'&&pg.fonteProva?' · '+esc(pg.fonteProva):''}</span>${itens}</div>
            ${pg.ref?`<span class="ps">${esc(pg.ref)}</span>`:''}`}</div>`;
        }
        html+=`<details class="rv-top" id="pg-${esc(t.id)}" data-grupo="pgt:${esc(t.id)}" ${S.abertos.has('pgt:'+t.id)?'open':''}>
          <summary class="t-h"><span class="t-num">${esc(t.num)}</span><span class="t-tit">${esc(t.titulo)} <span class="mono" style="font-size:12px;color:var(--muted)">· ${ps.length} ${ps.length===1?'pegadinha':'pegadinhas'}</span></span></summary>
          <div class="t-meta">${ids.length?`<button class="lnk" data-pg-treinar="${esc(t.id)}">Treinar ${ids.length} ${ids.length===1?'item':'itens'}</button>`:''}</div>
          <div class="pts">${corpo}</div></details>`;
      }
      html+=`</details>`;
    }
  }
  todos=[...new Set(todos)];
  return `<div style="display:flex;flex-direction:column;gap:14px">
    <div class="filters"><select id="f-pgmat" aria-label="Matéria">${opts}</select><select id="f-pgtipo" aria-label="Tipo de pegadinha">${tOpts}</select></div>
    <div class="row">${todos.length?`<button class="btn small" data-pg-treinar="*">Treinar as ${todos.length} filtradas, intercaladas</button>`:''}<button class="btn ghost small" id="pg-abrir">Abrir tudo</button><button class="btn ghost small" id="pg-fechar">Fechar tudo</button></div>
    <p class="rule">${nP} ${nP===1?'pegadinha':'pegadinhas'}, cada uma ligada a um item C/E.</p>
    ${html||'<div class="notice">Nenhuma pegadinha com esse filtro.</div>'}
  </div>`;
}
function treinarPg(id){
  let ps=[...S.pg.values()].filter(p=>(!S.fPgTipo||p.tipo===S.fPgTipo));
  if(id==='*') ps=ps.filter(p=>{const t=S.ed.get(p.topico);return !S.fPgMat||(t&&t.sigla===S.fPgMat)});
  else ps=ps.filter(p=>p.topico===id);
  const fila=qidsPg(ps); if(!fila.length) return;
  if(id==='*'||S.shuffle){ for(let i=fila.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[fila[i],fila[j]]=[fila[j],fila[i]]} }
  const t=S.ed.get(id);
  setView('treinar');
  novaRodada('PEG',t?`Pegadinhas · ${lblT(t)} ${t.titulo}`:'Pegadinhas intercaladas','pegadinhas',fila);
}
/* aba Conteúdo: materiais gerados para complementar o estudo */
function viewConteudo(){
  if(!S.edLoaded) return `<div class="notice">Carregando…</div>`;
  const mats=[...S.mat.values()].filter(m=>m.tipo==='material'||m.tipo==='cobertura');
  const fontes=[...S.mat.values()].filter(m=>m.tipo==='fonte'||m.tipo==='metodo');
  const ordem=m=>{const t=S.ed.get((m.topicos||[])[0]);return t?t.ordem:9999};
  const grupos=new Map();
  for(const m of mats.sort((a,b)=>ordem(a)-ordem(b)||(a.tipo==='material'?-1:1))){
    const t=S.ed.get((m.topicos||[])[0]); const k=t?t.materia:'Outros';
    if(!grupos.has(k)) grupos.set(k,[]); grupos.get(k).push(m);
  }
  let html='';
  for(const [mat,ms] of grupos){
    html+=`<details class="mat-g" data-grupo="ct:${esc(mat)}" ${S.abertos.has('ct:'+mat)?'open':''}><summary><span class="gn">${esc(mat)}</span><span></span><span class="mono" style="font-size:12.5px;color:var(--muted)">${ms.length} ${ms.length===1?'material':'materiais'}</span></summary>`;
    for(const m of ms){
      const tops=(m.topicos||[]).map(id=>S.ed.get(id)).filter(Boolean);
      html+=`<article class="ct">
        <div class="ct-h"><span class="mono" style="font-size:13px;font-weight:600">${tops.map(t=>esc(t.num)).join(', ')}</span><span class="mtype">${esc(MTIPO[m.tipo]||m.tipo)}</span></div>
        <a class="ct-t" href="${esc(m.url)}" target="_blank" rel="noopener">${esc(m.titulo)}</a>
        ${m.descricao?`<p class="pd">${esc(m.descricao)}</p>`:''}
        ${(m.secoes||[]).length?`<ol class="ct-s">${m.secoes.map(s=>`<li>${esc(s)}</li>`).join('')}</ol>`:''}
        <span class="ps">${m.chat?`chat ${esc(m.chat)}`:''}${m.criadoEm?` · ${ddmm(m.criadoEm)}`:''}</span>
      </article>`;
    }
    html+=`</details>`;
  }
  const fh=fontes.length?`<h2 class="section-title">Fontes do projeto</h2><div class="mat-l">${fontes.map(m=>`<div class="mat"><span class="mt">${m.url?`<a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(m.titulo)}</a>`:esc(m.titulo)}</span><span class="mtype">${(m.topicos||[]).map(id=>esc(lblT(S.ed.get(id))||id)).join(', ')||esc(MTIPO[m.tipo]||'')}</span></div>`).join('')}</div>`:'';
  return `<div class="wrap" style="gap:14px">
    ${html||'<div class="notice">Nenhum material gerado ainda.</div>'}
    ${fh}
  </div>`;
}
function viewPontos(t,doc){
  if(!doc||!(doc.itens||[]).length) return '';
  let html='', g=null;
  doc.itens.forEach((p,i)=>{
    if(p.grupo&&p.grupo!==g){ g=p.grupo; html+=`<span class="pts-g">${esc(g)}</span>`; }
    const key=t.id+'#'+i, oculto=S.evocar&&!S.revelados.has(key);
    html+=`<div class="pt">${oculto?`<button class="pk ev" data-revelar="${esc(key)}">${esc(p.k)}</button>`:`<span class="pk">${esc(p.k)}</span>`}
      ${oculto?'':`<p class="pd">${esc(p.d)}</p>${p.trap?`<p class="ptr">Pegadinha: ${esc(p.trap)}</p>`:''}${p.src?`<span class="ps">${esc(p.src)}</span>`:''}`}</div>`;
  });
  const f=(doc.fontes||[]).map(x=>x.url?`<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.titulo)}</a>`:esc(x.titulo)).join(' · ');
  return `<div class="pts">${html}${f?`<span class="ps">Fonte: ${f}</span>`:''}</div>`;
}
function salvarStatus(id,val){
  const t=S.ed.get(id); if(!t) return;
  const v=ST[val]?val:null;
  S.ed.set(id,Object.assign({},t,{status:v})); render(true);
  enqueue(()=>S.db.doc('edital/'+id).update({status:v,statusEm:new Date().toISOString()}));
}

function viewMetodo(){
  return `<div class="wrap metodo">
    <p class="rule">Resumo do documento Metodo_de_Estudo.md do projeto. É o mesmo método que o Claude aplica nos chats de cada matéria.</p>
    <h2 class="section-title">Como usar este caderno</h2>
    <ol>
      <li><b>Comece pela revisão de hoje.</b> Ela mistura capítulos de propósito: escolher qual regra se aplica faz parte do treino. <span class="src">Fixe o Conhecimento · intercalação</span></li>
      <li><b>Marque a confiança antes do gabarito.</b> Errar com certeza é o sinal mais importante do caderno. <span class="src">Fixe o Conhecimento · calibração</span></li>
      <li><b>Depois do erro, marque de onde ele veio.</b> Cada origem pede um remédio diferente.</li>
      <li><b>Justifique todo erro antes de seguir.</b> Errou, deixou em branco ou chutou: o Caderno só libera o próximo item depois que você marca de onde veio o erro e escreve, com as suas palavras, por que errou e qual é a regra certa. A justificativa fica guardada no caderno de erros. <span class="src">Geração e elaboração · Fixe o Conhecimento</span></li>
      <li><b>Escreva a regra com as suas palavras.</b> Copiar o comentário não conta; explicar e dar um exemplo próprio, sim. <span class="src">Você Sabe Estudar? · estudo ativo</span></li>
      <li><b>Não releia o PDF para revisar.</b> Reler e grifar dão a sensação de domínio sem fixar. Volte às questões. <span class="src">Otimize seu Aprendizado</span></li>
      <li><b>Treine as pegadinhas de memória.</b> Na aba Pegadinhas, com "Evocar antes de ler", explique por que a armadilha engana antes de abrir a regra, e depois responda o item ligado. Distinguir regras parecidas lado a lado é o remédio para os erros de interferência. <span class="src">Fixe o Conhecimento · intercalação e discriminação</span></li>
      <li><b>Leia devagar o que parece óbvio.</b> As palavras de alcance aparecem destacadas depois da resposta para treinar o olho. <span class="src">Rápido e Devagar · Sistema 2</span></li>
      <li><b>Itens Errados: corrija antes do gabarito.</b> Ao marcar E, reescreva a assertiva certa no campo opcional. Corrigir a afirmação falsa melhora a retenção quando há feedback depois. <span class="src">Uner, Tekin e Roediger, 2022</span></li>
      <li><b>Certeza só quando souber dizer por quê.</b> A aba Hoje mostra o seu acerto com certeza nos últimos 14 dias; a meta é 90% ou mais. <span class="src">Fixe o Conhecimento · calibração</span></li>
      <li><b>Videoaulas: pausa de evocação.</b> A cada bloco de 15 a 20 minutos, pare e responda de memória 3 a 5 perguntas sobre o que acabou de ver. Isso reduziu a divagação de cerca de 40% para 19% e elevou o teste final de 68% para 90%. <span class="src">Szpunar, Khan e Schacter, 2013</span></li>
      <li><b>Celular em outro cômodo.</b> A simples presença do celular sobre a mesa reduziu a capacidade cognitiva disponível. <span class="src">Ward et al., 2017 · Otimize seu Aprendizado</span></li>
      <li><b>Próximo passo no formato "quando/onde → farei".</b> Ex.: "amanhã, às 7h, na mesa: revisão de hoje e DC 1.4". Intenções de implementação aumentam a chance de cumprir o plano. <span class="src">Gollwitzer e Sheeran, 2006</span></li>
      <li><b>No simulado, reconsidere e troque quando tiver motivo.</b> Trocas costumam ir mais de errado para certo do que o contrário; o resultado mostra o seu saldo. <span class="src">Kruger, Wirtz e Miller, 2005</span></li>
      <li><b>Na prova, marque só acima de 50%.</b> Com +1, −1 e 0, o ganho esperado é 2 × acerto − 1. A aba Desempenho mostra o seu acerto real em cada nível de confiança. <span class="src">Critério do edital</span></li>
    </ol>
    <h2 class="section-title">Status dos tópicos</h2>
    <ul>
      <li>Vale o maior entre o Controle e o Tutory. Em estudo: há material, mapa, questões ou estudo/resumo marcado no Tutory. Revisando: 80% das questões feitas, ou revisão e exercício iniciados no Tutory.</li>
      <li>Dominado, só pelo Controle: 80% das questões feitas, 85% de acerto na última resposta, nada no caderno de erros e cada questão acertada (sem chute) numa revisão feita 7 dias ou mais depois do primeiro contato.</li>
      <li>Você pode fixar o status à mão em Edital → Detalhes.</li>
    </ul>
    <h2 class="section-title">Regras da agenda</h2>
    <ul>
      <li>Erro, branco ou chute: o item volta amanhã e fica no caderno.</li>
      <li>Repescagem: no fim de cada rodada, os itens errados, em branco ou acertados no chute aparecem mais uma vez. Não contam no placar.</li>
      <li>Acerto com certeza: volta em 7 dias no mínimo, depois 15 e 30.</li>
      <li>Acerto com dúvida: volta em 3 dias no mínimo.</li>
      <li>No máximo 40 revisões por dia. Os erros do caderno entram primeiro; os acertos que sobrarem passam para os dias seguintes.</li>
      <li>Nenhum intervalo passa de 20% dos dias que faltam para a prova. Quanto mais perto da prova, mais curtos ficam.</li>
      <li>Saída do caderno: dois acertos seguidos sem chute, em dias diferentes. O item continua na agenda.</li>
      <li>A partir de 10/01/2027, tudo que estiver na agenda vira revisão diária até a prova.</li>
      <li>Cartões de revisão ativa (07/11/2026): depois de responder e virar, marque Novamente (volta no fim da sessão e amanhã), Difícil, Bom ou Fácil. O espaçamento segue a mesma escada das questões (1, 3, 7, 15 e 30 dias, com o teto de 20% dos dias até a prova): Bom sobe um degrau, Fácil sobe dois, Difícil repete o degrau e Novamente volta ao início. Por dia: até 50 revisões de cartões, priorizando os Novamente e os mais atrasados, e até 50 cartões novos. As questões também passam a 50 revisões por dia. Os cartões que excederem o limite ficam para o dia seguinte.</li>
    </ul>
    <h2 class="section-title">O que a pesquisa mostra</h2>
    <ul>
      <li><b>Testar fixa mais que reler.</b> Uma semana depois, 56% de recordação para quem fez teste contra 42% para quem releu. Cinco minutos depois, reler parecia melhor (81% contra 75%). <span class="src">Roediger e Karpicke, 2006</span></li>
      <li><b>O feedback quase dobra o efeito.</b> Testes com correção: g = 0,73; sem correção: g = 0,39. Por isso todo item tem comentário. <span class="src">Rowland, 2014 · meta-análise</span></li>
      <li><b>Erro com certeza é o que mais se corrige</b> depois de ver o gabarito, porque a surpresa prende a atenção. <span class="src">Butterfield e Metcalfe, 2001</span></li>
      <li><b>O melhor intervalo encolhe com a proximidade da prova.</b> Com 70 dias até a prova, cerca de 12; com 35 dias, cerca de 8. Errar para mais custa menos que errar para menos. <span class="src">Cepeda et al., 2008</span></li>
      <li><b>Acertar em várias sessões vale mais que repetir na mesma.</b> 68% contra 26% de retenção depois de uma semana. <span class="src">Rawson et al., 2018</span></li>
      <li><b>Misturar ajuda a distinguir o que se parece.</b> Uma semana depois, 63% contra 20%, embora a prática misturada pareça pior na hora. O efeito vale para conceitos parecidos, não para texto novo. <span class="src">Rohrer e Taylor, 2007 · Brunmair e Richter, 2019</span></li>
      <li><b>Mapa mental só ajuda se for feito de memória.</b> Mapas montados de memória rendem como escrever de memória, e mais do que estudar com o texto aberto. <span class="src">Blunt e Karpicke, 2014</span></li>
      <li><b>A sensação de "já sei" engana.</b> Quem releu quatro vezes previa lembrar mais e lembrou menos (40% contra 61%). <span class="src">Roediger e Karpicke, 2006</span></li>
    </ul>
    <p class="rule">Referências completas no documento Metodo_de_Estudo.md do projeto, seção 12.</p>
    <h2 class="section-title">As quatro obras</h2>
    <div class="books">
      <div class="book"><span class="bt">Fixe o Conhecimento</span><span class="ba">Brown, Roediger e McDaniel</span><span class="bu">Autoteste, espaçamento, intercalação e dificuldades desejáveis.</span></div>
      <div class="book"><span class="bt">Otimize seu Aprendizado</span><span class="ba">Daniel T. Willingham</span><span class="bu">O que o cérebro faz por padrão ao estudar e como contornar.</span></div>
      <div class="book"><span class="bt">Você Sabe Estudar?</span><span class="ba">Claudio de Moura Castro</span><span class="bu">Estudo ativo, hábito, leitura com perguntas e anotações próprias.</span></div>
      <div class="book"><span class="bt">Rápido e Devagar</span><span class="ba">Daniel Kahneman</span><span class="bu">Sistema 1 e Sistema 2: por que a resposta óbvia engana na prova.</span></div>
    </div>
  </div>`;
}

/* ---------- ações ---------- */
function wire(){
  document.querySelectorAll('[data-cap]').forEach(b=>b.addEventListener('click',()=>{S.cap=b.dataset.cap;S.capEscolhido=true;render(true)}));
  document.querySelectorAll('input[name="modo"]').forEach(i=>i.addEventListener('change',()=>{S.modo=i.value;render(true)}));
  const sh=$('#shuffle'); if(sh) sh.addEventListener('change',()=>{S.shuffle=sh.checked});
  const st=$('#start'); if(st) st.addEventListener('click',()=>startRound(S.cap,S.modo));
  const sr=$('#start-rev'); if(sr) sr.addEventListener('click',startRevisao);
  const rm=$('#rev-mais'); if(rm) rm.addEventListener('click',()=>{S.revExtra=(S.revExtra||0)+20;render(true)});
  document.querySelectorAll('[data-ans]').forEach(b=>b.addEventListener('click',()=>marcar(b.dataset.ans)));
  document.querySelectorAll('[data-conf]').forEach(b=>b.addEventListener('click',()=>confirmar(Number(b.dataset.conf))));
  document.querySelectorAll('[data-origem]').forEach(b=>b.addEventListener('click',()=>salvarOrigem(b.dataset.origem,b.dataset.val)));
  const jt=$('#just-txt'); if(jt){ jt.addEventListener('input',()=>{const rd=S.round; if(!rd) return; rd.just=jt.value; const id=jt.dataset.just, ok=justOk(rd,id); const c=$('#just-cnt'); if(c) c.textContent=justMsg(rd.just.trim().length,(S.r.get(id)||{}).origem); const b=$('#next'); if(b) b.disabled=!ok;}); if(S.r.get(jt.dataset.just)?.origem) jt.focus({preventScroll:true}); }
  document.querySelectorAll('[data-heat]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.heat;S.abertos.add(b.dataset.sig);if(S.fSt)S.fSt='';render(true);requestAnimationFrame(()=>{const el=document.getElementById('tp-'+id);if(!el)return;el.scrollIntoView({behavior:'smooth',block:'center'});el.classList.add('flash');setTimeout(()=>el.classList.remove('flash'),1800)})}));
  const crt=$('#corr-txt'); if(crt) crt.addEventListener('input',()=>{if(S.round) S.round.corr=crt.value});
  const nx=$('#next'); if(nx){ nx.addEventListener('click',next); if(!document.activeElement||document.activeElement===document.body||document.activeElement.dataset.conf) nx.focus({preventScroll:true}); }
  const qt=$('#quit'); if(qt) qt.addEventListener('click',()=>{const rd=S.round; if(rd&&rd.atual&&exigeJust(rd.atual)&&!justOk(rd,rd.fila[rd.idx])){toast('Justifique este erro antes de encerrar a rodada.');return} if(rd&&rd.atual&&exigeJust(rd.atual)){next(); if(S.round&&!S.round.fim){finalizar();} render(true); return} finalizar();render(true)});
  const gc=$('#go-caderno'); if(gc) gc.addEventListener('click',()=>{S.round=null;setView('caderno')});
  const ag=$('#again'); if(ag) ag.addEventListener('click',()=>{S.round=null;render(true)});
  document.querySelectorAll('[data-revisar]').forEach(b=>b.addEventListener('click',()=>{S.cap=b.dataset.revisar;S.capEscolhido=true;S.modo='caderno';setView('treinar');startRound(S.cap,'caderno')}));
  document.querySelectorAll('[data-tirar]').forEach(b=>b.addEventListener('click',()=>tirar(b.dataset.tirar)));
  document.querySelectorAll('textarea[data-nota]').forEach(t=>{
    let timer;
    t.addEventListener('input',()=>{clearTimeout(timer);const id=t.dataset.nota;$('#saved-'+CSS.escape(id)).textContent='…';timer=setTimeout(()=>salvarNota(id,t.value),900)});
    t.addEventListener('blur',()=>{clearTimeout(timer);salvarNota(t.dataset.nota,t.value);if(S.pendingRender)setTimeout(()=>render(),0)});
  });
  document.querySelectorAll('[data-ir-materia]').forEach(b=>b.addEventListener('click',()=>{S.fMat=b.dataset.irMateria;S.fSt='';setView('edital');window.scrollTo({top:0})}));
  const md=$('#mais-diario'); if(md) md.addEventListener('click',()=>{S.mostrarDiario=!S.mostrarDiario;render(true)});
  const fm=$('#f-mat'); if(fm) fm.addEventListener('change',()=>{S.fMat=fm.value;render(true)});
  const fs=$('#f-st'); if(fs) fs.addEventListener('change',()=>{S.fSt=fs.value;render(true)});
  const ev=$('#evocar'); if(ev) ev.addEventListener('change',()=>{S.evocar=ev.checked;S.revelados.clear();render(true)});
  document.querySelectorAll('details[data-grupo]').forEach(d=>d.addEventListener('toggle',()=>{if(d.open)S.abertos.add(d.dataset.grupo);else S.abertos.delete(d.dataset.grupo)}));
  document.querySelectorAll('[data-status]').forEach(s=>s.addEventListener('change',()=>salvarStatus(s.dataset.status,s.value)));
  document.querySelectorAll('[data-ir-mapa]').forEach(b=>b.addEventListener('click',()=>{S.mapaId=b.dataset.irMapa;S.mapaAb=null;S.revelados.clear();setView('mapa');window.scrollTo({top:0})}));
  document.querySelectorAll('[data-mx]').forEach(b=>b.addEventListener('click',()=>{const k=b.dataset.mx;S.mapaX=S.mapaX||new Set();if(S.mapaX.has(k))S.mapaX.delete(k);else S.mapaX.add(k);render(true)}));
  document.querySelectorAll('[data-mtog]').forEach(b=>b.addEventListener('click',()=>{const k=b.dataset.mtog;S.mapaAb=S.mapaAb||new Set();if(S.mapaAb.has(k))S.mapaAb.delete(k);else S.mapaAb.add(k);render(true)}));
  document.querySelectorAll('[data-mtodos]').forEach(b=>b.addEventListener('click',()=>{S.mapaAb=b.dataset.mtodos==='1'?new Set(['*']):new Set();render(true)}));
  document.querySelectorAll('[data-mir]').forEach(b=>b.addEventListener('click',()=>{const el=document.getElementById('mn-'+b.dataset.mir);if(el){el.scrollIntoView({block:'center'});el.classList.add('m-flash');setTimeout(()=>el.classList.remove('m-flash'),1200)}}));
  const ct=$('#cart-top'); if(ct) ct.addEventListener('change',()=>{S.cartId=ct.value;render(true)});
  const cp=$('#cart-pend'); if(cp) cp.addEventListener('change',()=>{S.cartPend=cp.checked;render(true)});
  document.querySelectorAll('[data-cfech]').forEach(b=>b.addEventListener('click',()=>{const k=b.dataset.cfech;S.cartFech=S.cartFech||new Set();if(S.cartFech.has(k))S.cartFech.delete(k);else S.cartFech.add(k);render(true)}));
  document.querySelectorAll('[data-cf]').forEach(b=>b.addEventListener('click',()=>{S.cartFech=new Set();if(b.dataset.cf==='0'){const rv=S.rv.get(S.cartId);for(const c of (rv&&rv.cartoes)||[])S.cartFech.add(S.cartId+'#'+(c.tema||'Geral'))}render(true)}));
  const cr=$('#cart-reset'); if(cr) cr.addEventListener('click',()=>{for(const k of [...S.cartAbertos]) if(k.startsWith(S.cartId+'@')){S.cartAbertos.delete(k);S.cartRated.delete(k);S.cartResp.delete(k);S.ia.delete(k)}render(true)});
  const mt=$('#mapa-top'); if(mt) mt.addEventListener('change',()=>{S.mapaId=mt.value;S.mapaAb=null;S.revelados.clear();render(true)});
  document.querySelectorAll('[data-ir-rev]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.irRev,t=S.ed.get(id);S.fMat=t?t.sigla:'';if(t)S.abertos.add('rv:'+t.sigla);S.abertos.add('rvt:'+id);setView('revisao');setTimeout(()=>{const el=document.getElementById('rv-'+id);if(el)el.scrollIntoView({block:'start'})},30)}));
  const ra=$('#rv-abrir'); if(ra) ra.addEventListener('click',()=>{for(const t of S.ed.values()){if(S.rv.has(t.id)||S.pt.has(t.id)){S.abertos.add('rv:'+t.sigla);S.abertos.add('rvt:'+t.id)}}render(true)});
  const rf=$('#rv-fechar'); if(rf) rf.addEventListener('click',()=>{for(const k of [...S.abertos]) if(k.startsWith('rv:')||k.startsWith('rvt:')) S.abertos.delete(k); S.fMat=''; render(true)});
  const fe=$('#f-evo'); if(fe) fe.addEventListener('change',()=>{S.fEvo=fe.value;S.evoOff.clear();render(true)});
  document.querySelectorAll('[data-qr]').forEach(r=>{const f=()=>{const k='qr:'+r.dataset.qr;if(S.abertos.has(k))S.abertos.delete(k);else S.abertos.add(k);render(true)};r.addEventListener('click',f);r.addEventListener('keydown',e=>{if(e.key==='Enter')f()})});
  document.querySelectorAll('[data-evoper]').forEach(b=>b.addEventListener('click',()=>{S.evoPer=b.dataset.evoper;render(true)}));
  const ed=$('#evo-de'); if(ed) ed.addEventListener('change',()=>{S.evoDe=ed.value;render(true)});
  const ea=$('#evo-ate'); if(ea) ea.addEventListener('change',()=>{S.evoAte=ea.value;render(true)});
  const el=$('#evo-limpa'); if(el) el.addEventListener('click',()=>{S.evoDe='';S.evoAte='';render(true)});
  document.querySelectorAll('[data-evomodo]').forEach(b=>b.addEventListener('click',()=>{S.evoModo=b.dataset.evomodo;render(true)}));
  document.querySelectorAll('[data-evo]').forEach(b=>b.addEventListener('click',()=>{const c=b.dataset.evo;if(S.evoOff.has(c))S.evoOff.delete(c);else S.evoOff.add(c);render(true)}));
  const tip=$('#evo-tip'), box=document.querySelector('.evo-box');
  document.querySelectorAll('.evo-hit').forEach(c=>{const show=()=>{if(!tip||!box)return;const br=box.getBoundingClientRect(),sv=box.querySelector('svg').getBoundingClientRect();tip.textContent=c.dataset.tip;tip.hidden=false;const tw=tip.offsetWidth;const cx=sv.left-br.left+(+c.dataset.x)*sv.width/box.querySelector('svg').viewBox.baseVal.width;let lx=cx+12;if(lx+tw>br.width)lx=cx-12-tw;lx=Math.max(0,lx);tip.style.left=lx+'px';tip.style.top='12px'};const hide=()=>{if(tip)tip.hidden=true};c.addEventListener('mouseenter',show);c.addEventListener('focus',show);c.addEventListener('mouseleave',hide);c.addEventListener('blur',hide);});
  document.querySelectorAll('[data-sub]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.sub)));
  document.querySelectorAll('[data-ir-cart]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.irCart;if(((S.rv.get(id)||{}).cartoes||[]).length){S.cartId=id;S.cartPend=false;setView('cartoes');window.scrollTo({top:0});return}const t=S.ed.get(id);S.fMat=t?t.sigla:'';S.evocar=true;S.revelados.clear();if(t)S.abertos.add('rv:'+t.sigla);S.abertos.add('rvt:'+id);setView('revisao');setTimeout(()=>{const el=document.getElementById('rv-'+id);if(el)el.scrollIntoView({block:'start'})},30)}));
  document.querySelectorAll('[data-cart-hoje]').forEach(b=>b.addEventListener('click',iniciarMix));
  document.querySelectorAll('[data-cmix-next]').forEach(b=>b.addEventListener('click',()=>{const m=S.cmix;if(!m)return;const k=m.fila[m.idx];m.idx++;S.cartRated.delete(k);S.cartAbertos.delete(k);S.cartResp.delete(k);render(true);window.scrollTo({top:0})}));
  document.querySelectorAll('[data-cmix-sair]').forEach(b=>b.addEventListener('click',()=>{S.cmix=null;render(true)}));
  document.querySelectorAll('[data-cav]').forEach(b=>b.addEventListener('click',()=>salvarAval(b.dataset.cav,b.dataset.v)));
  document.querySelectorAll('[data-cart]').forEach(b=>b.addEventListener('click',()=>{const k=b.dataset.cart;if(S.cartAbertos.has(k)){S.cartAbertos.delete(k);S.cartRated.delete(k);S.cartResp.delete(k);S.ia.delete(k)}else S.cartAbertos.add(k);render(true)}));
  document.querySelectorAll('[data-cresp]').forEach(t=>{t.addEventListener('input',()=>S.cartResp.set(t.dataset.cresp,t.value));t.addEventListener('blur',()=>{if(S.pendingRender)setTimeout(()=>render(),0)})});
  document.querySelectorAll('[data-exab]').forEach(b=>b.addEventListener('click',()=>{const k=b.dataset.exab;if(S.exAb.has(k))S.exAb.delete(k);else S.exAb.add(k);render(true)}));
  document.querySelectorAll('[data-irmapa]').forEach(b=>b.addEventListener('click',()=>irMapa(b.dataset.irmapa)));
  document.querySelectorAll('[data-exia]').forEach(b=>b.addEventListener('click',()=>explicarIA(b.dataset.exia)));
  document.querySelectorAll('[data-ia]').forEach(b=>b.addEventListener('click',()=>corrigirIA(b.dataset.ia)));
  document.querySelectorAll('[data-cver]').forEach(b=>b.addEventListener('click',()=>{S.cartAbertos.add(b.dataset.cver);render(true)}));
  document.querySelectorAll('[data-pts]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.pts;if(S.ptsAbertos.has(id))S.ptsAbertos.delete(id);else S.ptsAbertos.add(id);render(true)}));
  document.querySelectorAll('[data-revelar]').forEach(b=>b.addEventListener('click',()=>{S.revelados.add(b.dataset.revelar);render(true)}));
  document.querySelectorAll('[data-pgmodo]').forEach(b=>b.addEventListener('click',()=>{S.pgModo=b.dataset.pgmodo;render(true)}));
  document.querySelectorAll('[data-mec-treinar]').forEach(b=>b.addEventListener('click',()=>treinarMec(b.dataset.mecTreinar)));
  const fmm=$('#f-mecmat'); if(fmm) fmm.addEventListener('change',()=>{S.fMecMat=fmm.value;render(true)});
  document.querySelectorAll('[data-pg-treinar]').forEach(b=>b.addEventListener('click',()=>treinarPg(b.dataset.pgTreinar)));
  document.querySelectorAll('[data-ir-pg]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.irPg,t=S.ed.get(id);S.fPgMat=t?t.sigla:'';if(t)S.abertos.add('pg:'+t.sigla);S.abertos.add('pgt:'+id);setView('pegadinhas');setTimeout(()=>{const el=document.getElementById('pg-'+id);if(el)el.scrollIntoView({block:'start'})},30)}));
  const fpm=$('#f-pgmat'); if(fpm) fpm.addEventListener('change',()=>{S.fPgMat=fpm.value;render(true)});
  const fpt=$('#f-pgtipo'); if(fpt) fpt.addEventListener('change',()=>{S.fPgTipo=fpt.value;render(true)});
  const ta=$('#tr-abrir'); if(ta) ta.addEventListener('click',()=>{for(const c of caps()){const t=topicoDoCap(c.cap);S.abertos.add('tr:'+(t?t.sigla:'_outros'))}render(true)});
  const tf=$('#tr-fechar'); if(tf) tf.addEventListener('click',()=>{for(const k of [...S.abertos]) if(k.startsWith('tr:')) S.abertos.delete(k); render(true)});
  const pa=$('#pg-abrir'); if(pa) pa.addEventListener('click',()=>{for(const p of S.pg.values()){const t=S.ed.get(p.topico);if(t)S.abertos.add('pg:'+t.sigla);S.abertos.add('pgt:'+p.topico)}render(true)});
  const pf=$('#pg-fechar'); if(pf) pf.addEventListener('click',()=>{for(const k of [...S.abertos]) if(k.startsWith('pg:')||k.startsWith('pgt:')) S.abertos.delete(k); S.fPgMat=''; render(true)});
  document.querySelectorAll('[data-treinar]').forEach(b=>b.addEventListener('click',()=>{S.cap=b.dataset.treinar;S.capEscolhido=true;S.modo='novos';{const t=topicoDoCap(S.cap);if(t)S.abertos.add('tr:'+t.sigla);}S.round=null;setView('treinar');window.scrollTo({top:0})}));
  const conf1=document.querySelector('[data-conf="1"]'); if(conf1&&S.round&&S.round.pend&&S.round.pend.focus){ S.round.pend.focus=false; conf1.focus({preventScroll:true}); }
}
function novaRodada(cap,capNome,modo,fila){
  S.round={id:'r-'+Date.now().toString(36),cap,capNome,modo,fila,idx:0,atual:null,pend:null,itens:[],certos:0,errados:0,brancos:0,inicio:new Date().toISOString(),fim:null,rep:{fila:[],ini:null,res:[]}};
  render(true); window.scrollTo({top:0});
}
function startRound(cap,modo){
  let fila=filaPara(cap,modo);
  if(!fila.length) return;
  if(S.shuffle){ for(let i=fila.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[fila[i],fila[j]]=[fila[j],fila[i]]} }
  novaRodada(cap,capNome(cap),modo,fila);
}
function startRevisao(){
  const {fila}=devidas(); if(!fila.length) return;
  if(S.view!=='treinar') setView('treinar');
  novaRodada('MIX','Revisão intercalada','revisao',fila);
}
function marcar(L){
  const rd=S.round; if(!rd||rd.atual||rd.fim) return;
  if(emRep(rd)){ registrarRep(L); return; }
  if(L==='B'){ registrar('B',null); return; }
  rd.pend={marcada:L,focus:true};
  render(true);
}
function confirmar(c){
  const rd=S.round; if(!rd||!rd.pend||rd.atual) return;
  registrar(rd.pend.marcada,c);
}
function registrar(L,conf){
  const rd=S.round; if(!rd||rd.atual||rd.fim) return;
  const q=S.q.get(rd.fila[rd.idx]); if(!q) return;
  const acertou=L===q.gabarito;
  const corr=(L==='E'&&rd.corr||'').trim(); rd.corr='';
  rd.pend=null; rd.just='';
  rd.atual={marcada:L,acertou,conf,corr};
  if(L==='B') rd.brancos++; else if(acertou) rd.certos++; else rd.errados++;
  rd.itens.push(Object.assign({qid:q.id,ordem:q.ordem||0,marcada:L,gabarito:q.gabarito,conf:conf||null},corr?{corr}:{}));
  if((L==='B'||!acertou||conf===1)&&!rd.rep.fila.includes(q.id)) rd.rep.fila.push(q.id);
  // estado do item
  const prev=S.r.get(q.id)||{};
  const now=new Date().toISOString(), d=hoje();
  const r=Object.assign({},prev,{qid:q.id,cap:q.cap,ordem:q.ordem||0,ultimaMarcada:L,atualizadoEm:now,
    tentativas:(prev.tentativas||0)+1,conf:conf||null});
  const hist=Array.isArray(prev.hist)?prev.hist.slice(-7):[];
  hist.push({m:L,ok:acertou,em:now,c:conf||null}); r.hist=hist;
  r.primeiraEm=prev.primeiraEm||(Array.isArray(prev.hist)&&prev.hist[0]&&prev.hist[0].em)||now;
  if(acertou&&conf!==1&&!prev.retidoEm&&difDias(diaDe(r.primeiraEm),d)>=RETENCAO) r.retidoEm=now;
  const nPrev=prev.tentativas?nivelDe(prev):0;
  if(acertou&&conf===1){
    // acerto no chute não conta como domínio
    r.acertos=(prev.acertos||0)+1;
    if(!prev.noCaderno){ r.noCaderno=true; r.entrouEm=now; r.motivo='chute'; r.acertosSeguidos=0; }
    r.nivel=0;
  } else if(acertou){
    r.acertos=(prev.acertos||0)+1; r.acertosSeguidos=(prev.acertosSeguidos||0)+1;
    if(prev.noCaderno && r.acertosSeguidos>=2){ r.noCaderno=false; r.saiuEm=now; r.motivoSaida='dois acertos seguidos'; }
    // certeza: pelo menos 7 dias; dúvida: pelo menos 3. Enquanto o item estiver no caderno, volta em 3 dias.
    r.nivel=conf===3?Math.min(Math.max(nPrev+1,2),INT.length-1):Math.max(nPrev,1);
    if(r.noCaderno) r.nivel=Math.min(r.nivel,1);
  } else {
    if(L==='B') r.brancos=(prev.brancos||0)+1; else r.erros=(prev.erros||0)+1;
    r.acertosSeguidos=0;
    if(!prev.noCaderno){ r.entrouEm=now; }
    r.noCaderno=true; r.motivo=(L==='B'&&!(prev.noCaderno&&prev.motivo==='erro'))?'branco':'erro';
    r.nivel=0;
  }
  r.proxRevisao=agendar(d,r.nivel);
  r.calib=L==='B'||!conf?null:(!acertou&&conf===3?'excesso':(acertou&&conf===1?'sub':'ok'));
  if(typeof r.nota!=='string') r.nota='';
  if(corr) r.correcoes=(Array.isArray(prev.correcoes)?prev.correcoes:[]).concat([{em:now,texto:corr}]).slice(-5);
  S.r.set(q.id,r);
  const rdoc=rodadaDoc(rd);
  enqueue(()=>S.db.doc('respostas/'+q.id).set(r));
  enqueue(()=>S.db.doc('rodadas/'+rd.id).set(rdoc));
  render(true);
}
/* repescagem: não altera respostas nem agenda; só fica registrada na rodada */
function registrarRep(L){
  const rd=S.round; const q=S.q.get(rd.fila[rd.idx]); if(!q) return;
  const acertou=L===q.gabarito;
  rd.atual={marcada:L,acertou,conf:null,rep:true};
  rd.rep.res.push({qid:q.id,m:L,ok:acertou});
  const rdoc=rodadaDoc(rd);
  enqueue(()=>S.db.doc('rodadas/'+rd.id).set(rdoc));
  render(true);
}
function rodadaDoc(rd){
  const total=rd.rep.ini===null?rd.fila.length:rd.rep.ini;
  return {cap:rd.cap,capNome:rd.capNome,modo:rd.modo,inicio:rd.inicio,fim:rd.fim,total,
    certos:rd.certos,errados:rd.errados,brancos:rd.brancos,itens:rd.itens,repescagem:rd.rep.res};
}
/* superaprendizagem: erro, branco ou chute exigem origem marcada e justificativa escrita antes de seguir */
const JUST_MIN=1;   // sem mínimo de caracteres (pedido do Lucas, 29/10/2026); basta escrever algo
function exigeJust(a){return !!a&&!a.rep&&(a.marcada==='B'||!a.acertou||a.conf===1)}
function justOk(rd,qid){const r=S.r.get(qid)||{};return !!r.origem&&(rd.just||'').trim().length>=JUST_MIN}
function justMsg(n,origem){const f=[];if(!origem)f.push('marque de onde veio o erro');if(n<JUST_MIN)f.push('escreva a justificativa');return f.length?'Falta: '+f.join(' e ')+'.':'Pronto. A justificativa vai para o caderno de erros.'}
function next(){
  const rd=S.round; if(!rd||!rd.atual) return;
  const qid=rd.fila[rd.idx];
  if(exigeJust(rd.atual)){
    if(!justOk(rd,qid)){ toast('Antes de seguir, marque de onde veio o erro e escreva a justificativa com as suas palavras.'); const ta=$('#just-txt'); if(ta) ta.focus(); return; }
    const prev=S.r.get(qid)||{}, now=new Date().toISOString(), texto=rd.just.trim();
    const js=(Array.isArray(prev.justificativas)?prev.justificativas:[]).concat([{em:now,texto,origem:prev.origem||null,marcada:rd.atual.marcada}]).slice(-8);
    const nota=(prev.nota||'').trim()?prev.nota:texto;
    S.r.set(qid,Object.assign({},prev,{justificativas:js,nota}));
    enqueue(()=>S.db.doc('respostas/'+qid).update({justificativas:js,nota}));
  }
  rd.just='';
  rd.atual=null; rd.idx++;
  if(rd.idx>=rd.fila.length){
    if(rd.rep.ini===null&&rd.rep.fila.length){ rd.rep.ini=rd.fila.length; rd.fila=rd.fila.concat(rd.rep.fila); }
    else finalizar();
  }
  render(true); window.scrollTo({top:0});
}
function finalizar(){
  const rd=S.round; if(!rd||rd.fim) return;
  rd.fim=new Date().toISOString(); rd.pend=null;
  if(rd.itens.length){ const d=rodadaDoc(rd); enqueue(()=>S.db.doc('rodadas/'+rd.id).set(d)); }
  else { S.round=null; }
}
function tirar(id){
  const prev=S.r.get(id); if(!prev) return;
  const now=new Date().toISOString();
  const r=Object.assign({},prev,{noCaderno:false,saiuEm:now,atualizadoEm:now,motivoSaida:'manual',acertosSeguidos:0});
  S.r.set(id,r); render(true);
  enqueue(()=>S.db.doc('respostas/'+id).set(r));
  toast('Item retirado do caderno. Ele continua na agenda de revisões.');
}
function salvarOrigem(id,val){
  const prev=S.r.get(id); if(!prev||!ORIGENS[val]) return;
  const v=prev.origem===val?null:val;
  S.r.set(id,Object.assign({},prev,{origem:v}));
  render(true);
  enqueue(()=>S.db.doc('respostas/'+id).update({origem:v}));
}
const lastNota=new Map();
function salvarNota(id,val){
  const prev=S.r.get(id); if(!prev) return;
  if((prev.nota||'')===val && lastNota.get(id)===val) return;
  lastNota.set(id,val);
  S.r.set(id,Object.assign({},prev,{nota:val}));
  enqueue(()=>S.db.doc('respostas/'+id).update({nota:val})).then(()=>{const s=document.getElementById('saved-'+id); if(s) s.textContent='Anotação salva';});
}
document.addEventListener('keydown',e=>{
  if(S.view!=='treinar'||!S.round||S.round.fim) return;
  const t=e.target; if(t&&(t.tagName==='TEXTAREA'||t.tagName==='INPUT'||t.tagName==='SELECT')) return;
  if(e.metaKey||e.ctrlKey||e.altKey) return;
  const rd=S.round, k=e.key.toLowerCase();
  if(!rd.atual && (k==='c'||k==='e'||k==='b')){ e.preventDefault(); marcar(k.toUpperCase()); }
  else if(rd.pend && !rd.atual && (k==='1'||k==='2'||k==='3')){ e.preventDefault(); confirmar(Number(k)); }
  else if(rd.pend && !rd.atual && e.key==='Escape'){ e.preventDefault(); rd.pend=null; render(true); }
  else if(rd.atual && (e.key==='Enter'||e.key==='ArrowRight')){ if(t&&t.dataset&&(t.dataset.origem||t.dataset.conf)&&e.key==='Enter') return; e.preventDefault(); next(); }
});

/* ---------- conexão ---------- */
function subscribe(){
  const db=S.db;
  db.collection('questoes').onSnapshot(snap=>{
    const m=new Map(); for(const d of snap.docs){ const v=d.data(); if(v&&v.enunciado&&(v.gabarito==='C'||v.gabarito==='E')) m.set(d.id,Object.assign({id:d.id},v)); }
    S.q=m; S.qLoaded=true; render();
  },err=>{S.dbState='missing';render(true)});
  db.collection('respostas').onSnapshot(snap=>{
    const m=new Map(); for(const d of snap.docs){ const v=d.data(); if(v) m.set(d.id,Object.assign({qid:d.id},v)); }
    // mantém respostas locais ainda não confirmadas
    for(const [k,v] of S.r){ const s=m.get(k); if(!s || (v.atualizadoEm||'')>(s.atualizadoEm||'')) m.set(k,v); }
    S.r=m; render();
  },()=>{});
  db.collection('rodadas').orderBy('inicio','desc').limit(500).onSnapshot(snap=>{
    S.rodadas=snap.docs.map(d=>Object.assign({id:d.id},d.data())); if(['historico','painel','treinar'].includes(S.view)&&!S.round) render(); else updateCounts();
  },()=>{});
  const central=(col,fn)=>db.collection(col).onSnapshot(snap=>{fn(snap.docs.map(d=>Object.assign({id:d.id},d.data())));if(['painel','edital','revisao','pegadinhas','conteudo','cartoes','mapa'].includes(S.view))render();},()=>{});
  central('revisao',ds=>{S.rv=new Map(ds.map(d=>[d.id,d]));});
  central('cartoes_aval',ds=>{S.cav=new Map(ds.map(d=>[d.k||d.id,d]));});
  central('pegadinhas',ds=>{S.pg=new Map(ds.map(d=>[d.id,d]));updateCounts();});
  central('analise',ds=>{S.an=new Map(ds.map(d=>[d.id,d]));const m=new Map();const c=S.an.get('CONTROLE');for(const it of ((c&&c.itens)||[])) if(it.mecanismo&&typeof it.item==='string') m.set(it.item,{m:it.mecanismo,v:it.vacina||'',e:it.evidencia||''});S.mecQ=m;});
  central('config',ds=>{S.cfg=new Map(ds.map(d=>[d.id,d]));});
  central('edital',ds=>{S.ed=new Map(ds.map(d=>[d.id,d]));S.edLoaded=true;});
  central('materiais',ds=>{S.mat=new Map(ds.map(d=>[d.id,d]));});
  central('pontos',ds=>{S.pt=new Map(ds.map(d=>[d.id,d]));});
  central('diario',ds=>{S.di=ds;});
  db.collection('textos').onSnapshot(snap=>{S.tx=new Map(snap.docs.map(d=>[d.id,Object.assign({id:d.id},d.data())]));if(['simulado','treinar'].includes(S.view))render();},()=>{});
  db.collection('simulados').onSnapshot(snap=>{S.sims=snap.docs.map(d=>Object.assign({id:d.id},d.data()));if(S.view==='simulado'&&!simLS('obj')&&!simLS('disc'))render();},()=>{});
}
/* ---------- SIMULADO DOMINICAL ---------- */
const SIM_DEF={
  obj:{min:300,blocos:[
    {prova:'P1',nome:'Conhecimentos básicos',corte:18,mats:[['lp','Língua Portuguesa',26],['li','Língua Inglesa',10],['da','Dir. Administrativo e Adm. Pública',24],['dc','Dir. Constitucional e RICD',18],['ti','Tecnologia da Informação e Dados',12]]},
    {prova:'P2',nome:'Conhecimentos específicos',corte:27,mats:[['pl','Processo Legislativo e Regimentos',30],['lg','Linguística',25],['rf','Reconhecimento de fala, transcrição e IA',20],['cp','Ciência Política',15]]}]},
  disc:{min:180}
};
const SIM_DISC=[
 {id:'d1',tipo:'questao',linhas:20,mat:'pl',tema:'Tramitação de proposições',enunciado:'Discorra sobre a apreciação conclusiva das comissões na Câmara dos Deputados, abordando: (a) fundamento constitucional e regimental; (b) hipóteses em que não se aplica; (c) o recurso ao Plenário — quem pode interpor e em que prazo.',espelho:['Art. 58, §2º, I, CF e art. 24, II, RICD: comissões discutem e votam projetos dispensada a competência do Plenário.','Exceções do art. 24, II, RICD: PLP, código, iniciativa popular, matéria de comissão, já aprovada em plenário da outra Casa, pareceres divergentes, urgência.','Recurso de 1/10 dos membros da Casa, no prazo de 5 sessões da publicação do anúncio (art. 58, §1º e 132, §2º, RICD).']},
 {id:'d2',tipo:'questao',linhas:20,mat:'rf',tema:'ASR',enunciado:'Explique o funcionamento de um sistema de reconhecimento automático de fala (ASR) e indique duas limitações relevantes para o registro de debates parlamentares, propondo como o revisor humano deve atuar sobre cada uma.',espelho:['Pipeline: sinal → extração de características → modelo acústico/de linguagem (ou end-to-end) → texto.','Limitações: sobreposição de falas, nomes próprios e jargão regimental, ruído, sotaques; métrica WER.','Papel do revisor: conferência com áudio, padronização, identificação de oradores, fidelidade ao sentido.']},
 {id:'d3',tipo:'questao',linhas:20,mat:'lg',tema:'Signo linguístico',enunciado:'Explique a distinção saussuriana entre língua e fala e relacione-a à atividade de transformar o discurso oral do Plenário em texto escrito.',espelho:['Língua: sistema social, abstrato; fala: ato individual, concreto.','Signo: significante + significado, arbitrariedade.','Aplicação: a redação final passa da fala (marcas de oralidade) à norma do sistema escrito, preservando o sentido.']},
 {id:'d4',tipo:'questao',linhas:20,mat:'pl',tema:'Medidas provisórias',enunciado:'Discorra sobre o rito de apreciação das medidas provisórias no Congresso Nacional, abordando a comissão mista, o trancamento de pauta e os prazos de vigência.',espelho:['Art. 62 CF: 60+60 dias, suspensos no recesso; comissão mista emite parecer (ADI 4029).','Sobrestamento a partir do 45º dia das deliberações legislativas da Casa em que estiver (alcance restrito, MS 27931).','Votação começa na Câmara; perda de eficácia e decreto legislativo em 60 dias.']},
 {id:'p1',tipo:'peca',linhas:50,mat:'pl',tema:'Peça técnica',enunciado:'Redija uma NOTA TÉCNICA, dirigida à chefia do Departamento de Taquigrafia, Revisão e Redação, sobre os critérios que devem orientar a edição das notas taquigráficas de uma sessão deliberativa: fidelidade ao discurso, supressão de marcas de oralidade, correção gramatical e registro de incidentes regimentais (questões de ordem, votações nominais).',espelho:['Estrutura: identificação, assunto, análise, conclusão/recomendação, local e data, assinatura sem identificação pessoal.','Fidelidade ao conteúdo e ao sentido, sem alterar posicionamentos.','Edição: retirada de vícios de oralidade, padronização, norma-padrão.','Registro de questões de ordem, resultado de votações e incidentes regimentais.']},
 {id:'p2',tipo:'peca',linhas:50,mat:'rf',tema:'Peça técnica',enunciado:'Redija um PARECER TÉCNICO sobre a adoção de transcrição automática por IA no registro das reuniões de comissões da Câmara, abordando ganhos, riscos (fidelidade, privacidade, viés) e a divisão de tarefas entre máquina e revisor.',espelho:['Estrutura de parecer: ementa, relatório, análise, conclusão.','Ganhos: celeridade, custo, acessibilidade.','Riscos: WER, nomes/termos, LGPD, viés de sotaque, responsabilidade.','Conclusão: modelo híbrido com revisão humana obrigatória.']}
];
const SIM_MAPA={ap:'da',jur:'dc',banca:null};
function simSigla(cap){
  const m=materiaDoCap(cap); if(m) return m.toLowerCase();
  const c=String(cap||'');
  if(/^BANCA-/i.test(c)) return c.slice(6).toLowerCase();
  if(/^AP-/i.test(c)) return 'da';
  if(/^JUR-DC/i.test(c)) return 'dc';
  if(/^\d/.test(c)) return 'rf';
  return c.split(/[-.]/)[0].toLowerCase();
}
function simBlueprint(){const c=S.cfg.get('simulado');return (c&&c.obj&&c.obj.blocos)?c.obj:SIM_DEF.obj}
function domingos(){const d=new Date();const off=(7-d.getDay())%7;const p=new Date(d);p.setDate(d.getDate()+off);return {hoje:d.getDay()===0,prox:p.toLocaleDateString('pt-BR')}}
function simLS(k,v){try{if(v===undefined)return JSON.parse(localStorage.getItem('sim:'+k)||'null');if(v===null)localStorage.removeItem('sim:'+k);else localStorage.setItem('sim:'+k,JSON.stringify(v))}catch(e){return null}}
function simMontar(){
  const bp=simBlueprint(), porMat=new Map();
  for(const q of S.q.values()){if(q.foraNivel)continue;const s=simSigla(q.cap);if(!porMat.has(s))porMat.set(s,[]);porMat.get(s).push(q)}
  const usados=new Set();for(const h of S.sims||[])for(const it of (h.itens||[]))usados.add(it.qid);
  const itens=[],falta=[];
  for(const b of bp.blocos) for(const [s,nome,n] of b.mats){
    const pool=(porMat.get(s)||[]).slice();
    const peso=q=>(/^BANCA/.test(q.cap)?0:2)+(S.r.has(q.id)?1:0)+(usados.has(q.id)?3:0)+Math.random();
    pool.sort((a,b)=>peso(a)-peso(b));
    // equilíbrio entre capítulos: round-robin pelos capítulos estudados
    const caps=new Map();for(const q of pool){if(!caps.has(q.cap))caps.set(q.cap,[]);caps.get(q.cap).push(q)}
    const filas=[...caps.values()],esc=[];let i=0;
    while(esc.length<n&&filas.some(f=>f.length)){const f=filas[i%filas.length];if(f.length)esc.push(f.shift());i++}
    {const ord=[],vis=new Map();for(const q of esc){const k=q.textoId||('_'+q.id);if(!vis.has(k)){vis.set(k,[]);ord.push(k)}vis.get(k).push(q)}esc.splice(0,esc.length,...ord.flatMap(k=>vis.get(k).sort((a,b)=>(a.id>b.id)-(a.id<b.id))));}
    if(esc.length<n) falta.push({s,nome,pedido:n,tem:esc.length});
    for(const q of esc) itens.push({qid:q.id,prova:b.prova,mat:s,marcada:null});
  }
  return {itens,falta};
}
function simFmt(ms){ms=Math.max(0,ms);const h=Math.floor(ms/36e5),m=Math.floor(ms%36e5/6e4),s=Math.floor(ms%6e4/1e3);return `${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`}
function linhas(t){return String(t||'').split('\n').reduce((a,l)=>a+Math.max(1,Math.ceil(l.length/72)),0)*(String(t||'').trim()?1:0)}
function viewSimulado(){
  const so=simLS('obj'), sd=simLS('disc'), dm=domingos(), bp=simBlueprint();
  if(so&&!so.fim) return viewSimObj(so);
  if(so&&so.fim&&!so.visto) return viewSimObjRes(so);
  if(sd&&!sd.fim) return viewSimDisc(sd);
  if(sd&&sd.fim&&!sd.visto) return viewSimDiscRes(sd);
  const tot=b=>b.mats.reduce((a,m)=>a+m[2],0);
  const hist=(S.sims||[]).slice().sort((a,b)=>(b.data||'').localeCompare(a.data||''));
  return `<div class="wrap">
  <div class="due${dm.hoje?'':' calm'}"><div class="due-body"><span class="due-n">${dm.hoje?'Hoje é dia de simulado':'Próximo simulado: domingo, '+dm.prox}</span><span class="due-meta">Objetiva 300 min (P1 + P2, 180 itens) · Discursiva 180 min (2 questões de 20 linhas + peça técnica de 50 linhas). Mesma duração e pontuação do edital (itens 7 e 9).</span></div></div>
  <h2 class="section-title">Composição da objetiva</h2>
  <div class="tbl-wrap"><table class="narrow"><thead><tr><th>Matéria</th><th class="num">Itens</th><th class="num">No banco</th></tr></thead><tbody>
  ${bp.blocos.map(b=>`<tr class="qr-m"><td><b>${b.prova} · ${esc(b.nome)}</b> <span class="ref">corte ${b.corte} pts</span></td><td class="num">${tot(b)}</td><td></td></tr>`+b.mats.map(([s,n,q])=>{const t=[...S.q.values()].filter(x=>simSigla(x.cap)===s).length;return `<tr><td style="padding-left:24px">${esc(n)}</td><td class="num">${q}</td><td class="num ${t<q?'neg':''}">${t}</td></tr>`}).join('')).join('')}
  </tbody></table></div>
  <p class="rule">Fonte da distribuição: total de 90 + 90 itens e cortes de 18 e 27 pontos estão no edital (itens 7.1 e 8.11.6). A divisão por matéria é <b>estimativa</b>: LP (26) e LI (10) seguem a numeração do bloco de Nível superior da prova Cebraspe da Câmara de 08/03/2026 já cadastrado no Caderno; as demais matérias são classificação provisória do Claude, a substituir pela incidência do portal MentoriaAA quando ela for registrada. Só entram itens dos tópicos já estudados (os que estão no Caderno), em rodízio entre capítulos, com prioridade para itens reais da banca e itens ainda não usados em simulados. Matérias com falta de itens aparecem em vermelho e são completadas com o que houver.</p>
  <details class="why"><summary>Antes de começar (opcional): 5 minutos de escrita sobre as preocupações</summary><p>Escreva livremente o que te preocupa nesta prova. Escrever logo antes da prova melhorou as notas, sobretudo de quem fica ansioso (Ramirez e Beilock, 2011). O texto não é salvo. Depois, use 30 segundos para olhar a prova inteira e planejar o tempo (Willingham).</p><div class="note"><textarea id="sim-exp" style="min-height:90px" placeholder="O que me preocupa nesta prova é…"></textarea></div></details>
  <div class="row"><button class="btn" id="sim-obj">Começar objetiva (300 min)</button><button class="btn ghost" id="sim-disc">Começar discursiva (180 min)</button></div>
  <p class="rule">Regra de decisão: certo +1, errado −1, branco 0. Marque só acima de 50% de chance. As respostas do simulado não alteram a agenda de revisão nem o Caderno de erros; os erros aparecem no resultado para você levar ao treino.</p>
  <h2 class="section-title">Histórico</h2>
  ${hist.length?`<div class="tbl-wrap"><table class="narrow"><thead><tr><th>Data</th><th>Tipo</th><th class="num">P1</th><th class="num">P2</th><th class="num">Total</th></tr></thead><tbody>${hist.map(h=>`<tr><td class="mono">${esc(h.data)}</td><td>${h.tipo==='obj'?'Objetiva':'Discursiva'}</td><td class="num">${h.tipo==='obj'?h.p1:'–'}</td><td class="num">${h.tipo==='obj'?h.p2:'–'}</td><td class="num">${h.tipo==='obj'?h.p1+h.p2:(h.nota??'–')+' / 60'}</td></tr>`).join('')}</tbody></table></div>`:`<div class="notice">Nenhum simulado registrado ainda.</div>`}
  </div>`;
}
function viewSimObj(so){
  const rest=so.inicio+so.min*6e4-Date.now(), i=so.pos||0, it=so.itens[i], q=S.q.get(it.qid)||{};
  const resp=so.itens.filter(x=>x.marcada).length;
  return `<div class="wrap"><div class="scorebar"><span class="score"><span class="n" id="sim-relogio">${simFmt(rest)}</span><span>${resp}/${so.itens.length} marcadas</span></span><span class="progress">${it.prova} · item ${i+1} de ${so.itens.length}</span></div>
  <div class="item"><div class="item-head"><span class="item-num">ITEM ${i+1}</span><span class="tag">${esc(it.prova)} · ${esc(it.mat.toUpperCase())}</span></div>
  ${textoHTML(q)}<div class="statement">${q.enunciado?statementHTML(q,false):'(item indisponível)'}</div>
  <div class="answers">${['C','E'].map(l=>`<button class="bubble${it.marcada===l?' picked':''}" data-sim-m="${l}">${l}</button>`).join('')}<button class="blank${it.marcada==='B'?' picked':''}" data-sim-m="B">Deixar em branco</button></div>
  ${(it.marcada==='C'||it.marcada==='E')?`<div class="conf"><span class="conf-q">Qual a sua confiança?</span><div class="conf-opts">${[[1,'Chute'],[2,'Dúvida'],[3,'Certeza']].map(([v,t])=>`<button data-sim-conf="${v}" style="${it.conf===v?'border-color:var(--pen);font-weight:700':''}"><span class="mono">${v}</span>${t}</button>`).join('')}</div><span class="ref">Sem correção agora: o gabarito só aparece ao entregar a prova.</span></div>`:''}
  <div class="next-row"><button class="btn ghost small" data-sim-ir="${i-1}" ${i?'':'disabled'}>← Anterior</button><button class="btn small" data-sim-ir="${i+1}" ${i<so.itens.length-1?'':'disabled'}>Próximo →</button></div></div>
  <details class="why"><summary>Folha de respostas</summary><div class="chips" style="margin-top:8px">${so.itens.map((x,k)=>`<button class="chip" aria-pressed="${k===i}" data-sim-ir="${k}" style="min-width:44px">${k+1}${x.marcada?' '+x.marcada+(x.conf?'·'+x.conf:''):''}</button>`).join('')}</div></details>
  <div class="row"><button class="btn" id="sim-entregar">Entregar prova</button><button class="btn ghost small" id="sim-cancelar">Cancelar simulado</button></div></div>`;
}
function simPontos(so){const p={P1:0,P2:0},mat=new Map();for(const it of so.itens){const q=S.q.get(it.qid);if(!q)continue;const v=!it.marcada||it.marcada==='B'?0:(it.marcada===q.gabarito?1:-1);p[it.prova]+=v;const k=it.prova+'|'+it.mat,o=mat.get(k)||{c:0,e:0,b:0,n:0};o.n++;if(v>0)o.c++;else if(v<0)o.e++;else o.b++;mat.set(k,o)}return {p,mat}}
function viewSimObjRes(so){
  const {p,mat}=simPontos(so),bp=simBlueprint();
  const erros=so.itens.filter(it=>{const q=S.q.get(it.qid);return q&&it.marcada&&it.marcada!=='B'&&it.marcada!==q.gabarito});
  return `<div class="wrap"><h2 class="section-title">Resultado da objetiva · ${esc(so.data)}</h2>
  <div class="summary"><div class="stat"><span class="v">${p.P1}</span><span class="k">P1 (corte 18)</span></div><div class="stat"><span class="v">${p.P2}</span><span class="k">P2 (corte 27)</span></div><div class="stat ${p.P1+p.P2>=45?'c':'e'}"><span class="v">${p.P1+p.P2}</span><span class="k">Total líquido</span></div><div class="stat"><span class="v">${simFmt(so.fimEm-so.inicio)}</span><span class="k">Tempo usado</span></div></div>
  <p class="insight">${p.P1>=18&&p.P2>=27?'<b>Acima dos dois cortes.</b>':'<b>Abaixo de pelo menos um corte.</b>'} O corte do edital elimina quem fica abaixo de 18 na P1 ou de 27 na P2.</p>
  <div class="tbl-wrap"><table class="narrow"><thead><tr><th>Matéria</th><th class="num">C</th><th class="num">E</th><th class="num">Br</th><th class="num">Líquido</th></tr></thead><tbody>${[...mat].map(([k,o])=>`<tr><td>${esc(k.replace('|',' · ').toUpperCase())}</td><td class="num pos">${o.c}</td><td class="num neg">${o.e}</td><td class="num">${o.b}</td><td class="num">${o.c-o.e}</td></tr>`).join('')}</tbody></table></div>
  <h2 class="section-title">Acerto por confiança</h2>
  <div class="tbl-wrap"><table class="narrow"><thead><tr><th>Confiança</th><th class="num">Itens</th><th class="num">Acerto</th><th class="num">Líquido</th></tr></thead><tbody>${[[1,'Chute'],[2,'Dúvida'],[3,'Certeza'],[0,'Sem confiança']].map(([v,t])=>{const xs=so.itens.filter(x=>(x.marcada==='C'||x.marcada==='E')&&(x.conf||0)===v);if(!xs.length)return '';const c=xs.filter(x=>{const q=S.q.get(x.qid);return q&&q.gabarito===x.marcada}).length;return `<tr><td>${t}</td><td class="num">${xs.length}</td><td class="num">${fmtPct(c/xs.length)}</td><td class="num ${2*c-xs.length<0?'neg':'pos'}">${2*c-xs.length}</td></tr>`}).join('')}</tbody></table></div>
  <p class="rule">Se o acerto no chute ficar abaixo de 50%, o líquido é negativo: nesses casos, vale deixar em branco na prova.</p>
  ${(()=>{const tr=so.itens.filter(x=>x.prim&&x.prim!==(x.marcada||'B'));if(!tr.length)return `<p class="rule">Trocas de resposta: nenhuma neste simulado. Trocar após reconsiderar costuma ajudar: em Kruger, Wirtz e Miller (2005), 51% das trocas foram de errado para certo e 25% de certo para errado.</p>`;let ec=0,ce=0,ee=0;for(const x of tr){const q=S.q.get(x.qid);if(!q)continue;const a=x.prim===q.gabarito,b=(x.marcada||'B')===q.gabarito;if(!a&&b)ec++;else if(a&&!b)ce++;else ee++}return `<h2 class="section-title">Trocas de resposta (${tr.length})</h2><div class="summary"><div class="stat c"><span class="v">${ec}</span><span class="k">errado → certo</span></div><div class="stat e"><span class="v">${ce}</span><span class="k">certo → errado</span></div><div class="stat"><span class="v">${ee}</span><span class="k">sem efeito</span></div><div class="stat"><span class="v">${ec-ce>=0?'+':''}${ec-ce}</span><span class="k">saldo das trocas</span></div></div><p class="rule">Estudo de referência: 51% das trocas foram de errado para certo e 25% de certo para errado (Kruger, Wirtz e Miller, 2005). O que vale é o seu saldo: acompanhe aqui a cada simulado.</p>`})()}
  <h2 class="section-title">Itens errados (${erros.length})</h2>
  <p class="rule">Classifique cada erro: o padrão dos erros diz o que treinar na semana (Willingham, dica 56). ${(()=>{const c={};for(const x of erros)if(x.origem)c[x.origem]=(c[x.origem]||0)+1;const k=Object.keys(c);return k.length?'Até agora: '+k.map(o=>ORIGENS[o].t+' '+c[o]).join(' · ')+'.':''})()}</p>
  ${erros.map(it=>{const q=S.q.get(it.qid);const ix=so.itens.indexOf(it);return `<div class="entry"><div class="chips">${Object.entries(ORIGENS).map(([k,v])=>`<button class="chip" data-sim-or="${ix}" data-val="${k}" aria-pressed="${it.origem===k}">${v.t}</button>`).join('')}</div><div class="pills"><span class="pill">${esc(q.cap)}</span><span class="pill e">marcou ${it.marcada}</span>${it.conf?`<span class="pill b">${['','chute','dúvida','certeza'][it.conf]}</span>`:''}<span class="pill c">gabarito ${q.gabarito}</span></div><div class="statement">${esc(q.enunciado)}</div><details class="why"><summary>Por quê</summary><p>${esc(q.comentario)}</p><p class="ref">${esc(q.ref||'')} · ${esc(q.origem||'')}</p></details></div>`}).join('')||'<div class="notice">Nenhum erro.</div>'}
  <button class="btn" id="sim-fechar">Fechar e voltar</button></div>`;
}
function viewSimDisc(sd){
  const rest=sd.inicio+sd.min*6e4-Date.now();
  return `<div class="wrap"><div class="scorebar"><span class="score"><span class="n" id="sim-relogio">${simFmt(rest)}</span></span><span class="progress">Discursiva · escreva de memória</span></div>
  ${sd.itens.map((d,k)=>`<div class="item"><div class="item-head"><span class="item-num">${d.tipo==='peca'?'PEÇA TÉCNICA':'QUESTÃO '+(k+1)}</span><span class="tag">até ${d.linhas} linhas · ${d.tipo==='peca'?30:15} pts</span></div><div class="statement">${esc(d.enunciado)}</div>
  <div class="note"><textarea data-sim-txt="${k}" style="min-height:${d.linhas*14}px">${esc(d.texto||'')}</textarea><span class="saved" id="sim-ln-${k}">${linhas(d.texto)} de ${d.linhas} linhas (≈72 caracteres por linha)</span></div></div>`).join('')}
  <div class="row"><button class="btn" id="sim-dentregar">Entregar discursiva</button><button class="btn ghost small" id="sim-dcancelar">Cancelar</button></div></div>`;
}
function simNota(d){const tl=Math.max(1,linhas(d.texto)),nc=+d.nc||0,ne=+d.ne||0;const v=d.tipo==='peca'?nc-6*ne/tl:nc-3*ne/tl;return Math.max(0,Math.round(v*100)/100)}
function viewSimDiscRes(sd){
  const tot=sd.itens.reduce((a,d)=>a+simNota(d),0);
  return `<div class="wrap"><h2 class="section-title">Correção da discursiva · ${esc(sd.data)}</h2>
  <p class="rule">Compare seu texto com o espelho, dê a nota de conteúdo (NC) e conte os erros de grafia, morfossintaxe e vocabulário (NE). Fórmulas do edital (9.8.5): questão NQ = NC − 3×NE÷TL; peça NPT = NC − 6×NE÷TL. Aprovação na P3: 30 de 60. Espelhos e enunciados são inéditos Claude.</p>
  ${sd.itens.map((d,k)=>`<div class="item"><div class="item-head"><span class="item-num">${d.tipo==='peca'?'PEÇA':'QUESTÃO '+(k+1)}</span><span class="tag">${linhas(d.texto)} linhas escritas</span></div><div class="statement">${esc(d.enunciado)}</div>
  <details class="why"><summary>Seu texto</summary><p>${esc(d.texto||'(em branco)').replace(/\n/g,'<br>')}</p></details>
  <div class="verdict dub"><span class="vt">Espelho</span>${d.espelho.map(e=>`<p>• ${esc(e)}</p>`).join('')}</div>
  <div class="row"><label class="check">NC (0–${d.tipo==='peca'?30:15}) <input type="number" min="0" max="${d.tipo==='peca'?30:15}" step="0.5" data-sim-nc="${k}" value="${d.nc??''}" style="width:70px"></label><label class="check">NE <input type="number" min="0" data-sim-ne="${k}" value="${d.ne??''}" style="width:60px"></label><b class="mono">${simNota(d)} pts</b></div></div>`).join('')}
  <div class="summary two"><div class="stat ${tot>=30?'c':'e'}"><span class="v">${Math.round(tot*100)/100}</span><span class="k">Nota P3 (de 60; aprova com 30)</span></div><div class="stat"><span class="v">${simFmt(sd.fimEm-sd.inicio)}</span><span class="k">Tempo usado</span></div></div>
  <button class="btn" id="sim-dsalvar">Salvar correção e voltar</button></div>`;
}
function simSorteioDisc(){
  const est=new Set();for(const q of S.q.values())est.add(simSigla(q.cap));
  const ok=d=>est.has(d.mat), n=(S.sims||[]).filter(h=>h.tipo==='disc').length;
  const qs=SIM_DISC.filter(d=>d.tipo==='questao'&&ok(d)), ps=SIM_DISC.filter(d=>d.tipo==='peca'&&ok(d));
  const Q=qs.length?qs:SIM_DISC.filter(d=>d.tipo==='questao'), P=ps.length?ps:SIM_DISC.filter(d=>d.tipo==='peca');
  return [Q[(2*n)%Q.length],Q[(2*n+1)%Q.length],P[n%P.length]].map(d=>Object.assign({},d,{texto:''}));
}
let simTimer=null;
function simTick(){clearInterval(simTimer);simTimer=setInterval(()=>{const el=$('#sim-relogio');if(!el||S.view!=='simulado'){clearInterval(simTimer);return}const s=simLS('obj')&&!simLS('obj').fim?simLS('obj'):simLS('disc');if(!s)return;const r=s.inicio+s.min*6e4-Date.now();el.textContent=simFmt(r);if(r<=0){clearInterval(simTimer);toastSim('Tempo esgotado. Entregue a prova.')}},1000)}
function toastSim(t){const el=$('#toast');if(!el)return;el.textContent=t;el.hidden=false;setTimeout(()=>el.hidden=true,3500)}
function hojeISO(){const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function wireSim(){
  const go=(k,v)=>{simLS(k,v);render(true)};
  const o=$('#sim-obj');if(o)o.addEventListener('click',()=>{const {itens,falta}=simMontar();if(falta.length)toastSim('Faltam itens em: '+falta.map(f=>f.s.toUpperCase()+' ('+f.tem+'/'+f.pedido+')').join(', '));go('obj',{inicio:Date.now(),min:SIM_DEF.obj.min,itens,pos:0,data:hojeISO()})});
  const d=$('#sim-disc');if(d)d.addEventListener('click',()=>go('disc',{inicio:Date.now(),min:SIM_DEF.disc.min,itens:simSorteioDisc(),data:hojeISO()}));
  document.querySelectorAll('[data-sim-m]').forEach(b=>b.addEventListener('click',()=>{const s=simLS('obj');const it=s.itens[s.pos||0];const m=b.dataset.simM;if(it.marcada&&!it.prim)it.prim=it.marcada;if(it.marcada===m){it.marcada=null;it.conf=null;go('obj',s);return}if(it.prim&&it.prim!==m)it.trocas=(it.trocas||0)+1;it.marcada=m;it.conf=null;if(m==='B'&&(s.pos||0)<s.itens.length-1)s.pos=(s.pos||0)+1;go('obj',s)}));
  document.querySelectorAll('[data-sim-conf]').forEach(b=>b.addEventListener('click',()=>{const s=simLS('obj');const it=s.itens[s.pos||0];it.conf=+b.dataset.simConf;if((s.pos||0)<s.itens.length-1)s.pos=(s.pos||0)+1;go('obj',s);window.scrollTo({top:0})}));
  document.querySelectorAll('[data-sim-ir]').forEach(b=>b.addEventListener('click',()=>{const s=simLS('obj');const k=+b.dataset.simIr;if(k<0||k>=s.itens.length)return;s.pos=k;go('obj',s);window.scrollTo({top:0})}));
  const e=$('#sim-entregar');if(e)e.addEventListener('click',()=>{const s=simLS('obj');const br=s.itens.filter(x=>!x.marcada).length;if(br&&!confirm(br+' itens sem marcação contarão como branco. Entregar?'))return;s.fim=true;s.fimEm=Date.now();const {p}=simPontos(s);const id=s.data+'-obj-'+s.inicio;if(S.db)enqueue(()=>S.db.doc('simulados/'+id).set({tipo:'obj',data:s.data,inicio:new Date(s.inicio).toISOString(),minutos:Math.round((s.fimEm-s.inicio)/6e4),p1:p.P1,p2:p.P2,itens:s.itens.map(x=>Object.assign({qid:x.qid,prova:x.prova,mat:x.mat,marcada:x.marcada||'B',conf:x.conf||null},x.prim&&x.prim!==(x.marcada||'B')?{prim:x.prim}:{}))}));go('obj',s)});
  const c=$('#sim-cancelar');if(c)c.addEventListener('click',()=>{if(confirm('Cancelar o simulado em andamento? As marcações serão perdidas.'))go('obj',null)});
  document.querySelectorAll('[data-sim-or]').forEach(b=>b.addEventListener('click',()=>{const s=simLS('obj');const it=s.itens[+b.dataset.simOr];if(!it)return;it.origem=it.origem===b.dataset.val?null:b.dataset.val;go('obj',s)}));
  const f=$('#sim-fechar');if(f)f.addEventListener('click',()=>{const s=simLS('obj');if(s&&S.db&&s.itens.some(x=>x.origem)){const id=s.data+'-obj-'+s.inicio;const origens=s.itens.map((x,k)=>x.origem?{i:k,qid:x.qid,origem:x.origem}:null).filter(Boolean);enqueue(()=>S.db.doc('simulados/'+id).update({origensErros:origens}))}go('obj',null)});
  document.querySelectorAll('[data-sim-txt]').forEach(t=>t.addEventListener('input',()=>{const s=simLS('disc');const k=+t.dataset.simTxt;s.itens[k].texto=t.value;simLS('disc',s);const l=$('#sim-ln-'+k);if(l){const n=linhas(t.value),m=s.itens[k].linhas;l.textContent=n+' de '+m+' linhas (≈72 caracteres por linha)'+(n>m?' — acima do limite: o excedente é desconsiderado':'')}}));
  const de=$('#sim-dentregar');if(de)de.addEventListener('click',()=>{const s=simLS('disc');s.fim=true;s.fimEm=Date.now();go('disc',s)});
  const dc=$('#sim-dcancelar');if(dc)dc.addEventListener('click',()=>{if(confirm('Cancelar a discursiva? O texto será perdido.'))go('disc',null)});
  const upd=(sel,campo)=>document.querySelectorAll(sel).forEach(i=>i.addEventListener('change',()=>{const s=simLS('disc');s.itens[+i.dataset[campo==='nc'?'simNc':'simNe']][campo]=i.value;go('disc',s)}));
  upd('[data-sim-nc]','nc');upd('[data-sim-ne]','ne');
  const ds=$('#sim-dsalvar');if(ds)ds.addEventListener('click',()=>{const s=simLS('disc');const nota=Math.round(s.itens.reduce((a,d)=>a+simNota(d),0)*100)/100;const id=s.data+'-disc-'+s.inicio;if(S.db)enqueue(()=>S.db.doc('simulados/'+id).set({tipo:'disc',data:s.data,inicio:new Date(s.inicio).toISOString(),minutos:Math.round((s.fimEm-s.inicio)/6e4),nota,itens:s.itens.map(d=>({id:d.id,tipo:d.tipo,tema:d.tema,texto:d.texto,linhas:linhas(d.texto),nc:+d.nc||0,ne:+d.ne||0,nota:simNota(d)}))}));go('disc',null)});
  if($('#sim-relogio'))simTick();
}

function init(){
  let v='painel'; try{ const h=(location.hash||'').slice(1); if(VIEWS.includes(h)) v=h; }catch(e){}
  setView(v,false);
  const use=window.claude&&window.claude.use?window.claude.use('db'):Promise.resolve(null);
  Promise.resolve(use).then(db=>{
    if(!db){ S.dbState='missing'; render(true); return; }
    S.db=db; S.dbState='ok'; render(true); subscribe();
  },()=>{S.dbState='missing';render(true)});
}
init();
})();
