# Área Fiscal · matriz operacional de cobertura

Atualizada em **08/11/2026**, com ampliação de bancos de dados nas tarefas **35, 38, 44, 50, 59 e 65** e reaproveitamento das questões de DIKW na **T71**, além das tarefas anteriormente trabalhadas. Ambiente Base44 vinculado à conta do candidato; o histórico da Câmara permanece separado.

## Totais reais do banco

| Métrica | Quantidade |
|---|---:|
| Tarefas do edital | 75 |
| Trilhas | 00: 20, 01: 16, 02: 20, 03: 19 |
| Questões físicas distintas | **516** |
| Mapas por tópico | 75 |
| Nós dos mapas, considerando todos os níveis | **785** (727 com identificador) |
| Flashcards físicos | **607** |
| Flashcards ligados a nós por identificador explícito | **499** |
| Déficit aritmético até 20 questões/tarefa (excluídas 3 orientações e considerados bancos compartilhados) | **969** |

**Atenção:** a bateria **T18 possui 77 questões acessíveis**: 1 local e 76 referenciadas por ID das tarefas T06 e T12. Os itens reutilizados **não** aumentam o total de questões físicas e não criam novo histórico de respostas. Os mapas e cartões da bateria podem encaminhar aos materiais conceituais T06 e T12. A bateria **T19 contém 34 questões acessíveis**: 1 própria e 33 referências por ID à T09. Em ambos os casos, não há cópia de documentos de questões, nem duplicação de histórico ou SRS.

## Assuntos aprofundados

- **T04 · Constitucionalismo e neoconstitucionalismo:** 25 questões únicas, 44 nós, 39 flashcards, 39 vínculos diretos; fonte: Apostila Direito Constitucional, seção 1.2, pp. 7–18.
- **T06 · Regime jurídico administrativo e princípios expressos:** 39 questões únicas, 44 nós e 40 flashcards (40 vínculos exatos), fonte: `DIREITO ADMINISTRATIVO.zip/1. Princípios da Administração.pdf`, seções 1.1–1.2, pp. 3–28.
- **T07 · Ortografia, acentuação e acentos diferenciais:** **40 questões** (39 novas e uma preservada), **46 nós**, **41 flashcards** (41/41 vínculos), fonte: \`PORTUGUÊS.zip/1. Ortografia oficial. Acentuação gr.pdf\`, pp. 3, 14–35, seções 1.1 e 1.4–1.6.
- **T08 · Tributo: conceito e natureza jurídica:** **33 questões**, **39 nós**, **34 flashcards** (34/34 vínculos), fonte: \`DIREITO TRIBUTÁRIO.zip/1. 1 - Conceito de Tributo.pdf\`, pp. 3, 10–27, especialmente arts. 3º–5º, 118, 156 e 162 do CTN e decisões discutidas na própria apostila.
- **T09 · Contabilidade: objeto, finalidade e usuários:** **33 questões**, **40 nós**, **34 flashcards** (34/34 vínculos), fonte: \`CONTABILIDADE.zip/1. Aspectos Introdutórios.pdf\`, pp. 3–28. A distinção finalidade × objetivo segue a convenção adotada pela apostila e seu enquadramento em provas.
- **T12 · Princípios administrativos implícitos:** 37 questões únicas, 46 nós e 38 flashcards (38 vínculos exatos), fonte: mesma apostila, seção 1.3, pp. 28–59.
- **T18 · Bateria: princípios administrativos:** 77 questões disponíveis por IDs únicos, duas perguntas conceituais próprias, links para os dois mapas aprofundados; 76 itens são **referências**, não cópias.

- **T19 · Bateria de aspectos introdutórios:** **34 questões** com reutilização dos 33 IDs da tarefa 09, mais uma questão própria; dois cartões preservados e links ao mapa da T09.

**Proveniência:** as questões adicionais foram redigidas para a plataforma e rotuladas como **autorais** com página da apostila. Não foram indevidamente atribuídas ao Cebraspe, FCC ou FGV. As questões anteriormente registradas e as avaliações SRS foram preservadas. **444 questões novas** (além das 72 originalmente cadastradas) foram criadas como exercícios autorais com comentários e referências de apostila. A presença de conteúdo não atesta sua qualidade científica nem o domínio ou retenção por parte do aluno. Nenhum histórico de respostas ou avaliações de revisão espaçada foi artificialmente criado.

**T05, T11, T17, T21, T26 e T32 desbloqueadas** pelos novos PDFs de TI. Os dois primeiros assuntos de tecnologia e os dois de governança foram aprofundados; suas baterias passaram a compartilhar os mesmos IDs das questões de teoria.

## Ampliação de Tecnologia da Informação em 08/11/2026

As fontes efetivamente lidas para estes seis tópicos foram **1. Análise de Informações - Pirâmide DIKW. Dados Abertos. Metadados de Arquivos.pdf** (81 páginas) e **2. Governança de dados.pdf** (193 páginas). Os 18 outros PDFs recebidos permanecem como fontes para lotes posteriores; não equivalem a assuntos já concluídos.

- **T05 · Pirâmide DIKW e dados abertos:** 32 questões (31 novas), 35 nós, 33 cartões e 33 vínculos. Origem: primeiro PDF, pp. 3–20 e 41–43, incluindo a pirâmide ilustrada na p. 5.
- **T11 · Metadados de arquivos:** 29 questões (28 novas), 36 nós, 30 cartões e 30 vínculos. Origem: primeiro PDF, pp. 51–58 e 78–79, inclusive EXIF, XML, Dublin Core e classificações.
- **T17 · Bateria DIKW/dados abertos/metadados:** 62 questões distintas acessíveis, sendo 61 referências às questões das T05 e T11 e 1 própria. Os mapas T05/T11 são acessíveis por links.
- **T21 · Governança de dados: fundamentos e organização:** 31 questões (30 novas), 35 nós, 32 cartões e 32 vínculos. Origem: segundo PDF, pp. 5–29.
- **T26 · Governança: arquitetura, ciclo e controles:** 35 questões (34 novas), 43 nós, 36 cartões e 36 vínculos. Origem: segundo PDF, pp. 34–71.
- **T32 · Bateria de governança:** 67 questões acessíveis, sendo 66 referências aos bancos T21/T26 e 1 própria, com links aos dois mapas originais.

**Controles da etapa anterior:** 396 questões físicas, 75 mapas com 665 nós, 487 cartões e 365 links válidos, com 14 tarefas ampliadas. A auditoria atualizada passou para **516 questões, 785 nós, 607 cartões, 499 vínculos e 21 tarefas ampliadas**; o déficit aritmético caiu para **969**. Nenhum histórico de respostas ou nota SRS foi artificialmente alterado.

**Proveniência e limite:** 324 questões autorais acrescentadas às 72 iniciais, com referências a apostilas; não atribuir autoria Cebraspe/FCC/FGV aos itens criados. A revisão editorial e pedagógica é necessária antes de considerar todo o conteúdo homologado.

## Detalhamento por tópico

| Trilha | Tarefa | Disciplina | Assunto | Questões distintas acessíveis | Nós do mapa | Flashcards locais | Links exatos cartão–mapa | Situação |
|---|---|---|---|---|---|---|---|---|
| 00 | 01 | Orientações de estudo | Monte uma rotina realista | 0 | 3 | 2 | 0/2 | Orientação: não requer 20 questões |
| 00 | 02 | Orientações de estudo | Crie constância no ciclo | 0 | 3 | 2 | 0/2 | Orientação: não requer 20 questões |
| 00 | 03 | Orientações de estudo | Planeje a revisão com resumos e mapas | 0 | 3 | 2 | 0/2 | Orientação: não requer 20 questões |
| 00 | 04 | Direito Constitucional | Constitucionalismo e neoconstitucionalismo | 25 | 44 | 39 | 39/39 | Cobertura estrutural; revisão editorial pendente |
| 00 | 05 | Tecnologia da Informação | Pirâmide DIKW e dados abertos | **32** | **35** | **33** | **33/33** | Cobertura estrutural; revisão editorial pendente |
| 00 | 06 | Direito Administrativo | Regime jurídico administrativo e princípios expressos | 39 | 44 | 40 | 40/40 | Cobertura estrutural; revisão editorial pendente |
| 00 | 07 | Português | Ortografia, acentuação e acentos diferenciais | **40** | **46** | **41** | **41/41** | Cobertura estrutural; revisão editorial pendente |
| 00 | 08 | Direito Tributário | Tributo: conceito e natureza jurídica | **33** | **39** | **34** | **34/34** | Cobertura estrutural; revisão editorial pendente |
| 00 | 09 | Contabilidade Geral e Avançada | Contabilidade: objeto, finalidade e usuários | **33** | **40** | **34** | **34/34** | Cobertura estrutural; revisão editorial pendente |
| 00 | 10 | Direito Constitucional | Sentidos, estrutura e classificação da Constituição | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 00 | 11 | Tecnologia da Informação | Metadados de arquivos | **29** | **36** | **30** | **30/30** | Cobertura estrutural; revisão editorial pendente |
| 00 | 12 | Direito Administrativo | Princípios administrativos implícitos | 37 | 46 | 38 | 38/38 | Cobertura estrutural; revisão editorial pendente |
| 00 | 13 | Raciocínio Lógico e Matemática | Proposições e sentenças simples | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 00 | 14 | Direito Tributário | Impostos, taxas e contribuição de melhoria | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 00 | 15 | Português | Hífen, grafia, siglas e abreviações | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 00 | 16 | Direito Constitucional | Aplicabilidade das normas e poder constituinte | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 00 | 17 | Tecnologia da Informação | Bateria: DIKW, dados abertos e metadados | **62** | 4 | 2 | **2/2** | Bateria: banco compartilhado |
| 00 | 18 | Direito Administrativo | Bateria: princípios administrativos | 77 | 4 | 2 | 2/2 | Bateria: banco compartilhado |
| 00 | 19 | Contabilidade Geral e Avançada | Bateria: aspectos introdutórios da contabilidade | **34** | 4 | 2 | **2/2** | Bateria: banco compartilhado |
| 00 | 20 | Raciocínio Lógico e Matemática | Proposições compostas e conectivos | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 21 | Tecnologia da Informação | Governança de dados: fundamentos, papéis e organização | **31** | **35** | **32** | **32/32** | Cobertura estrutural; revisão editorial pendente |
| 01 | 22 | Contabilidade Geral e Avançada | Estática patrimonial, situações líquidas, atos e fatos | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 23 | Direito Constitucional | Princípios fundamentais da Constituição | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 24 | Raciocínio Lógico e Matemática | Conversão de linguagem e tabela-verdade | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 25 | Direito Administrativo | Estado, governo e Direito Administrativo | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 26 | Tecnologia da Informação | Governança: arquitetura, ciclo e controles | **35** | **43** | **36** | **36/36** | Cobertura estrutural; revisão editorial pendente |
| 01 | 27 | Direito Tributário | Empréstimos compulsórios, contribuições especiais e classificações | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 28 | Português | Expressões problemáticas e regras de grafia | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 29 | Contabilidade Geral e Avançada | Patrimônio líquido, classificação e teoria das contas | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 30 | Direito Administrativo | Administração Pública em sentidos subjetivo e objetivo | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 31 | Raciocínio Lógico e Matemática | Bateria: proposições simples e compostas | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 32 | Tecnologia da Informação | Bateria: governança de dados | **67** | 4 | 2 | **2/2** | Bateria: banco compartilhado |
| 01 | 33 | Direito Administrativo | Bateria: introdução ao Direito Administrativo | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 34 | Contabilidade Geral e Avançada | Plano de contas e método das partidas dobradas | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 01 | 35 | Tecnologia da Informação | Banco de dados, SGBD e transações | **31** | **34** | **32** | **32/32** | Cobertura estrutural; revisão editorial pendente |
| 01 | 36 | Direito Tributário | Bateria: conceito e espécies tributárias | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 37 | Direito Tributário | Limitações ao poder de tributar: legalidade, isonomia e não confisco | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 38 | Tecnologia da Informação | Papéis, arquitetura ANSI/SPARC e projetos de banco de dados | **31** | **34** | **32** | **32/32** | Cobertura estrutural; revisão editorial pendente |
| 02 | 39 | Direito Constitucional | Normas constitucionais no tempo e interpretação | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 40 | Raciocínio Lógico e Matemática | Equivalências lógicas fundamentais | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 41 | Direito Administrativo | Organização administrativa: direta, indireta, concentração e descentralização | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 42 | Contabilidade Geral e Avançada | Retificação de lançamentos e fatos contábeis | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 43 | Português | Substantivo e adjetivo | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 44 | Tecnologia da Informação | Bateria: conceitos básicos de bancos de dados | **63** | 4 | 2 | **2/2** | Bateria compartilhada |
| 02 | 45 | Direito Tributário | Anterioridades, irretroatividade e demais princípios tributários | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 46 | Raciocínio Lógico e Matemática | Negações lógicas | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 47 | Direito Administrativo | Autarquias e jurisprudência da organização administrativa | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 48 | Português | Advérbio, artigo, numeral e interjeição | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 49 | Direito Constitucional | Bateria: normas constitucionais no tempo e interpretação | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 50 | Tecnologia da Informação | Modelagem conceitual: MER, entidades e relacionamentos | **31** | **35** | **32** | **32/32** | Cobertura estrutural; revisão editorial pendente |
| 02 | 51 | Raciocínio Lógico e Matemática | Álgebra de proposições | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 52 | Contabilidade Geral e Avançada | Bateria: escrituração, parte I | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 53 | Direito Administrativo | Bateria: organização administrativa, parte I | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 54 | Português | Bateria: classes de palavras I | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 55 | Direito Tributário | Bateria: princípios tributários | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 02 | 56 | Raciocínio Lógico e Matemática | Bateria: equivalências e negações | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 57 | Contabilidade Geral e Avançada | Livros contábeis e fiscais e balancete | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 58 | Direito Administrativo | Empresas públicas e sociedades de economia mista: conceitos e prescrição | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 59 | Tecnologia da Informação | Modelagem conceitual: atributos, modelo estendido e pé de galinha | **31** | **33** | **32** | **32/32** | Cobertura estrutural; revisão editorial pendente |
| 03 | 60 | Direito Tributário | Imunidades tributárias: fundamentos, recíproca e religiosa | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 61 | Português | Preposições e conjunções coordenativas | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 62 | Direito Constitucional | Teoria geral dos direitos fundamentais | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 63 | Contabilidade Geral e Avançada | Bateria: escrituração, parte II | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 64 | Raciocínio Lógico e Matemática | Quantificadores e diagramas lógicos | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 65 | Tecnologia da Informação | Bateria: modelagem conceitual | **63** | 4 | 2 | **2/2** | Bateria compartilhada |
| 03 | 66 | Direito Administrativo | Estatais: regime de pessoal. Fundações públicas | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 67 | Contabilidade Geral e Avançada | Regimes contábeis e apuração do resultado | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 68 | Direito Tributário | Imunidades: partidos, entidades, livros e demais hipóteses | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 69 | Português | Conjunções subordinativas e sentidos no contexto | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 70 | Raciocínio Lógico e Matemática | Bateria: diagramas lógicos | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 71 | Tecnologia da Informação | Revisão: DIKW, dados abertos e metadados | **62** | 4 | 2 | **2/2** | Revisão com banco compartilhado |
| 03 | 72 | Direito Constitucional | Bateria: teoria geral dos direitos fundamentais | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 73 | Direito Administrativo | Bateria: organização administrativa, parte II | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 74 | Português | Bateria: preposições e conjunções | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |
| 03 | 75 | Direito Tributário | Bateria: imunidades tributárias | 1 | 4 | 2 | 0/2 | Pendente de aprofundamento |

## Expansão de Bancos de Dados e Modelagem (08/11/2026)

Fonte 4: **4. Análise de Informações - Conceitos Básicos de Bancos de Dados.pdf** (199 páginas). Fonte 5: **5. Análise de Informações - Modelagem Conceitual.pdf** (217 páginas). Foram consultadas as páginas correspondentes ao recorte da trilha, sem inserir textos literais extensos nem atribuir à banca questões novas.

| Trilha / tarefa | Escopo | Questões acessíveis | Flashcards | Nós do mapa |
|---|---|---:|---:|---:|
| 01 / 35 | Banco, SGBD, compartilhamento, ACID e exemplos de transação | 31 | 32 | 34 |
| 02 / 38 | ANSI/SPARC, independência, classificação, DBA/AD e projeto | 31 | 32 | 34 |
| 02 / 44 | Bateria: banco compartilhado das T35/T38 | 63 (62 referências + 1 própria) | 2 | 4 |
| 02 / 50 | MER, entidades, atributos, relacionamentos e cardinalidade | 31 | 32 | 35 |
| 03 / 59 | Atributos, MER estendido, especialização, agregação e Crow's Foot | 31 | 32 | 33 |
| 03 / 65 | Bateria: banco compartilhado das T50/T59 | 63 (62 referências + 1 própria) | 2 | 4 |
| 03 / 71 | Revisão: mesmo banco DIKW/metadados T05/T11 | 62 (61 referências + 1 própria) | 2 | 4 |

Foram criadas **120 questões originais** de Certo/Errado, com gabarito, comentário, página do PDF, ID estável de origem, mapaNoId e vínculos a cartão. As quatro tarefas teóricas preservam os dois flashcards anteriores e sua questão original. As baterias e revisões **não copiam** questões nem modificam respostas, histórico ou repetição espaçada do candidato.

**Auditoria desta etapa:** 516 questões físicas distintas; 75 mapas, 785 nós (727 com ID), 607 flashcards e 499 vínculos explícitos válidos. **21 tarefas com cobertura estrutural ampliada** e 54 ainda pendentes, incluindo orientações de estudo. A análise técnica não homologa automaticamente a qualidade pedagógica nem comprova domínio das matérias.

## Critérios para avançar

1. Fonte realmente consultada, com páginas referenciadas.
2. Pelo menos 20 questões C/E independentes por assunto, reutilizadas nas baterias pelo mesmo ID quando os conteúdos forem coincidentes.
3. Gabarito, comentário e distinção entre item autoral e questão real de concurso.
4. Mapa temático com conceitos, relações, exemplos e distorções de banca.
5. Flashcards de evocação e aplicação ligados por `mapaNoId`, sem interferência na revisão espaçada.
6. Testes de integridade e validação editorial sem alteração das respostas anteriores.

## Continuação desta etapa (T07, T08, T09 e T19)

- Os três temas teóricos foram ampliados usando os PDFs anexados, com questão autoral Certo/Errado, comentário, referência à página, subtópico e ligação direta a nó do mapa e flashcard.
- Foram preservados em cada tarefa os dois flashcards anteriores e a questão original. A revisão espaçada segue o motor existente; nenhum resultado do candidato foi alterado.
- O banco compartilhado da T19 inclui 33 referências por ID a questões da T09 sem criar documentos duplicados. Esta bateria continua com seu próprio item original.
- A T08 exige atenção especial à ressalva jurisprudencial sobre dação de bens móveis (ADI 1.917 e ADI 2.405) e ao caráter finalístico de certas espécies tributárias, tal como tratado nas páginas da apostila, sem extrapolações.
- **Histórico:** os marcos anteriores eram 273 questões / 364 cartões, e depois 396 questões / 487 cartões. A auditoria atualizada está no primeiro quadro: 516 questões e 607 cartões, sem duplicar registros de baterias.
- **Limitação atual:** ainda existem 54 tarefas sem cobertura estrutural ampliada, incluindo 3 orientações iniciais. Os demais assuntos exigem leitura, elaboração e revisão editorial.

## Suplementos de TI a partir dos PDFs 3, 6 e 7 (08/11/2026)

Foram agregados **três módulos suplementares** sem adulterar o roteiro oficial das 75 tarefas. Qualidade de Dados (`fiscal-sup-qualidade`): 24 questões e 24 cartões; Modelagem Lógica (`fiscal-sup-modelagem-logica`): 24 e 24; Normalização (`fiscal-sup-normalizacao`): 27 e 27. Seus mapas têm 91 nós ao todo, incluídos 16 ramos e 75 folhas; os 75 flashcards ligam-se a 75 questões por ID.

**Banco total auditado na Área Fiscal:** 591 questões únicas, das quais 516 anteriores e 75 recém-incluídas; 78 documentos em `edital`, sendo 75 tarefas oficiais e 3 suplementos não numerados; 78 mapas em `revisao`. Totais de cartões, nós e links derivados da auditoria anterior: 682, 876 e 574, respectivamente. Preservaram-se o histórico de respostas e os mecanismos de repetição espaçada; nenhuma nota foi fabricada. A marcação `SUP` não se confunde com as trilhas 00–03.

Conteúdo registrado em `docs/AREA_FISCAL_TI_SUPLEMENTOS_3_6_7.md`, com fontes e páginas. Os itens são autorais, estruturalmente testados, porém ainda **não homologados pedagogicamente**.
