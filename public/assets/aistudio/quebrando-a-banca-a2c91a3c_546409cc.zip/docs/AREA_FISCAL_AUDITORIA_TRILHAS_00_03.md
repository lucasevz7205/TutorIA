# Auditoria de cobertura — Área Fiscal · Trilhas 00 a 03

Data de auditoria: 2026-11-08. Ambiente de estudo: 6af069aa28e43e39f27bd73c. Fonte: coleções autenticadas StudyDocument do Base44. **Não houve leitura dos ZIPs/PDFs da pasta `concurso - primo/material`.**

## Resultado consolidado

- Tópicos cadastrados: 75; distribuição {"00":20,"01":16,"02":20,"03":19}.
- Questões comentadas cadastradas na auditoria inicial: 72; **agora 96**, após inclusão de 24 itens autorais na T04. Procedência declarada: {"Autoral · adaptação para treino":72}.
- Cartões na auditoria inicial: 150; **agora 187**, em virtude de 37 novos cartões da T04; mapas permanecem 75, com 44 nós só no mapa T04. Cartões originais: 150, em 75 documentos. Mapas: 75; nós existentes no total: 297 (não mede profundidade/qualidade).
- Vínculos explícitos cartão → nó de mapa: 0/150 na auditoria inicial. **Piloto T04 concluído:** mapa ampliado para 44 nós, 39 cartões mapeados (incluindo os dois originais preservados). Links explicitamente válidos: 39/39 na T04. Demais cartões não modificados, total geral **39/187**.
- Déficit matemático inicial para atingir 20 por tópico sem reaproveitamento: 1428; com a T04 cumprida, **1409** faltantes em tarefas distintas. **Esta cifra não é meta de geração definitiva**: questões do mesmo assunto devem formar um banco único e compartilhado entre teoria/bateria, após normalização.
- A contagem de nós não prova cobertura dos subtópicos das apostilas. Status de cobertura semântica: **não auditável sem o PDF integral**.
- Revisão ativa: os 150 flashcards existentes usam o mecanismo de autoavaliação e espaçamento do app, porém a coleção `cartoes_aval` não tinha registros nesse ambiente durante o inventário: **0 avaliações registradas por assunto**. Material disponível não equivale a revisão efetivamente realizada.

## Status por assunto

As linhas abaixo são tópicos operacionais da trilha e ainda não foram fundidas por identidade conceitual. Uma tarefa de teoria e sua bateria correlata devem apontar para o mesmo banco temático, preservando registros históricos existentes.

| Trilha | Tarefa | Disciplina | Assunto | Questões C/E distintas | Nós no mapa | Flashcards | Links exatos ao mapa | Situação |
|---|---:|---|---|---:|---:|---:|---:|---|
| 00 | 01 | Orientações de estudo | Monte uma rotina realista | 0 | 3 | 2 | 0/2 | Lacuna |
| 00 | 02 | Orientações de estudo | Crie constância no ciclo | 0 | 3 | 2 | 0/2 | Lacuna |
| 00 | 03 | Orientações de estudo | Planeje a revisão com resumos e mapas | 0 | 3 | 2 | 0/2 | Lacuna |
| 00 | 04 | Direito Constitucional | Constitucionalismo e neoconstitucionalismo | **25** | **44** | **39** | **39/39** | **Cobertura estrutural concluída; revisão editorial pendente** |
| 00 | 05 | Tecnologia da Informação | Pirâmide DIKW e dados abertos | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 06 | Direito Administrativo | Regime jurídico administrativo e princípios expressos | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 07 | Português | Ortografia, acentuação e acentos diferenciais | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 08 | Direito Tributário | Tributo: conceito e natureza jurídica | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 09 | Contabilidade Geral e Avançada | Contabilidade: objeto, finalidade e usuários | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 10 | Direito Constitucional | Sentidos, estrutura e classificação da Constituição | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 11 | Tecnologia da Informação | Metadados de arquivos | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 12 | Direito Administrativo | Princípios administrativos implícitos | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 13 | Raciocínio Lógico e Matemática | Proposições e sentenças simples | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 14 | Direito Tributário | Impostos, taxas e contribuição de melhoria | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 15 | Português | Hífen, grafia, siglas e abreviações | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 16 | Direito Constitucional | Aplicabilidade das normas e poder constituinte | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 17 | Tecnologia da Informação | Bateria: DIKW, dados abertos e metadados | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 18 | Direito Administrativo | Bateria: princípios administrativos | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 19 | Contabilidade Geral e Avançada | Bateria: aspectos introdutórios da contabilidade | 1 | 4 | 2 | 0/2 | Lacuna |
| 00 | 20 | Raciocínio Lógico e Matemática | Proposições compostas e conectivos | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 21 | Tecnologia da Informação | Governança de dados: fundamentos, papéis e organização | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 22 | Contabilidade Geral e Avançada | Estática patrimonial, situações líquidas, atos e fatos | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 23 | Direito Constitucional | Princípios fundamentais da Constituição | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 24 | Raciocínio Lógico e Matemática | Conversão de linguagem e tabela-verdade | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 25 | Direito Administrativo | Estado, governo e Direito Administrativo | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 26 | Tecnologia da Informação | Governança: arquitetura, ciclo e controles | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 27 | Direito Tributário | Empréstimos compulsórios, contribuições especiais e classificações | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 28 | Português | Expressões problemáticas e regras de grafia | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 29 | Contabilidade Geral e Avançada | Patrimônio líquido, classificação e teoria das contas | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 30 | Direito Administrativo | Administração Pública em sentidos subjetivo e objetivo | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 31 | Raciocínio Lógico e Matemática | Bateria: proposições simples e compostas | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 32 | Tecnologia da Informação | Bateria: governança de dados | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 33 | Direito Administrativo | Bateria: introdução ao Direito Administrativo | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 34 | Contabilidade Geral e Avançada | Plano de contas e método das partidas dobradas | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 35 | Tecnologia da Informação | Banco de dados, SGBD e transações | 1 | 4 | 2 | 0/2 | Lacuna |
| 01 | 36 | Direito Tributário | Bateria: conceito e espécies tributárias | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 37 | Direito Tributário | Limitações ao poder de tributar: legalidade, isonomia e não confisco | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 38 | Tecnologia da Informação | Papéis, arquitetura ANSI/SPARC e projetos de banco de dados | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 39 | Direito Constitucional | Normas constitucionais no tempo e interpretação | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 40 | Raciocínio Lógico e Matemática | Equivalências lógicas fundamentais | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 41 | Direito Administrativo | Organização administrativa: direta, indireta, concentração e descentralização | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 42 | Contabilidade Geral e Avançada | Retificação de lançamentos e fatos contábeis | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 43 | Português | Substantivo e adjetivo | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 44 | Tecnologia da Informação | Bateria: conceitos básicos de bancos de dados | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 45 | Direito Tributário | Anterioridades, irretroatividade e demais princípios tributários | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 46 | Raciocínio Lógico e Matemática | Negações lógicas | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 47 | Direito Administrativo | Autarquias e jurisprudência da organização administrativa | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 48 | Português | Advérbio, artigo, numeral e interjeição | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 49 | Direito Constitucional | Bateria: normas constitucionais no tempo e interpretação | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 50 | Tecnologia da Informação | Modelagem conceitual: MER, entidades e relacionamentos | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 51 | Raciocínio Lógico e Matemática | Álgebra de proposições | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 52 | Contabilidade Geral e Avançada | Bateria: escrituração, parte I | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 53 | Direito Administrativo | Bateria: organização administrativa, parte I | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 54 | Português | Bateria: classes de palavras I | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 55 | Direito Tributário | Bateria: princípios tributários | 1 | 4 | 2 | 0/2 | Lacuna |
| 02 | 56 | Raciocínio Lógico e Matemática | Bateria: equivalências e negações | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 57 | Contabilidade Geral e Avançada | Livros contábeis e fiscais e balancete | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 58 | Direito Administrativo | Empresas públicas e sociedades de economia mista: conceitos e prescrição | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 59 | Tecnologia da Informação | Modelagem conceitual: atributos, modelo estendido e pé de galinha | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 60 | Direito Tributário | Imunidades tributárias: fundamentos, recíproca e religiosa | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 61 | Português | Preposições e conjunções coordenativas | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 62 | Direito Constitucional | Teoria geral dos direitos fundamentais | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 63 | Contabilidade Geral e Avançada | Bateria: escrituração, parte II | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 64 | Raciocínio Lógico e Matemática | Quantificadores e diagramas lógicos | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 65 | Tecnologia da Informação | Bateria: modelagem conceitual | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 66 | Direito Administrativo | Estatais: regime de pessoal. Fundações públicas | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 67 | Contabilidade Geral e Avançada | Regimes contábeis e apuração do resultado | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 68 | Direito Tributário | Imunidades: partidos, entidades, livros e demais hipóteses | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 69 | Português | Conjunções subordinativas e sentidos no contexto | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 70 | Raciocínio Lógico e Matemática | Bateria: diagramas lógicos | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 71 | Tecnologia da Informação | Revisão: DIKW, dados abertos e metadados | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 72 | Direito Constitucional | Bateria: teoria geral dos direitos fundamentais | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 73 | Direito Administrativo | Bateria: organização administrativa, parte II | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 74 | Português | Bateria: preposições e conjunções | 1 | 4 | 2 | 0/2 | Lacuna |
| 03 | 75 | Direito Tributário | Bateria: imunidades tributárias | 1 | 4 | 2 | 0/2 | Lacuna |

## Primeira unidade editorial: Trilha 00 · Tarefa 04

**Assunto:** Constitucionalismo e neoconstitucionalismo. Fonte de leitura indicada no roteiro: `DIREITO CONSTITUCIONAL.zip › 1. Conceito. Classificação. Aplicab.pdf`.

A trilha disponível no Base44 descreve: (a) constitucionalismo como limitação do poder, (b) força normativa da Constituição, (c) centralidade dos direitos fundamentais, (d) papel dos princípios no neoconstitucionalismo. Ela **não contém o PDF** nem a extensão e as ressalvas de cada tópico. **Pós-recebimento da fonte:** a tarefa tem **25 questões únicas** (24 autorais novas + 1 original preservada), todas com comentários e C/E; **44 nós** em sete ramos (seção 1.2, p. 7–18), e **39 cartões** de evocação/aplicação com correspondência explícita a nó (39/39 validada). Os itens novos não são transcrições integrais de provas: são questões autorais derivadas da leitura. A questão já existente `fiscal-t04-ce01` foi preservada. Cada enunciado tem fonte indicada e todas as 25 questões foram associadas diretamente a pelo menos um nó/cartão. O mecanismo de espaçamento existente permanece intacto; não houve criação artificial de avaliações.

**Critérios para homologação:** (1) fonte PDF efetivamente lida e páginas/seções rastreáveis, (2) pelo menos 20 itens independentes com C/E, comentário e prova de origem, (3) mapa multinível cobrindo conceitos, autores, fases históricas, diferenciações e armadilhas realmente tratados na apostila, (4) cartões por subtópico com perguntas de recuperação e aplicação, (5) mapaNoId individual válido em cada cartão, (6) associação das questões ao mesmo assunto e reutilização por baterias sem duplicação, (7) testes do app e conferência editorial de exemplos.

## Lacunas documentais

**Para finalizar a Trilha 00:** anexar `Trilha 00-4.pdf` e, para começar pela tarefa 04, `DIREITO CONSTITUCIONAL.zip` ou o PDF extraído `1. Conceito. Classificação. Aplicab.pdf`.

**Para expandir 00–03:** disponibilizar a pasta `material` ou os ZIPs/PDFs completos de Direito Constitucional, Direito Administrativo, Direito Tributário, Português, Contabilidade, TI e Raciocínio Lógico, além das Trilhas 01–03. Os nomes indicados em `materiais` são **referências bibliográficas**, não acesso aos arquivos. Modelos do ambiente da Câmara já são acessíveis pela coleção legada `ClaudeDocument/revisao` e não precisam ser reenviados.

## Reutilização de bancos (candidatos à normalização, não fusão automática)

- Trilha 00 · Tarefas 05 (DIKW e dados abertos), 11 (metadados), 17 (bateria DIKW/metadados): mapear subtópicos em um ou mais bancos conceituais compartilhados, sem confundir dados abertos com metadados.
- Trilha 00 · Tarefas 06 (princípios expressos), 12 (implícitos), 18 (bateria de princípios): reutilização por subassunto, não por todo o PDF indistintamente.
- Trilha 00 · Tarefas 09 e 19: introdução à Contabilidade (objeto, finalidade, usuários) e respectiva bateria.
- Trilha 00 · Tarefas 04, 10, 16: mesma apostila de Direito Constitucional, **mas assuntos diferentes**, não devem compartilhar indiscriminadamente as mesmas questões.

## Atualização após o recebimento das fontes em 08/11/2026

Recebidos no chat os arquivos `primo.zip` (Trilhas 00 a 03), `DIREITO CONSTITUCIONAL.zip`, `DIREITO ADMINISTRATIVO.zip`, `DIREITO TRIBUTÁRIO.zip`, `PORTUGUÊS.zip`, `RACIOCÍNIO LÓGICO.zip` e `CONTABILIDADE.zip`. **Não foi fornecido `TI.zip`, necessário às tarefas de Tecnologia da Informação.** Os PDFs permaneceram no material fornecido pelo usuário, e a base contém apenas conhecimento transformado em perguntas, explicações e mapa, com indicação de páginas.

A validação da T04 conferiu IDs, gabaritos, 25 enunciados distintos, 39 cartões, 44 nós, 39 links válidos cartão → nó, **25/25 questões com ligação direta a pelo menos um cartão/nó** e a integridade dos 8 fragmentos que compõem o documento de revisão. A abertura do nó do mapa exibe as questões associadas, com gabarito/comentário recolhidos até que o estudante os revele. A cobertura do PDF nos ramos estudados é estrutural; demanda avaliação pedagógica do usuário antes de chamá-la de domínio da matéria.
